var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

jQuery(function ($) {
    var App = App || {};
    App.Manage = function () {
        var view = {
            init: function () {
                controls.init();
                view.bind();
            },
            bind: function () {
                helper.validateForm();
                helper.eventCalender();
            }
        };

        var controls = {
            init: function () {
                this.Form = $(".jsForm");
            }
        };

        var helper = {
            initDatatable: function () {
                if ($(".datatable").length > 0) {
                    $(".datatable").dataTable();
                }
            },
            validateForm: function () {
                controls.Form.validate({
                    errorElement: 'span',
                    errorClass: 'help-block',
                    focusInvalid: true,
                    rules: {
                        pass:{
                             required: true,
                            minlength: 6, 
                        },
                        cpass: {
                            required: true,
                            minlength: 6,
                            equalTo: "#password"
                        }
                    },
                    messages: {
                        pass:{
                            required: "Please Enter Password",
                        }
                    },
                    invalidHandler: function (event, validator) {
                    },
                    highlight: function (element) {
                        $(element).closest('.form-group').addClass('has-error');
                    },
                    success: function (label) {
                        label.closest('.form-group').removeClass('has-error');
                        label.remove();
                    },
                    errorPlacement: function (error, element) {

                        error.insertAfter(element);

                    },
                    submitHandler: function (form) {
                        var btn = $(this)[0].submitButton;
                        form.submit();
                    }
                });
            },
            eventCalender: function () {
                if ($(".monthly").length > 0) {
                    $('#mycalendar').monthly({
                        mode: 'event',
                        dataType: 'json',
                        events: str
                    });
                }
            },
        }
        view.init();
    }
    App.Manage();
})

}
/*
     FILE ARCHIVED ON 20:17:37 Nov 21, 2018 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:01:18 Jan 28, 2021.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 2234.979
  RedisCDXSource: 3.226
  CDXLines.iter: 20.615 (3)
  exclusion.robots.policy: 0.248
  esindex: 0.012
  PetaboxLoader3.datanode: 2214.8 (5)
  LoadShardBlock: 2207.12 (3)
  PetaboxLoader3.resolve: 1590.938 (2)
  exclusion.robots: 0.26
  load_resource: 1692.87 (2)
*/