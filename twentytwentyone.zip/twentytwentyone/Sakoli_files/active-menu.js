var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

function setMenuActive(page_parent) {
    switch (page_parent) {
        case "":
            $(".home").addClass("current-menu-parent");
            break;
        case 'about-us':
            $(".menu-item-1").addClass("current-menu-parent");
            break;
        case 'resources':
            $(".menu-item-5").addClass("current-menu-parent");
            break;
        case 'membership':
            $(".menu-item-2").addClass("current-menu-parent");
            break;
    }
}



}
/*
     FILE ARCHIVED ON 03:15:51 Nov 21, 2018 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:01:24 Jan 28, 2021.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  LoadShardBlock: 3774.266 (3)
  RedisCDXSource: 1.468
  load_resource: 2524.518 (2)
  captures_list: 3794.996
  exclusion.robots: 0.306
  esindex: 0.013
  PetaboxLoader3.datanode: 5991.381 (5)
  exclusion.robots.policy: 0.29
  CDXLines.iter: 15.944 (3)
  PetaboxLoader3.resolve: 239.49 (2)
*/