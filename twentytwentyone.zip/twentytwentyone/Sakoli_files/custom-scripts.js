var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

jQuery(document).ready(function() {
	$window 		  = jQuery(window),
	$the_post		  = jQuery('#the-post'),
	$wrapper 		  = jQuery("#wrapper");

if( tie.SmothScroll ){
	tie_SmothScroll();
}

//Responsive Videos
	$wrapper.fitVids();

//LightBox
	jQuery( "a.lightbox-enabled, a[rel='lightbox-enabled']" ).iLightBox({ skin: tie.lightbox_skin});

	if( tie.lightbox_all ){
	 	$the_post.find("div.entry a").not( "div.entry .gallery a" ).each(function(i, el) {
			var href_value = el.href;
			if (/\.(jpg|jpeg|png|gif)$/.test(href_value)) {
				jQuery(this).iLightBox({ skin: tie.lightbox_skin});
			}
		});
	};

	if( tie.lightbox_gallery ){
		$the_post.find("div.entry .gallery a").each(function(i, el) {
			var href_value = el.href;
			if (/\.(jpg|jpeg|png|gif)$/.test(href_value)) {
				jQuery(this).addClass( 'ilightbox-gallery' );
			}
		});
		$the_post.find( '.ilightbox-gallery' ).iLightBox({
			skin: tie.lightbox_skin,
			path: tie.lightbox_thumb,
			controls: {
				arrows: tie.lightbox_arrows,
			}
		});
	};

	jQuery( 'section.videos-lightbox a.single-videolighbox' ).iLightBox({
		skin: tie.lightbox_skin,
		path: tie.lightbox_thumb,
		controls: {
			arrows: tie.lightbox_arrows,
		}
	});

	if( tie.woocommerce_lightbox == 'yes' ){
		jQuery( "a[rel='lightbox-enabled[product-gallery]']" ).iLightBox({
			skin: tie.lightbox_skin,
			path: tie.lightbox_thumb,
			controls: {
				arrows: tie.lightbox_arrows,
			}
		});
	};

//Slide-out Sidebar
	jQuery("#slide-out-open").click(function() {
		if( jQuery( this ).hasClass( "slide-out-open" ) ) {
			$wrapper.css({overflow:"hidden"});
			jQuery("body").addClass( 'js-nav' );
			jQuery( this ).removeClass('slide-out-open').addClass('slide-out-close');
			return false;
		}
		else if( jQuery( this ).hasClass( "slide-out-close" ) ) {
			$wrapper.css({overflow:"auto"});
			jQuery("body").removeClass( 'js-nav' );
			jQuery( this ).removeClass('slide-out-close').addClass('slide-out-open');
			return false;
		}
	});

	if ( !Modernizr.csstransforms || !Modernizr.csstransitions || !Modernizr.csstransforms3d) {
		var TieSlideOpenIE = false ;
		jQuery('#slide-out').hide();
		jQuery("#slide-out-open").click(function() {
			jQuery('#mobile-menu').show();
			jQuery('#slide-out').show();
			jQuery(this).hide();
			jQuery('div.wrapper-outer').css({overflow:"hidden"});
			jQuery('#open-slide-overlay').remove();
			jQuery('body').append('<div id="open-slide-overlay"></div>');
			TieSlideOpenIE = true ;
		});

		jQuery(document).on("click", "#open-slide-overlay" , function(){
			if( TieSlideOpenIE ){
				jQuery('#slide-out').hide();
				jQuery('#mobile-menu').hide();
				jQuery('#slide-out-open').show();
				jQuery('div.wrapper-outer').css({overflow:"auto"});
				jQuery(this).remove();
				TieSlideOpenIE = false ;
			}
		});
	}

//Mobile Menus
	if( tie.mobile_menu_active ){
		var mobileItems = jQuery( '#main-nav div.main-menu' ).clone();
		mobileItems.find( 'div.mega-menu-content' ).remove();
		mobileItems.find( 'li.menu-item-has-children' ).append( '<i class="mobile-arrows fa fa-chevron-down"></i>' );
		jQuery( '#slide-out #mobile-menu' ).append( mobileItems );

		if( tie.mobile_menu_top ){
			var mobileItemsTop = jQuery( '#top-nav div.top-menu ul.menu' ).clone();
			mobileItemsTop.find( 'li.menu-item-has-children' ).append( '<i class="mobile-arrows fa fa-chevron-down"></i>' );
			jQuery( '#slide-out #mobile-menu' ).append( mobileItemsTop );
		}
	}

	jQuery("#mobile-menu li.menu-item-has-children i.mobile-arrows").click(function() {
		if( jQuery( this ).hasClass( "fa-chevron-down" ) )
			jQuery( this ).removeClass( "fa-chevron-down" ).addClass( "fa-chevron-up" );
		else
			jQuery( this ).removeClass( "fa-chevron-up" ).addClass( "fa-chevron-down" );

		jQuery( this ).parent().find('ul:first').toggle();
	});

//Scroll To top
	var $topcontrol = jQuery('#topcontrol');
	$window.scroll(function(){
		if (jQuery(this).scrollTop() > 100) {
			$topcontrol.css({bottom:"10px"});
		} else {
			$topcontrol.css({bottom:"-100px"});
		}
	});
	$topcontrol.click(function(){
		jQuery('html, body').animate({scrollTop: '0px'}, 800);
		return false;
	});

//Go to Post Content
	jQuery('a.go-to-the-post').click(function(){
		jQuery('html, body').animate({scrollTop: $the_post.offset().top}, 500);
		return false;
	});

//tooltip();
    jQuery('.tooltip-nw').tipsy({fade: true, gravity: 'nw'});
    jQuery('.tooltip-ne').tipsy({fade: true, gravity: 'ne'});
    jQuery('.tooltip-w' ).tipsy({fade: true, gravity: 'w' });
    jQuery('.tooltip-e' ).tipsy({fade: true, gravity: 'e' });
    jQuery('.tooltip-sw').tipsy({fade: true, gravity: 'w' });
    jQuery('.tooltip-se').tipsy({fade: true, gravity: 'e' });
    jQuery('.ttip, .tooltip-n'	  ).tipsy({fade: true, gravity: 's'});
    jQuery('.tooldown, .tooltip-s').tipsy({fade: true, gravity: 'n'});

// Toggle Shortcode
	jQuery("h3.toggle-head-open").click(function () {
		jQuery(this).parent().find("div.toggle-content").slideToggle("slow");
		jQuery(this).hide();
		jQuery(this).parent().find("h3.toggle-head-close").show();
    });
	jQuery("h3.toggle-head-close").click(function () {
		jQuery(this).parent().find("div.toggle-content").slideToggle("slow");
		jQuery(this).hide();
		jQuery(this).parent().find("h3.toggle-head-open").show();
    });

//Mega-Menus
	jQuery( "#main-nav li.mega-menu:not(#main-nav li li)" ).hover(function(){
		var menuWidth 			= jQuery( '#main-nav div.container' ).width();
		var menuPosition 		= jQuery(this).offset();
		var menuItemPosition 	= jQuery(this).offset();
		var PositionLeft 		= menuItemPosition.left-menuPosition.left+50;
                console.log(menuWidth+PositionLeft);
		jQuery(this).find('div.mega-menu-block').css({ left: '-'+PositionLeft+'px', width: menuWidth-900 });
	});

//Mega Menus Tabs
	jQuery("div.mega-cat-wrapper").each(function(){
		jQuery( this ).find("div.mega-cat-content-tab").hide();
		jQuery( this ).find("ul.mega-cat-sub-categories li:first").addClass("cat-active").show();
		jQuery( this ).find("div.mega-cat-content-tab:first").addClass("already-loaded").show();
		jQuery( this ).find("ul.mega-cat-sub-categories li").click(function( event ) {
			event.preventDefault();
			jQuery( this ).parent().find("li").removeClass("cat-active");
			jQuery( this ).addClass("cat-active");
			jQuery( this ).parent().parent().parent().find("div.mega-cat-content-tab").hide();
			var activeTab = jQuery(this).find("a").attr("href");

			if( jQuery(activeTab).hasClass( "already-loaded" ) ){
				jQuery(activeTab).fadeIn();
			}else{
				jQuery(activeTab).addClass("loading-items").fadeIn( 600 , function() {
					jQuery( this ).removeClass("loading-items").addClass("already-loaded");
				});
			}
			return false;
		});
	});

//iPad menu hover bug with Safari
	var userAgent = navigator.userAgent;
	if ( userAgent.match(/iPad/i) ) {
		if ( userAgent.search("Safari") >= 0 && userAgent.search("Chrome") < 0 ) {
			jQuery('#main-nav li.menu-item-has-children a, #main-nav li.mega-menu a, #top-nav li.menu-item-has-children a').attr("onclick","return true");
		}
	}

//tabbed Boxes
 	jQuery("div.cat-box-content").each(function(){
		jQuery( this ).find("div.cat-tabs-wrap").hide();
		jQuery( this ).find("div.cat-tabs-header ul li:first").addClass("active").show();
		jQuery( this ).find("div.cat-tabs-wrap:first").show();
		jQuery( this ).find("div.cat-tabs-header ul li").click(function( event ) {
			event.preventDefault();
			jQuery( this ).parent().find("li").removeClass("active");
			jQuery( this ).addClass("active");
			jQuery( this ).parent().parent().parent().find("div.cat-tabs-wrap").hide();
			var activeTab = jQuery(this).find("a").attr("href");
			jQuery(activeTab).fadeIn();
			return false;
		});
	});

	var $tabbed_Widget_tabs_wrap = jQuery("#tabbed-widget div.tabs-wrap");
	$tabbed_Widget_tabs_wrap.hide();
	jQuery("#tabbed-widget ul.posts-taps li:first").addClass("active").show();
	jQuery("#tabbed-widget div.tabs-wrap:first").show();
	jQuery("#tabbed-widget li.tabs").click(function() {
		jQuery("#tabbed-widget ul.posts-taps li").removeClass("active");
		jQuery(this).addClass("active");
		$tabbed_Widget_tabs_wrap.hide();
		var activeTab = jQuery(this).find("a").attr("href");
		jQuery(activeTab).slideDown();
		return false;
	});

//Scrolling Boxes height Fix
	$window.smartresize(function(){
		jQuery("div.group_items-box").each(function(i, el) {
			var groups_height = jQuery(this).find( 'div.group_items:first-child' ).height();
			jQuery(this).height( groups_height );
		});
	});

//Stick Navigation
	var stickySidebarTop = 0;
	var $fixed_enabled = jQuery("#main-nav.fixed-enabled");
	if( !tie_isMobile.any() && $fixed_enabled.length > 0 ){
		stickySidebarTop = 50;
		jQuery( '#theme-header' ).imagesLoaded(function() {
			jQuery(function(){
				var navScroll_1  = jQuery(document).scrollTop();
				var headerHeight = $fixed_enabled .offset().top;

				$window.scroll(function() {
					var navScroll_2 = jQuery(document).scrollTop();

					if (navScroll_2 > headerHeight){ $fixed_enabled.addClass('fixed-nav'); }
					else { $fixed_enabled.removeClass('fixed-nav');}

					if (navScroll_2 > navScroll_1){ $fixed_enabled.removeClass('fixed-nav-appear');}
					else { $fixed_enabled.addClass('fixed-nav-appear');}

					navScroll_1 = jQuery(document).scrollTop();
				});
			});
		});
	}

//Sticky Sidebar
	if( !tie_isMobile.any() && tie.sticky_sidebar ){
		jQuery( '#sidebar' ).theiaStickySidebar({"containerSelector":".content","additionalMarginTop": stickySidebarTop });
	}

//Check Also Box
	jQuery(function(){
		var $check_also_box = jQuery("#check-also-box");
		if( tie.is_singular && $check_also_box.length > 0 ){
			var articleHeight   =  $the_post.outerHeight();
			var checkAlsoClosed = false ;
			$window.scroll(function() {
				if( !checkAlsoClosed ) {
					var articleScroll = jQuery(document).scrollTop();
					if ( articleScroll > articleHeight ){ $check_also_box.addClass('show-check-also');}
					else { $check_also_box.removeClass('show-check-also');}
				}
			});
		}
		jQuery('#check-also-close').click(function() {
			$check_also_box.removeClass("show-check-also");
			checkAlsoClosed = true ;
			return false;
		});
	});

//Reading Position Indicator
	if( tie.is_singular && tie.reading_indicator ){
		var reading_content = $the_post.find( '.entry' );
		if( reading_content.length > 0 ){

			reading_content.imagesLoaded(function() {
				var content_height	= reading_content.height();
					window_height	= $window.height();

				$window.scroll(function() {
					var percent 		= 0,
						content_offset	= reading_content.offset().top;
						window_offest	= $window.scrollTop();

					if (window_offest > content_offset) {
						percent = 100 * (window_offest - content_offset) / (content_height - window_height);
					}
					jQuery('#reading-position-indicator').css('width', percent + '%');
				});
			});
		}
	}

//Comments Form
	if( tie.is_singular ){
		jQuery( "#reply-title" ).after( '<div class="stripe-line"></div>' );
	}

});

// Breaking News
function createTicker(){
	var tickerLIs 	= jQuery("#breaking-news ul").children();
	tickerItems 	= new Array();
	tickerLIs.each(function(el) {
		tickerItems.push( jQuery(this).html() );
	});
	i = 0  ;
	rotateTicker();
}
var isInTag = false;
function typetext() {
	var $breaking_news = jQuery('#breaking-news ul');
	if( $breaking_news.length > 0 ){
		var thisChar = tickerText.substr(c, 1);
		if( thisChar == '<' ){ isInTag = true; }
		if( thisChar == '>' ){ isInTag = false; }
		$breaking_news.html(tickerText.substr(0, c++));
		if(c < tickerText.length+1)
			if( isInTag ){
				typetext();
			}else{
				setTimeout("typetext()", 35);
			}
		else {
			c = 1;
			tickerText = "";
		}
	}
}

//images Scroll
jQuery(function() {
  var win_height_padded = $window.height() * .9;

  $window.on('scroll', tieRevealOnScroll);

  function tieRevealOnScroll() {
    var scrolled = $window.scrollTop(),
        win_height_padded = $window.height() * .9;

	jQuery("body.lazy-enabled #theme-footer div.post-thumbnail, body.lazy-enabled #main-content div.post-thumbnail, body.lazy-enabled #main-content img:not(.ei-slider-thumbs img), body.lazy-enabled #featured-posts").each(function () {
      var $this     = jQuery(this),
          offsetTop = $this.offset().top;

      if (scrolled + win_height_padded > offsetTop) {
		   jQuery(this).addClass( 'tie-appear' );
      }
    });
  }

  tieRevealOnScroll();
});

//isMobile
var tie_isMobile={Android:function(){return navigator.userAgent.match(/(?=.*\bAndroid\b)(?=.*\bMobile\b)/i)},BlackBerry:function(){return navigator.userAgent.match(/BlackBerry/i)},iOS:function(){return navigator.userAgent.match(/iPhone|iPod/i)},Opera:function(){return navigator.userAgent.match(/Opera Mini/i)},Windows:function(){return navigator.userAgent.match(/IEMobile/i)},any:function(){return tie_isMobile.Android()||tie_isMobile.BlackBerry()||tie_isMobile.iOS()||tie_isMobile.Opera()||tie_isMobile.Windows()}};
//debouncing
(function(e,t){var n=function(e,t,n){var r;return function(){function u(){if(!n)e.apply(s,o);r=null}var s=this,o=arguments;if(r)clearTimeout(r);else if(n)e.apply(s,o);r=setTimeout(u,t||100)}};jQuery.fn[t]=function(e){return e?this.bind("resize",n(e)):this.trigger(t)}})(jQuery,"smartresize")
//SmoothScroll for websites v1.2.1
function tie_SmothScroll(){function c(){var e=false;if(e){N("keydown",y)}if(t.keyboardSupport&&!e){T("keydown",y)}}function h(){if(!document.body)return;var e=document.body;var i=document.documentElement;var a=window.innerHeight;var f=e.scrollHeight;o=document.compatMode.indexOf("CSS")>=0?i:e;u=e;c();s=true;if(top!=self){r=true}else if(f>a&&(e.offsetHeight<=a||i.offsetHeight<=a)){var l=false;var h=function(){if(!l&&i.scrollHeight!=document.height){l=true;setTimeout(function(){i.style.height=document.height+"px";l=false},500)}};i.style.height="auto";setTimeout(h,10);if(o.offsetHeight<=a){var p=document.createElement("div");p.style.clear="both";e.appendChild(p)}}if(!t.fixedBackground&&!n){e.style.backgroundAttachment="scroll";i.style.backgroundAttachment="scroll"}}function m(e,n,r,i){i||(i=1e3);k(n,r);if(t.accelerationMax!=1){var s=+(new Date);var o=s-v;if(o<t.accelerationDelta){var u=(1+30/o)/2;if(u>1){u=Math.min(u,t.accelerationMax);n*=u;r*=u}}v=+(new Date)}p.push({x:n,y:r,lastX:n<0?.99:-.99,lastY:r<0?.99:-.99,start:+(new Date)});if(d){return}var a=e===document.body;var f=function(s){var o=+(new Date);var u=0;var l=0;for(var c=0;c<p.length;c++){var h=p[c];var v=o-h.start;var m=v>=t.animationTime;var g=m?1:v/t.animationTime;if(t.pulseAlgorithm){g=D(g)}var y=h.x*g-h.lastX>>0;var b=h.y*g-h.lastY>>0;u+=y;l+=b;h.lastX+=y;h.lastY+=b;if(m){p.splice(c,1);c--}}if(a){window.scrollBy(u,l)}else{if(u)e.scrollLeft+=u;if(l)e.scrollTop+=l}if(!n&&!r){p=[]}if(p.length){M(f,e,i/t.frameRate+1)}else{d=false}};M(f,e,0);d=true}function g(e){if(!s){h()}var n=e.target;var r=x(n);if(!r||e.defaultPrevented||C(u,"embed")||C(n,"embed")&&/\.pdf/i.test(n.src)){return true}var i=e.wheelDeltaX||0;var o=e.wheelDeltaY||0;if(!i&&!o){o=e.wheelDelta||0}if(!t.touchpadSupport&&A(o)){return true}if(Math.abs(i)>1.2){i*=t.stepSize/120}if(Math.abs(o)>1.2){o*=t.stepSize/120}m(r,-i,-o);e.preventDefault()}function y(e){var n=e.target;var r=e.ctrlKey||e.altKey||e.metaKey||e.shiftKey&&e.keyCode!==l.spacebar;if(/input|textarea|select|embed/i.test(n.nodeName)||n.isContentEditable||e.defaultPrevented||r){return true}if(C(n,"button")&&e.keyCode===l.spacebar){return true}var i,s=0,o=0;var a=x(u);var f=a.clientHeight;if(a==document.body){f=window.innerHeight}switch(e.keyCode){case l.up:o=-t.arrowScroll;break;case l.down:o=t.arrowScroll;break;case l.spacebar:i=e.shiftKey?1:-1;o=-i*f*.9;break;case l.pageup:o=-f*.9;break;case l.pagedown:o=f*.9;break;case l.home:o=-a.scrollTop;break;case l.end:var c=a.scrollHeight-a.scrollTop-f;o=c>0?c+10:0;break;case l.left:s=-t.arrowScroll;break;case l.right:s=t.arrowScroll;break;default:return true}m(a,s,o);e.preventDefault()}function b(e){u=e.target}function S(e,t){for(var n=e.length;n--;)w[E(e[n])]=t;return t}function x(e){var t=[];var n=o.scrollHeight;do{var i=w[E(e)];if(i){return S(t,i)}t.push(e);if(n===e.scrollHeight){if(!r||o.clientHeight+10<n){return S(t,document.body)}}else if(e.clientHeight+10<e.scrollHeight){overflow=getComputedStyle(e,"").getPropertyValue("overflow-y");if(overflow==="scroll"||overflow==="auto"){return S(t,e)}}}while(e=e.parentNode)}function T(e,t,n){window.addEventListener(e,t,n||false)}function N(e,t,n){window.removeEventListener(e,t,n||false)}function C(e,t){return(e.nodeName||"").toLowerCase()===t.toLowerCase()}function k(e,t){e=e>0?1:-1;t=t>0?1:-1;if(i.x!==e||i.y!==t){i.x=e;i.y=t;p=[];v=0}}function A(e){if(!e)return;e=Math.abs(e);f.push(e);f.shift();clearTimeout(L);var t=O(f[0],120)&&O(f[1],120)&&O(f[2],120);return!t}function O(e,t){return Math.floor(e/t)==e/t}function _(e){var n,r,i;e=e*t.pulseScale;if(e<1){n=e-(1-Math.exp(-e))}else{r=Math.exp(-1);e-=1;i=1-Math.exp(-e);n=r+i*(1-r)}return n*t.pulseNormalize}function D(e){if(e>=1)return 1;if(e<=0)return 0;if(t.pulseNormalize==1){t.pulseNormalize/=_(1)}return _(e)}var e={frameRate:150,animationTime:400,stepSize:120,pulseAlgorithm:true,pulseScale:8,pulseNormalize:1,accelerationDelta:20,accelerationMax:1,keyboardSupport:true,arrowScroll:50,touchpadSupport:true,fixedBackground:true,excluded:""};var t=e;var n=false;var r=false;var i={x:0,y:0};var s=false;var o=document.documentElement;var u;var a;var f=[120,120,120];var l={left:37,up:38,right:39,down:40,spacebar:32,pageup:33,pagedown:34,end:35,home:36};var t=e;var p=[];var d=false;var v=+(new Date);var w={};setInterval(function(){w={}},10*1e3);var E=function(){var e=0;return function(t){return t.uniqueID||(t.uniqueID=e++)}}();var L;var M=function(){return window.requestAnimationFrame||window.webkitRequestAnimationFrame||function(e,t,n){window.setTimeout(e,n||1e3/60)}}();var P=/chrome/i.test(window.navigator.userAgent);var H=null;if("onwheel"in document.createElement("div"))H="wheel";else if("onmousewheel"in document.createElement("div"))H="mousewheel";if(H&&P){T(H,g);T("mousedown",b);T("load",h)}}
//Modernizr 2.7.0
;window.Modernizr=function(a,b,c){function B(a){j.cssText=a}function C(a,b){return B(m.join(a+";")+(b||""))}function D(a,b){return typeof a===b}function E(a,b){return!!~(""+a).indexOf(b)}function F(a,b){for(var d in a){var e=a[d];if(!E(e,"-")&&j[e]!==c)return b=="pfx"?e:!0}return!1}function G(a,b,d){for(var e in a){var f=b[a[e]];if(f!==c)return d===!1?a[e]:D(f,"function")?f.bind(d||b):f}return!1}function H(a,b,c){var d=a.charAt(0).toUpperCase()+a.slice(1),e=(a+" "+o.join(d+" ")+d).split(" ");return D(b,"string")||D(b,"undefined")?F(e,b):(e=(a+" "+p.join(d+" ")+d).split(" "),G(e,b,c))}var d="2.7.0",e={},f=!0,g=b.documentElement,h="modernizr",i=b.createElement(h),j=i.style,k,l={}.toString,m=" -webkit- -moz- -o- -ms- ".split(" "),n="Webkit Moz O ms",o=n.split(" "),p=n.toLowerCase().split(" "),q={svg:"http://www.w3.org/2000/svg"},r={},s={},t={},u=[],v=u.slice,w,x=function(a,c,d,e){var f,i,j,k,l=b.createElement("div"),m=b.body,n=m||b.createElement("body");if(parseInt(d,10))while(d--)j=b.createElement("div"),j.id=e?e[d]:h+(d+1),l.appendChild(j);return f=["&#173;",'<style id="s',h,'">',a,"</style>"].join(""),l.id=h,(m?l:n).innerHTML+=f,n.appendChild(l),m||(n.style.background="",n.style.overflow="hidden",k=g.style.overflow,g.style.overflow="hidden",g.appendChild(n)),i=c(l,a),m?l.parentNode.removeChild(l):(n.parentNode.removeChild(n),g.style.overflow=k),!!i},y=function(b){var c=a.matchMedia||a.msMatchMedia;if(c)return c(b).matches;var d;return x("@media "+b+" { #"+h+" { position: absolute; } }",function(b){d=(a.getComputedStyle?getComputedStyle(b,null):b.currentStyle)["position"]=="absolute"}),d},z={}.hasOwnProperty,A;!D(z,"undefined")&&!D(z.call,"undefined")?A=function(a,b){return z.call(a,b)}:A=function(a,b){return b in a&&D(a.constructor.prototype[b],"undefined")},Function.prototype.bind||(Function.prototype.bind=function(b){var c=this;if(typeof c!="function")throw new TypeError;var d=v.call(arguments,1),e=function(){if(this instanceof e){var a=function(){};a.prototype=c.prototype;var f=new a,g=c.apply(f,d.concat(v.call(arguments)));return Object(g)===g?g:f}return c.apply(b,d.concat(v.call(arguments)))};return e}),r.touch=function(){var c;return"ontouchstart"in a||a.DocumentTouch&&b instanceof DocumentTouch?c=!0:x(["@media (",m.join("touch-enabled),("),h,")","{#modernizr{top:9px;position:absolute}}"].join(""),function(a){c=a.offsetTop===9}),c},r.csstransforms=function(){return!!H("transform")},r.csstransforms3d=function(){var a=!!H("perspective");return a&&"webkitPerspective"in g.style&&x("@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}",function(b,c){a=b.offsetLeft===9&&b.offsetHeight===3}),a},r.csstransitions=function(){return H("transition")},r.svg=function(){return!!b.createElementNS&&!!b.createElementNS(q.svg,"svg").createSVGRect};for(var I in r)A(r,I)&&(w=I.toLowerCase(),e[w]=r[I](),u.push((e[w]?"":"no-")+w));return e.addTest=function(a,b){if(typeof a=="object")for(var d in a)A(a,d)&&e.addTest(d,a[d]);else{a=a.toLowerCase();if(e[a]!==c)return e;b=typeof b=="function"?b():b,typeof f!="undefined"&&f&&(g.className+=" "+(b?"":"no-")+a),e[a]=b}return e},B(""),i=k=null,function(a,b){function l(a,b){var c=a.createElement("p"),d=a.getElementsByTagName("head")[0]||a.documentElement;return c.innerHTML="x<style>"+b+"</style>",d.insertBefore(c.lastChild,d.firstChild)}function m(){var a=s.elements;return typeof a=="string"?a.split(" "):a}function n(a){var b=j[a[h]];return b||(b={},i++,a[h]=i,j[i]=b),b}function o(a,c,d){c||(c=b);if(k)return c.createElement(a);d||(d=n(c));var g;return d.cache[a]?g=d.cache[a].cloneNode():f.test(a)?g=(d.cache[a]=d.createElem(a)).cloneNode():g=d.createElem(a),g.canHaveChildren&&!e.test(a)&&!g.tagUrn?d.frag.appendChild(g):g}function p(a,c){a||(a=b);if(k)return a.createDocumentFragment();c=c||n(a);var d=c.frag.cloneNode(),e=0,f=m(),g=f.length;for(;e<g;e++)d.createElement(f[e]);return d}function q(a,b){b.cache||(b.cache={},b.createElem=a.createElement,b.createFrag=a.createDocumentFragment,b.frag=b.createFrag()),a.createElement=function(c){return s.shivMethods?o(c,a,b):b.createElem(c)},a.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+m().join().replace(/[\w\-]+/g,function(a){return b.createElem(a),b.frag.createElement(a),'c("'+a+'")'})+");return n}")(s,b.frag)}function r(a){a||(a=b);var c=n(a);return s.shivCSS&&!g&&!c.hasCSS&&(c.hasCSS=!!l(a,"article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}")),k||q(a,c),a}var c="3.7.0",d=a.html5||{},e=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,f=/^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,g,h="_html5shiv",i=0,j={},k;(function(){try{var a=b.createElement("a");a.innerHTML="<xyz></xyz>",g="hidden"in a,k=a.childNodes.length==1||function(){b.createElement("a");var a=b.createDocumentFragment();return typeof a.cloneNode=="undefined"||typeof a.createDocumentFragment=="undefined"||typeof a.createElement=="undefined"}()}catch(c){g=!0,k=!0}})();var s={elements:d.elements||"abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",version:c,shivCSS:d.shivCSS!==!1,supportsUnknownElements:k,shivMethods:d.shivMethods!==!1,type:"default",shivDocument:r,createElement:o,createDocumentFragment:p};a.html5=s,r(b)}(this,b),e._version=d,e._prefixes=m,e._domPrefixes=p,e._cssomPrefixes=o,e.mq=y,e.testProp=function(a){return F([a])},e.testAllProps=H,e.testStyles=x,e.prefixed=function(a,b,c){return b?H(a,b,c):H(a,"pfx")},g.className=g.className.replace(/(^|\s)no-js(\s|$)/,"$1$2")+(f?" js "+u.join(" "):""),e}(this,this.document),function(a,b,c){function d(a){return"[object Function]"==o.call(a)}function e(a){return"string"==typeof a}function f(){}function g(a){return!a||"loaded"==a||"complete"==a||"uninitialized"==a}function h(){var a=p.shift();q=1,a?a.t?m(function(){("c"==a.t?B.injectCss:B.injectJs)(a.s,0,a.a,a.x,a.e,1)},0):(a(),h()):q=0}function i(a,c,d,e,f,i,j){function k(b){if(!o&&g(l.readyState)&&(u.r=o=1,!q&&h(),l.onload=l.onreadystatechange=null,b)){"img"!=a&&m(function(){t.removeChild(l)},50);for(var d in y[c])y[c].hasOwnProperty(d)&&y[c][d].onload()}}var j=j||B.errorTimeout,l=b.createElement(a),o=0,r=0,u={t:d,s:c,e:f,a:i,x:j};1===y[c]&&(r=1,y[c]=[]),"object"==a?l.data=c:(l.src=c,l.type=a),l.width=l.height="0",l.onerror=l.onload=l.onreadystatechange=function(){k.call(this,r)},p.splice(e,0,u),"img"!=a&&(r||2===y[c]?(t.insertBefore(l,s?null:n),m(k,j)):y[c].push(l))}function j(a,b,c,d,f){return q=0,b=b||"j",e(a)?i("c"==b?v:u,a,b,this.i++,c,d,f):(p.splice(this.i++,0,a),1==p.length&&h()),this}function k(){var a=B;return a.loader={load:j,i:0},a}var l=b.documentElement,m=a.setTimeout,n=b.getElementsByTagName("script")[0],o={}.toString,p=[],q=0,r="MozAppearance"in l.style,s=r&&!!b.createRange().compareNode,t=s?l:n.parentNode,l=a.opera&&"[object Opera]"==o.call(a.opera),l=!!b.attachEvent&&!l,u=r?"object":l?"script":"img",v=l?"script":u,w=Array.isArray||function(a){return"[object Array]"==o.call(a)},x=[],y={},z={timeout:function(a,b){return b.length&&(a.timeout=b[0]),a}},A,B;B=function(a){function b(a){var a=a.split("!"),b=x.length,c=a.pop(),d=a.length,c={url:c,origUrl:c,prefixes:a},e,f,g;for(f=0;f<d;f++)g=a[f].split("="),(e=z[g.shift()])&&(c=e(c,g));for(f=0;f<b;f++)c=x[f](c);return c}function g(a,e,f,g,h){var i=b(a),j=i.autoCallback;i.url.split(".").pop().split("?").shift(),i.bypass||(e&&(e=d(e)?e:e[a]||e[g]||e[a.split("/").pop().split("?")[0]]),i.instead?i.instead(a,e,f,g,h):(y[i.url]?i.noexec=!0:y[i.url]=1,f.load(i.url,i.forceCSS||!i.forceJS&&"css"==i.url.split(".").pop().split("?").shift()?"c":c,i.noexec,i.attrs,i.timeout),(d(e)||d(j))&&f.load(function(){k(),e&&e(i.origUrl,h,g),j&&j(i.origUrl,h,g),y[i.url]=2})))}function h(a,b){function c(a,c){if(a){if(e(a))c||(j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}),g(a,j,b,0,h);else if(Object(a)===a)for(n in m=function(){var b=0,c;for(c in a)a.hasOwnProperty(c)&&b++;return b}(),a)a.hasOwnProperty(n)&&(!c&&!--m&&(d(j)?j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}:j[n]=function(a){return function(){var b=[].slice.call(arguments);a&&a.apply(this,b),l()}}(k[n])),g(a[n],j,b,n,h))}else!c&&l()}var h=!!a.test,i=a.load||a.both,j=a.callback||f,k=j,l=a.complete||f,m,n;c(h?a.yep:a.nope,!!i),i&&c(i)}var i,j,l=this.yepnope.loader;if(e(a))g(a,0,l,0);else if(w(a))for(i=0;i<a.length;i++)j=a[i],e(j)?g(j,0,l,0):w(j)?B(j):Object(j)===j&&h(j,l);else Object(a)===a&&h(a,l)},B.addPrefix=function(a,b){z[a]=b},B.addFilter=function(a){x.push(a)},B.errorTimeout=1e4,null==b.readyState&&b.addEventListener&&(b.readyState="loading",b.addEventListener("DOMContentLoaded",A=function(){b.removeEventListener("DOMContentLoaded",A,0),b.readyState="complete"},0)),a.yepnope=k(),a.yepnope.executeStack=h,a.yepnope.injectJs=function(a,c,d,e,i,j){var k=b.createElement("script"),l,o,e=e||B.errorTimeout;k.src=a;for(o in d)k.setAttribute(o,d[o]);c=j?h:c||f,k.onreadystatechange=k.onload=function(){!l&&g(k.readyState)&&(l=1,c(),k.onload=k.onreadystatechange=null)},m(function(){l||(l=1,c(1))},e),i?k.onload():n.parentNode.insertBefore(k,n)},a.yepnope.injectCss=function(a,c,d,e,g,i){var e=b.createElement("link"),j,c=i?h:c||f;e.href=a,e.rel="stylesheet",e.type="text/css";for(j in d)e.setAttribute(j,d[j]);g||(n.parentNode.insertBefore(e,n),m(c,0))}}(this,document),Modernizr.load=function(){yepnope.apply(window,[].slice.call(arguments,0))};
//jQuery Easing v1.3
jQuery.easing["jswing"]=jQuery.easing["swing"];jQuery.extend(jQuery.easing,{def:"easeOutQuad",swing:function(a,b,c,d,e){return jQuery.easing[jQuery.easing.def](a,b,c,d,e)},easeInQuad:function(a,b,c,d,e){return d*(b/=e)*b+c},easeOutQuad:function(a,b,c,d,e){return-d*(b/=e)*(b-2)+c},easeInOutQuad:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b+c;return-d/2*(--b*(b-2)-1)+c},easeInCubic:function(a,b,c,d,e){return d*(b/=e)*b*b+c},easeOutCubic:function(a,b,c,d,e){return d*((b=b/e-1)*b*b+1)+c},easeInOutCubic:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b*b+c;return d/2*((b-=2)*b*b+2)+c},easeInQuart:function(a,b,c,d,e){return d*(b/=e)*b*b*b+c},easeOutQuart:function(a,b,c,d,e){return-d*((b=b/e-1)*b*b*b-1)+c},easeInOutQuart:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b*b*b+c;return-d/2*((b-=2)*b*b*b-2)+c},easeInQuint:function(a,b,c,d,e){return d*(b/=e)*b*b*b*b+c},easeOutQuint:function(a,b,c,d,e){return d*((b=b/e-1)*b*b*b*b+1)+c},easeInOutQuint:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b*b*b*b+c;return d/2*((b-=2)*b*b*b*b+2)+c},easeInSine:function(a,b,c,d,e){return-d*Math.cos(b/e*(Math.PI/2))+d+c},easeOutSine:function(a,b,c,d,e){return d*Math.sin(b/e*(Math.PI/2))+c},easeInOutSine:function(a,b,c,d,e){return-d/2*(Math.cos(Math.PI*b/e)-1)+c},easeInExpo:function(a,b,c,d,e){return b==0?c:d*Math.pow(2,10*(b/e-1))+c},easeOutExpo:function(a,b,c,d,e){return b==e?c+d:d*(-Math.pow(2,-10*b/e)+1)+c},easeInOutExpo:function(a,b,c,d,e){if(b==0)return c;if(b==e)return c+d;if((b/=e/2)<1)return d/2*Math.pow(2,10*(b-1))+c;return d/2*(-Math.pow(2,-10*--b)+2)+c},easeInCirc:function(a,b,c,d,e){return-d*(Math.sqrt(1-(b/=e)*b)-1)+c},easeOutCirc:function(a,b,c,d,e){return d*Math.sqrt(1-(b=b/e-1)*b)+c},easeInOutCirc:function(a,b,c,d,e){if((b/=e/2)<1)return-d/2*(Math.sqrt(1-b*b)-1)+c;return d/2*(Math.sqrt(1-(b-=2)*b)+1)+c},easeInElastic:function(a,b,c,d,e){var f=1.70158;var g=0;var h=d;if(b==0)return c;if((b/=e)==1)return c+d;if(!g)g=e*.3;if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);return-(h*Math.pow(2,10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g))+c},easeOutElastic:function(a,b,c,d,e){var f=1.70158;var g=0;var h=d;if(b==0)return c;if((b/=e)==1)return c+d;if(!g)g=e*.3;if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);return h*Math.pow(2,-10*b)*Math.sin((b*e-f)*2*Math.PI/g)+d+c},easeInOutElastic:function(a,b,c,d,e){var f=1.70158;var g=0;var h=d;if(b==0)return c;if((b/=e/2)==2)return c+d;if(!g)g=e*.3*1.5;if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);if(b<1)return-.5*h*Math.pow(2,10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g)+c;return h*Math.pow(2,-10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g)*.5+d+c},easeInBack:function(a,b,c,d,e,f){if(f==undefined)f=1.70158;return d*(b/=e)*b*((f+1)*b-f)+c},easeOutBack:function(a,b,c,d,e,f){if(f==undefined)f=1.70158;return d*((b=b/e-1)*b*((f+1)*b+f)+1)+c},easeInOutBack:function(a,b,c,d,e,f){if(f==undefined)f=1.70158;if((b/=e/2)<1)return d/2*b*b*(((f*=1.525)+1)*b-f)+c;return d/2*((b-=2)*b*(((f*=1.525)+1)*b+f)+2)+c},easeInBounce:function(a,b,c,d,e){return d-jQuery.easing.easeOutBounce(a,e-b,0,d,e)+c},easeOutBounce:function(a,b,c,d,e){if((b/=e)<1/2.75){return d*7.5625*b*b+c}else if(b<2/2.75){return d*(7.5625*(b-=1.5/2.75)*b+.75)+c}else if(b<2.5/2.75){return d*(7.5625*(b-=2.25/2.75)*b+.9375)+c}else{return d*(7.5625*(b-=2.625/2.75)*b+.984375)+c}},easeInOutBounce:function(a,b,c,d,e){if(b<e/2)return jQuery.easing.easeInBounce(a,b*2,0,d,e)*.5+c;return jQuery.easing.easeOutBounce(a,b*2-e,0,d,e)*.5+d*.5+c}});
//ELASTIC IMAGE SLIDESHOW
//tipsy
(function(a){function b(a,b){return typeof a=="function"?a.call(b):a}function c(a){while(a=a.parentNode){if(a==document)return true}return false}function d(b,c){this.$element=a(b);this.options=c;this.enabled=true;this.fixTitle()}d.prototype={show:function(){var c=this.getTitle();if(c&&this.enabled){var d=this.tip();d.find(".tipsy-inner")[this.options.html?"html":"text"](c);d[0].className="tipsy";d.remove().css({top:0,left:0,visibility:"hidden",display:"block"}).prependTo(document.body);var e=a.extend({},this.$element.offset(),{width:this.$element[0].offsetWidth,height:this.$element[0].offsetHeight});var f=d[0].offsetWidth,g=d[0].offsetHeight,h=b(this.options.gravity,this.$element[0]);var i;switch(h.charAt(0)){case"n":i={top:e.top+e.height+this.options.offset,left:e.left+e.width/2-f/2};break;case"s":i={top:e.top-g-this.options.offset,left:e.left+e.width/2-f/2};break;case"e":i={top:e.top+e.height/2-g/2,left:e.left-f-this.options.offset};break;case"w":i={top:e.top+e.height/2-g/2,left:e.left+e.width+this.options.offset};break}if(h.length==2){if(h.charAt(1)=="w"){i.left=e.left+e.width/2-15}else{i.left=e.left+e.width/2-f+15}}d.css(i).addClass("tipsy-"+h);d.find(".tipsy-arrow")[0].className="tipsy-arrow tipsy-arrow-"+h.charAt(0);if(this.options.className){d.addClass(b(this.options.className,this.$element[0]))}if(this.options.fade){d.stop().css({opacity:0,display:"block",visibility:"visible"}).animate({opacity:this.options.opacity})}else{d.css({visibility:"visible",opacity:this.options.opacity})}}},hide:function(){if(this.options.fade){this.tip().stop().fadeOut(function(){a(this).remove()})}else{this.tip().remove()}},fixTitle:function(){var a=this.$element;if(a.attr("title")||typeof a.attr("original-title")!="string"){a.attr("original-title",a.attr("title")||"").removeAttr("title")}},getTitle:function(){var a,b=this.$element,c=this.options;this.fixTitle();var a,c=this.options;if(typeof c.title=="string"){a=b.attr(c.title=="title"?"original-title":c.title)}else if(typeof c.title=="function"){a=c.title.call(b[0])}a=(""+a).replace(/(^\s*|\s*$)/,"");return a||c.fallback},tip:function(){if(!this.$tip){this.$tip=a('<div class="tipsy"></div>').html('<div class="tipsy-arrow"></div><div class="tipsy-inner"></div>');this.$tip.data("tipsy-pointee",this.$element[0])}return this.$tip},validate:function(){if(!this.$element[0].parentNode){this.hide();this.$element=null;this.options=null}},enable:function(){this.enabled=true},disable:function(){this.enabled=false},toggleEnabled:function(){this.enabled=!this.enabled}};a.fn.tipsy=function(b){function e(c){var e=a.data(c,"tipsy");if(!e){e=new d(c,a.fn.tipsy.elementOptions(c,b));a.data(c,"tipsy",e)}return e}function f(){var a=e(this);a.hoverState="in";if(b.delayIn==0){a.show()}else{a.fixTitle();setTimeout(function(){if(a.hoverState=="in")a.show()},b.delayIn)}}function g(){var a=e(this);a.hoverState="out";if(b.delayOut==0){a.hide()}else{setTimeout(function(){if(a.hoverState=="out")a.hide()},b.delayOut)}}if(b===true){return this.data("tipsy")}else if(typeof b=="string"){var c=this.data("tipsy");if(c)c[b]();return this}b=a.extend({},a.fn.tipsy.defaults,b);if(!b.live)this.each(function(){e(this)});if(b.trigger!="manual"){var h=b.live?"live":"bind",i=b.trigger=="hover"?"mouseenter":"focus",j=b.trigger=="hover"?"mouseleave":"blur";this[h](i,f)[h](j,g)}return this};a.fn.tipsy.defaults={className:null,delayIn:0,delayOut:0,fade:false,fallback:"",gravity:"n",html:false,live:false,offset:0,opacity:.8,title:"title",trigger:"hover"};a.fn.tipsy.revalidate=function(){a(".tipsy").each(function(){var b=a.data(this,"tipsy-pointee");if(!b||!c(b)){a(this).remove()}})};a.fn.tipsy.elementOptions=function(b,c){return a.metadata?a.extend({},c,a(b).metadata()):c};a.fn.tipsy.autoNS=function(){return a(this).offset().top>a(document).scrollTop()+a(window).height()/2?"s":"n"};a.fn.tipsy.autoWE=function(){return a(this).offset().left>a(document).scrollLeft()+a(window).width()/2?"e":"w"};a.fn.tipsy.autoBounds=function(b,c){return function(){var d={ns:c[0],ew:c.length>1?c[1]:false},e=a(document).scrollTop()+b,f=a(document).scrollLeft()+b,g=a(this);if(g.offset().top<e)d.ns="n";if(g.offset().left<f)d.ew="w";if(a(window).width()+a(document).scrollLeft()-g.offset().left<b)d.ew="e";if(a(window).height()+a(document).scrollTop()-g.offset().top<b)d.ns="s";return d.ns+(d.ew?d.ew:"")}}})(jQuery);
//innerfade
(function($){var default_options={animationType:"fade",animate:true,first_slide:0,easing:"linear",speed:"normal",type:"sequence",timeout:2e3,startDelay:0,loop:true,containerHeight:"auto",runningClass:"innerFade",children:null,cancelLink:null,pauseLink:null,prevLink:null,nextLink:null,indexContainer:null,currentItemContainer:null,totalItemsContainer:null,callback_index_update:null};$(function(){window.isActive=true;$(window).focus(function(){this.isActive=true});$(window).blur(function(){this.isActive=false})});$.fn.innerFade=function(options){return this.each(function(){$fade_object=new Object;$fade_object.container=this;$fade_object.settings=$.extend({},default_options,options);$fade_object.elements=$fade_object.settings.children===null?$($fade_object.container).children():$($fade_object.container).children($fade_object.settings.children);$fade_object.count=0;$($fade_object.container).data("object",$fade_object);if($fade_object.elements.length>1){if($fade_object.settings.nextLink||$fade_object.settings.prevLink){$.bindControls($fade_object)}if($fade_object.settings.cancelLink){$.bindCancel($fade_object)}$($fade_object.container).css({position:"relative"}).addClass($fade_object.settings.runningClass);if($fade_object.settings.containerHeight=="auto"){height=$($fade_object.elements).filter(":first").height();$($fade_object.container).css({height:height+"px"})}else{$($fade_object.container).css({height:$fade_object.settings.containerHeight})}if($fade_object.settings.indexContainer){$.innerFadeIndex($fade_object)}for(var i=0;i<$fade_object.elements.length;i++){$($fade_object.elements[i]).hide(0).css("z-index",String($fade_object.elements.length-i)).css("position","absolute")}var toShow="";var toHide="";if($fade_object.settings.type=="random"){toShow=Math.floor(Math.random()*$fade_object.elements.length);do{toHide=Math.floor(Math.random()*$fade_object.elements.length)}while(toHide==toShow)}else if($fade_object.settings.type=="random_start"){$fade_object.settings.type="sequence";toHide=Math.floor(Math.random()*$fade_object.elements.length);toShow=(toHide+1)%$fade_object.elements.length}else{toShow=$fade_object.settings.first_slide;toHide=$fade_object.settings.first_slide==0?$fade_object.elements.length-1:$fade_object.settings.first_slide-1}if($fade_object.settings.animate){$.fadeTimeout($fade_object,toShow,toHide,true)}else{$($fade_object.elements[toShow]).show();$($fade_object.elements[toHide]).hide();$.updateIndexes($fade_object,toShow)}$.updateIndexes($fade_object,toShow);$($fade_object.elements[toShow]).show();if($fade_object.settings.currentItemContainer){$.currentItem($fade_object,toShow)}if($fade_object.settings.totalItemsContainer){$.totalItems($fade_object)}if($fade_object.settings.pauseLink){$.bind_pause($fade_object)}}})};$.fn.innerFadeTo=function(slide_number){return this.each(function(index){var $fade_object=$(this).data("object");var $currentVisibleItem=$($fade_object.elements).filter(":visible");var currentItemIndex=$($fade_object.elements).index($currentVisibleItem);$.stopSlideshow($fade_object);if(slide_number!=currentItemIndex){$.fadeToItem($fade_object,slide_number,currentItemIndex)}})};$.fadeToItem=function($fade_object,toShow,toHide){var speed=$fade_object.settings.speed;switch($fade_object.settings.animationType){case"slide":$($fade_object.elements[toHide]).slideUp(speed);$($fade_object.elements[toShow]).slideDown(speed);break;case"slideOver":var itemWidth=$($fade_object.elements[0]).width(),to_hide_css={},to_show_css={},to_hide_animation={},to_show_animation={};$($fade_object.container).css({overflow:"hidden"});to_hide_css={position:"absolute",top:"0px"};to_show_css=$.extend({},to_hide_css);if(toShow>toHide){to_hide_css.left="0px";to_hide_css.right="auto";to_show_css.left="auto";to_show_css.right="-"+itemWidth+"px";to_hide_animation.left="-"+itemWidth+"px";to_show_animation.right="0px";console.log(to_hide_css)}else{to_hide_css.left="auto";to_hide_css.right="0px";to_show_css.left="-"+itemWidth+"px";to_show_css.right="auto";to_hide_animation.right="-"+itemWidth+"px";to_show_animation.left="0px"};$($fade_object.elements[toHide]).css(to_hide_css);$($fade_object.elements[toShow]).css(to_show_css).show();$($fade_object.elements[toHide]).animate(to_hide_animation,speed,$fade_object.settings.easing,function(){$(this).hide()});$($fade_object.elements[toShow]).animate(to_show_animation,speed,$fade_object.settings.easing);break;case"fadeEmpty":$($fade_object.elements[toHide]).fadeOut(speed,function(){$($fade_object.elements[toShow]).fadeIn(speed)});break;case"slideEmpty":$($fade_object.elements[toHide]).slideUp(speed,function(){$($fade_object.elements[toShow]).slideDown(speed)});break;default:$($fade_object.elements[toHide]).fadeOut(speed);$($fade_object.elements[toShow]).fadeIn(speed);break}if($fade_object.settings.currentItemContainer){$.currentItem($fade_object,toShow)}if($fade_object.settings.indexContainer||$fade_object.settings.callback_index_update){$.updateIndexes($fade_object,toShow)}};$.fadeTimeout=function($fade_object,toShow,toHide,firstRun){if(window.isActive){if(firstRun!=true){$.fadeToItem($fade_object,toShow,toHide)}$fade_object.count++;if($fade_object.settings.loop==false&&$fade_object.count>=$fade_object.elements.length){$.stopSlideshow($fade_object);return}if($fade_object.settings.type=="random"){toHide=toShow;while(toShow==toHide){toShow=Math.floor(Math.random()*$fade_object.elements.length)}}else{toHide=toHide>toShow?0:toShow;toShow=toShow+1>=$fade_object.elements.length?0:toShow+1}}var timeout=firstRun&&$fade_object.settings.startDelay?$fade_object.settings.startDelay:$fade_object.settings.timeout;$($fade_object.container).data("current_timeout",setTimeout(function(){$.fadeTimeout($fade_object,toShow,toHide,false)},timeout))};$.fn.innerFadeUnbind=function(){return this.each(function(index){var $fade_object=$(this).data("object");$.stopSlideshow($fade_object)})};$.stopSlideshow=function($fade_object){clearTimeout($($fade_object.container).data("current_timeout"));$($fade_object.container).data("current_timeout",null)};$.bindControls=function($fade_object){$($fade_object.settings.nextLink).on("click",function(event){event.preventDefault();$.stopSlideshow($fade_object);var $currentElement=$($fade_object.elements).filter(":visible");var currentElementIndex=$($fade_object.elements).index($currentElement);var $nextElement=$currentElement.next().length>0?$currentElement.next():$($fade_object.elements).filter(":first");var nextElementIndex=$($fade_object.elements).index($nextElement);$.fadeToItem($fade_object,nextElementIndex,currentElementIndex)});$($fade_object.settings.prevLink).on("click",function(event){event.preventDefault();$.stopSlideshow($fade_object);var $currentElement=$($fade_object.elements).filter(":visible");var currentElementIndex=$($fade_object.elements).index($currentElement);var $previousElement=$currentElement.prev().length>0?$currentElement.prev():$($fade_object.elements).filter(":last");var previousElementIndex=$($fade_object.elements).index($previousElement);$.fadeToItem($fade_object,previousElementIndex,currentElementIndex)})};$.bind_pause=function($fade_object){$($fade_object.settings.pauseLink).unbind().click(function(event){event.preventDefault();if($($fade_object.container).data("current_timeout")!=null){$.stopSlideshow($fade_object)}else{var tag=$($fade_object.container).children(":first").prop("tagName").toLowerCase();var nextItem="";var previousItem="";if($fade_object.settings.type=="random"){previousItem=Math.floor(Math.random()*$fade_object.elements.length);do{nextItem=Math.floor(Math.random()*$fade_object.elements.length)}while(previousItem==nextItem)}else if($fade_object.settings.type=="random_start"){previousItem=Math.floor(Math.random()*$fade_object.elements.length);nextItem=(previousItem+1)%$fade_object.elements.length}else{previousItem=$(tag,$($fade_object.container)).index($(tag+":visible",$($fade_object.container)));nextItem=previousItem+1==$fade_object.elements.length?0:previousItem+1}$.fadeTimeout($fade_object,nextItem,previousItem,false)}})};$.bindCancel=function($fade_object){$($fade_object.settings.cancelLink).unbind().click(function(event){event.preventDefault();$.stopSlideshow($fade_object)})};$.updateIndexes=function($fade_object,toShow){$($fade_object.settings.indexContainer).children().removeClass("active");$("> :eq("+toShow+")",$($fade_object.settings.indexContainer)).addClass("active");if(typeof $fade_object.settings.callback_index_update=="function"){$fade_object.settings.callback_index_update.call(this,toShow)}};$.createIndexHandler=function($fade_object,count,link){$(link).click(function(event){event.preventDefault();var $currentVisibleItem=$($fade_object.elements).filter(":visible");var currentItemIndex=$($fade_object.elements).index($currentVisibleItem);$.stopSlideshow($fade_object);if($currentVisibleItem.size()<=1&&count!=currentItemIndex){$.fadeToItem($fade_object,count,currentItemIndex)}})};$.createIndexes=function($fade_object){var $indexContainer=$($fade_object.settings.indexContainer);for(var i=0;i<$fade_object.elements.length;i++){var $link=$('<li><a href="#">'+(i+1)+"</a></li>");$.createIndexHandler($fade_object,i,$link);$indexContainer.append($link)}};$.linkIndexes=function($fade_object){var $indexContainer=$($fade_object.settings.indexContainer);var $indexContainerChildren=$("> :visible",$indexContainer);if($indexContainerChildren.size()==$fade_object.elements.length){var count=$fade_object.elements.length;for(var i=0;i<count;i++){$("a",$indexContainer).click(function(event){event.preventDefault()});$.createIndexHandler($fade_object,i,$indexContainerChildren[i])}}else{alert("There is a different number of items in the menu and slides. There needs to be the same number in both.\nThere are "+$indexContainerChildren.size()+" in the indexContainer.\nThere are "+$fade_object.elements.length+" in the slides container.")}};$.innerFadeIndex=function($fade_object){var $indexContainer=$($fade_object.settings.indexContainer);if($(":visible",$indexContainer).size()<=0){$.createIndexes($fade_object)}else{$.linkIndexes($fade_object)}};$.currentItem=function($fade_object,current){var $container=$($fade_object.settings.currentItemContainer);$container.text(current+1)};$.totalItems=function($fade_object){var $container=$($fade_object.settings.totalItemsContainer);$container.text($fade_object.elements.length)}})(jQuery);
//jQuery FlexSlider v2.5.0  Copyright 2012 WooThemes Contributing Author: Tyler Smith
!function($){$.flexslider=function(e,t){var a=$(e);a.vars=$.extend({},$.flexslider.defaults,t);var n=a.vars.namespace,i=window.navigator&&window.navigator.msPointerEnabled&&window.MSGesture,s=("ontouchstart"in window||i||window.DocumentTouch&&document instanceof DocumentTouch)&&a.vars.touch,r="click touchend MSPointerUp keyup",o="",l,c="vertical"===a.vars.direction,d=a.vars.reverse,u=a.vars.itemWidth>0,v="fade"===a.vars.animation,p=""!==a.vars.asNavFor,m={},f=!0;$.data(e,"flexslider",a),m={init:function(){a.animating=!1,a.currentSlide=parseInt(a.vars.startAt?a.vars.startAt:0,10),isNaN(a.currentSlide)&&(a.currentSlide=0),a.animatingTo=a.currentSlide,a.atEnd=0===a.currentSlide||a.currentSlide===a.last,a.containerSelector=a.vars.selector.substr(0,a.vars.selector.search(" ")),a.slides=$(a.vars.selector,a),a.container=$(a.containerSelector,a),a.count=a.slides.length,a.syncExists=$(a.vars.sync).length>0,"slide"===a.vars.animation&&(a.vars.animation="swing"),a.prop=c?"top":"marginLeft",a.args={},a.manualPause=!1,a.stopped=!1,a.started=!1,a.startTimeout=null,a.transitions=!a.vars.video&&!v&&a.vars.useCSS&&function(){var e=document.createElement("div"),t=["perspectiveProperty","WebkitPerspective","MozPerspective","OPerspective","msPerspective"];for(var n in t)if(void 0!==e.style[t[n]])return a.pfx=t[n].replace("Perspective","").toLowerCase(),a.prop="-"+a.pfx+"-transform",!0;return!1}(),a.ensureAnimationEnd="",""!==a.vars.controlsContainer&&(a.controlsContainer=$(a.vars.controlsContainer).length>0&&$(a.vars.controlsContainer)),""!==a.vars.manualControls&&(a.manualControls=$(a.vars.manualControls).length>0&&$(a.vars.manualControls)),""!==a.vars.customDirectionNav&&(a.customDirectionNav=2===$(a.vars.customDirectionNav).length&&$(a.vars.customDirectionNav)),a.vars.randomize&&(a.slides.sort(function(){return Math.round(Math.random())-.5}),a.container.empty().append(a.slides)),a.doMath(),a.setup("init"),a.vars.controlNav&&m.controlNav.setup(),a.vars.directionNav&&m.directionNav.setup(),a.vars.keyboard&&(1===$(a.containerSelector).length||a.vars.multipleKeyboard)&&$(document).bind("keyup",function(e){var t=e.keyCode;if(!a.animating&&(39===t||37===t)){var n=39===t?a.getTarget("next"):37===t?a.getTarget("prev"):!1;a.flexAnimate(n,a.vars.pauseOnAction)}}),a.vars.mousewheel&&a.bind("mousewheel",function(e,t,n,i){e.preventDefault();var s=a.getTarget(0>t?"next":"prev");a.flexAnimate(s,a.vars.pauseOnAction)}),a.vars.pausePlay&&m.pausePlay.setup(),a.vars.slideshow&&a.vars.pauseInvisible&&m.pauseInvisible.init(),a.vars.slideshow&&(a.vars.pauseOnHover&&a.hover(function(){a.manualPlay||a.manualPause||a.pause()},function(){a.manualPause||a.manualPlay||a.stopped||a.play()}),a.vars.pauseInvisible&&m.pauseInvisible.isHidden()||(a.vars.initDelay>0?a.startTimeout=setTimeout(a.play,a.vars.initDelay):a.play())),p&&m.asNav.setup(),s&&a.vars.touch&&m.touch(),(!v||v&&a.vars.smoothHeight)&&$(window).bind("resize orientationchange focus",m.resize),a.find("img").attr("draggable","false"),setTimeout(function(){a.vars.start(a)},200)},asNav:{setup:function(){a.asNav=!0,a.animatingTo=Math.floor(a.currentSlide/a.move),a.currentItem=a.currentSlide,a.slides.removeClass(n+"active-slide").eq(a.currentItem).addClass(n+"active-slide"),i?(e._slider=a,a.slides.each(function(){var e=this;e._gesture=new MSGesture,e._gesture.target=e,e.addEventListener("MSPointerDown",function(e){e.preventDefault(),e.currentTarget._gesture&&e.currentTarget._gesture.addPointer(e.pointerId)},!1),e.addEventListener("MSGestureTap",function(e){e.preventDefault();var t=$(this),n=t.index();$(a.vars.asNavFor).data("flexslider").animating||t.hasClass("active")||(a.direction=a.currentItem<n?"next":"prev",a.flexAnimate(n,a.vars.pauseOnAction,!1,!0,!0))})})):a.slides.on(r,function(e){e.preventDefault();var t=$(this),i=t.index(),s=t.offset().left-$(a).scrollLeft();0>=s&&t.hasClass(n+"active-slide")?a.flexAnimate(a.getTarget("prev"),!0):$(a.vars.asNavFor).data("flexslider").animating||t.hasClass(n+"active-slide")||(a.direction=a.currentItem<i?"next":"prev",a.flexAnimate(i,a.vars.pauseOnAction,!1,!0,!0))})}},controlNav:{setup:function(){a.manualControls?m.controlNav.setupManual():m.controlNav.setupPaging()},setupPaging:function(){var e="thumbnails"===a.vars.controlNav?"control-thumbs":"control-paging",t=1,i,s;if(a.controlNavScaffold=$('<ol class="'+n+"control-nav "+n+e+'"></ol>'),a.pagingCount>1)for(var l=0;l<a.pagingCount;l++){if(s=a.slides.eq(l),i="thumbnails"===a.vars.controlNav?'<img src="'+s.attr("data-thumb")+'"/>':"<a>"+t+"</a>","thumbnails"===a.vars.controlNav&&!0===a.vars.thumbCaptions){var c=s.attr("data-thumbcaption");""!==c&&void 0!==c&&(i+='<span class="'+n+'caption">'+c+"</span>")}a.controlNavScaffold.append("<li>"+i+"</li>"),t++}a.controlsContainer?$(a.controlsContainer).append(a.controlNavScaffold):a.append(a.controlNavScaffold),m.controlNav.set(),m.controlNav.active(),a.controlNavScaffold.delegate("a, img",r,function(e){if(e.preventDefault(),""===o||o===e.type){var t=$(this),i=a.controlNav.index(t);t.hasClass(n+"active")||(a.direction=i>a.currentSlide?"next":"prev",a.flexAnimate(i,a.vars.pauseOnAction))}""===o&&(o=e.type),m.setToClearWatchedEvent()})},setupManual:function(){a.controlNav=a.manualControls,m.controlNav.active(),a.controlNav.bind(r,function(e){if(e.preventDefault(),""===o||o===e.type){var t=$(this),i=a.controlNav.index(t);t.hasClass(n+"active")||(a.direction=i>a.currentSlide?"next":"prev",a.flexAnimate(i,a.vars.pauseOnAction))}""===o&&(o=e.type),m.setToClearWatchedEvent()})},set:function(){var e="thumbnails"===a.vars.controlNav?"img":"a";a.controlNav=$("."+n+"control-nav li "+e,a.controlsContainer?a.controlsContainer:a)},active:function(){a.controlNav.removeClass(n+"active").eq(a.animatingTo).addClass(n+"active")},update:function(e,t){a.pagingCount>1&&"add"===e?a.controlNavScaffold.append($("<li><a>"+a.count+"</a></li>")):1===a.pagingCount?a.controlNavScaffold.find("li").remove():a.controlNav.eq(t).closest("li").remove(),m.controlNav.set(),a.pagingCount>1&&a.pagingCount!==a.controlNav.length?a.update(t,e):m.controlNav.active()}},directionNav:{setup:function(){var e=$('<ul class="'+n+'direction-nav"><li class="'+n+'nav-prev"><a class="'+n+'prev" href="#">'+a.vars.prevText+'</a></li><li class="'+n+'nav-next"><a class="'+n+'next" href="#">'+a.vars.nextText+"</a></li></ul>");a.customDirectionNav?a.directionNav=a.customDirectionNav:a.controlsContainer?($(a.controlsContainer).append(e),a.directionNav=$("."+n+"direction-nav li a",a.controlsContainer)):(a.append(e),a.directionNav=$("."+n+"direction-nav li a",a)),m.directionNav.update(),a.directionNav.bind(r,function(e){e.preventDefault();var t;(""===o||o===e.type)&&(t=a.getTarget($(this).hasClass(n+"next")?"next":"prev"),a.flexAnimate(t,a.vars.pauseOnAction)),""===o&&(o=e.type),m.setToClearWatchedEvent()})},update:function(){var e=n+"disabled";1===a.pagingCount?a.directionNav.addClass(e).attr("tabindex","-1"):a.vars.animationLoop?a.directionNav.removeClass(e).removeAttr("tabindex"):0===a.animatingTo?a.directionNav.removeClass(e).filter("."+n+"prev").addClass(e).attr("tabindex","-1"):a.animatingTo===a.last?a.directionNav.removeClass(e).filter("."+n+"next").addClass(e).attr("tabindex","-1"):a.directionNav.removeClass(e).removeAttr("tabindex")}},pausePlay:{setup:function(){var e=$('<div class="'+n+'pauseplay"><a></a></div>');a.controlsContainer?(a.controlsContainer.append(e),a.pausePlay=$("."+n+"pauseplay a",a.controlsContainer)):(a.append(e),a.pausePlay=$("."+n+"pauseplay a",a)),m.pausePlay.update(a.vars.slideshow?n+"pause":n+"play"),a.pausePlay.bind(r,function(e){e.preventDefault(),(""===o||o===e.type)&&($(this).hasClass(n+"pause")?(a.manualPause=!0,a.manualPlay=!1,a.pause()):(a.manualPause=!1,a.manualPlay=!0,a.play())),""===o&&(o=e.type),m.setToClearWatchedEvent()})},update:function(e){"play"===e?a.pausePlay.removeClass(n+"pause").addClass(n+"play").html(a.vars.playText):a.pausePlay.removeClass(n+"play").addClass(n+"pause").html(a.vars.pauseText)}},touch:function(){function t(t){t.stopPropagation(),a.animating?t.preventDefault():(a.pause(),e._gesture.addPointer(t.pointerId),w=0,p=c?a.h:a.w,f=Number(new Date),l=u&&d&&a.animatingTo===a.last?0:u&&d?a.limit-(a.itemW+a.vars.itemMargin)*a.move*a.animatingTo:u&&a.currentSlide===a.last?a.limit:u?(a.itemW+a.vars.itemMargin)*a.move*a.currentSlide:d?(a.last-a.currentSlide+a.cloneOffset)*p:(a.currentSlide+a.cloneOffset)*p)}function n(t){t.stopPropagation();var a=t.target._slider;if(a){var n=-t.translationX,i=-t.translationY;return w+=c?i:n,m=w,y=c?Math.abs(w)<Math.abs(-n):Math.abs(w)<Math.abs(-i),t.detail===t.MSGESTURE_FLAG_INERTIA?void setImmediate(function(){e._gesture.stop()}):void((!y||Number(new Date)-f>500)&&(t.preventDefault(),!v&&a.transitions&&(a.vars.animationLoop||(m=w/(0===a.currentSlide&&0>w||a.currentSlide===a.last&&w>0?Math.abs(w)/p+2:1)),a.setProps(l+m,"setTouch"))))}}function s(e){e.stopPropagation();var t=e.target._slider;if(t){if(t.animatingTo===t.currentSlide&&!y&&null!==m){var a=d?-m:m,n=t.getTarget(a>0?"next":"prev");t.canAdvance(n)&&(Number(new Date)-f<550&&Math.abs(a)>50||Math.abs(a)>p/2)?t.flexAnimate(n,t.vars.pauseOnAction):v||t.flexAnimate(t.currentSlide,t.vars.pauseOnAction,!0)}r=null,o=null,m=null,l=null,w=0}}var r,o,l,p,m,f,g,h,S,y=!1,x=0,b=0,w=0;i?(e.style.msTouchAction="none",e._gesture=new MSGesture,e._gesture.target=e,e.addEventListener("MSPointerDown",t,!1),e._slider=a,e.addEventListener("MSGestureChange",n,!1),e.addEventListener("MSGestureEnd",s,!1)):(g=function(t){a.animating?t.preventDefault():(window.navigator.msPointerEnabled||1===t.touches.length)&&(a.pause(),p=c?a.h:a.w,f=Number(new Date),x=t.touches[0].pageX,b=t.touches[0].pageY,l=u&&d&&a.animatingTo===a.last?0:u&&d?a.limit-(a.itemW+a.vars.itemMargin)*a.move*a.animatingTo:u&&a.currentSlide===a.last?a.limit:u?(a.itemW+a.vars.itemMargin)*a.move*a.currentSlide:d?(a.last-a.currentSlide+a.cloneOffset)*p:(a.currentSlide+a.cloneOffset)*p,r=c?b:x,o=c?x:b,e.addEventListener("touchmove",h,!1),e.addEventListener("touchend",S,!1))},h=function(e){x=e.touches[0].pageX,b=e.touches[0].pageY,m=c?r-b:r-x,y=c?Math.abs(m)<Math.abs(x-o):Math.abs(m)<Math.abs(b-o);var t=500;(!y||Number(new Date)-f>t)&&(e.preventDefault(),!v&&a.transitions&&(a.vars.animationLoop||(m/=0===a.currentSlide&&0>m||a.currentSlide===a.last&&m>0?Math.abs(m)/p+2:1),a.setProps(l+m,"setTouch")))},S=function(t){if(e.removeEventListener("touchmove",h,!1),a.animatingTo===a.currentSlide&&!y&&null!==m){var n=d?-m:m,i=a.getTarget(n>0?"next":"prev");a.canAdvance(i)&&(Number(new Date)-f<550&&Math.abs(n)>50||Math.abs(n)>p/2)?a.flexAnimate(i,a.vars.pauseOnAction):v||a.flexAnimate(a.currentSlide,a.vars.pauseOnAction,!0)}e.removeEventListener("touchend",S,!1),r=null,o=null,m=null,l=null},e.addEventListener("touchstart",g,!1))},resize:function(){!a.animating&&a.is(":visible")&&(u||a.doMath(),v?m.smoothHeight():u?(a.slides.width(a.computedW),a.update(a.pagingCount),a.setProps()):c?(a.viewport.height(a.h),a.setProps(a.h,"setTotal")):(a.vars.smoothHeight&&m.smoothHeight(),a.newSlides.width(a.computedW),a.setProps(a.computedW,"setTotal")))},smoothHeight:function(e){if(!c||v){var t=v?a:a.viewport;e?t.animate({height:a.slides.eq(a.animatingTo).height()},e):t.height(a.slides.eq(a.animatingTo).height())}},sync:function(e){var t=$(a.vars.sync).data("flexslider"),n=a.animatingTo;switch(e){case"animate":t.flexAnimate(n,a.vars.pauseOnAction,!1,!0);break;case"play":t.playing||t.asNav||t.play();break;case"pause":t.pause()}},uniqueID:function(e){return e.filter("[id]").add(e.find("[id]")).each(function(){var e=$(this);e.attr("id",e.attr("id")+"_clone")}),e},pauseInvisible:{visProp:null,init:function(){var e=m.pauseInvisible.getHiddenProp();if(e){var t=e.replace(/[H|h]idden/,"")+"visibilitychange";document.addEventListener(t,function(){m.pauseInvisible.isHidden()?a.startTimeout?clearTimeout(a.startTimeout):a.pause():a.started?a.play():a.vars.initDelay>0?setTimeout(a.play,a.vars.initDelay):a.play()})}},isHidden:function(){var e=m.pauseInvisible.getHiddenProp();return e?document[e]:!1},getHiddenProp:function(){var e=["webkit","moz","ms","o"];if("hidden"in document)return"hidden";for(var t=0;t<e.length;t++)if(e[t]+"Hidden"in document)return e[t]+"Hidden";return null}},setToClearWatchedEvent:function(){clearTimeout(l),l=setTimeout(function(){o=""},3e3)}},a.flexAnimate=function(e,t,i,r,o){if(a.vars.animationLoop||e===a.currentSlide||(a.direction=e>a.currentSlide?"next":"prev"),p&&1===a.pagingCount&&(a.direction=a.currentItem<e?"next":"prev"),!a.animating&&(a.canAdvance(e,o)||i)&&a.is(":visible")){if(p&&r){var l=$(a.vars.asNavFor).data("flexslider");if(a.atEnd=0===e||e===a.count-1,l.flexAnimate(e,!0,!1,!0,o),a.direction=a.currentItem<e?"next":"prev",l.direction=a.direction,Math.ceil((e+1)/a.visible)-1===a.currentSlide||0===e)return a.currentItem=e,a.slides.removeClass(n+"active-slide").eq(e).addClass(n+"active-slide"),!1;a.currentItem=e,a.slides.removeClass(n+"active-slide").eq(e).addClass(n+"active-slide"),e=Math.floor(e/a.visible)}if(a.animating=!0,a.animatingTo=e,t&&a.pause(),a.vars.before(a),a.syncExists&&!o&&m.sync("animate"),a.vars.controlNav&&m.controlNav.active(),u||a.slides.removeClass(n+"active-slide").eq(e).addClass(n+"active-slide"),a.atEnd=0===e||e===a.last,a.vars.directionNav&&m.directionNav.update(),e===a.last&&(a.vars.end(a),a.vars.animationLoop||a.pause()),v)s?(a.slides.eq(a.currentSlide).css({opacity:0,zIndex:1}),a.slides.eq(e).css({opacity:1,zIndex:2}),a.wrapup(f)):(a.slides.eq(a.currentSlide).css({zIndex:1}).animate({opacity:0},a.vars.animationSpeed,a.vars.easing),a.slides.eq(e).css({zIndex:2}).animate({opacity:1},a.vars.animationSpeed,a.vars.easing,a.wrapup));else{var f=c?a.slides.filter(":first").height():a.computedW,g,h,S;u?(g=a.vars.itemMargin,S=(a.itemW+g)*a.move*a.animatingTo,h=S>a.limit&&1!==a.visible?a.limit:S):h=0===a.currentSlide&&e===a.count-1&&a.vars.animationLoop&&"next"!==a.direction?d?(a.count+a.cloneOffset)*f:0:a.currentSlide===a.last&&0===e&&a.vars.animationLoop&&"prev"!==a.direction?d?0:(a.count+1)*f:d?(a.count-1-e+a.cloneOffset)*f:(e+a.cloneOffset)*f,a.setProps(h,"",a.vars.animationSpeed),a.transitions?(a.vars.animationLoop&&a.atEnd||(a.animating=!1,a.currentSlide=a.animatingTo),a.container.unbind("webkitTransitionEnd transitionend"),a.container.bind("webkitTransitionEnd transitionend",function(){clearTimeout(a.ensureAnimationEnd),a.wrapup(f)}),clearTimeout(a.ensureAnimationEnd),a.ensureAnimationEnd=setTimeout(function(){a.wrapup(f)},a.vars.animationSpeed+100)):a.container.animate(a.args,a.vars.animationSpeed,a.vars.easing,function(){a.wrapup(f)})}a.vars.smoothHeight&&m.smoothHeight(a.vars.animationSpeed)}},a.wrapup=function(e){v||u||(0===a.currentSlide&&a.animatingTo===a.last&&a.vars.animationLoop?a.setProps(e,"jumpEnd"):a.currentSlide===a.last&&0===a.animatingTo&&a.vars.animationLoop&&a.setProps(e,"jumpStart")),a.animating=!1,a.currentSlide=a.animatingTo,a.vars.after(a)},a.animateSlides=function(){!a.animating&&f&&a.flexAnimate(a.getTarget("next"))},a.pause=function(){clearInterval(a.animatedSlides),a.animatedSlides=null,a.playing=!1,a.vars.pausePlay&&m.pausePlay.update("play"),a.syncExists&&m.sync("pause")},a.play=function(){a.playing&&clearInterval(a.animatedSlides),a.animatedSlides=a.animatedSlides||setInterval(a.animateSlides,a.vars.slideshowSpeed),a.started=a.playing=!0,a.vars.pausePlay&&m.pausePlay.update("pause"),a.syncExists&&m.sync("play")},a.stop=function(){a.pause(),a.stopped=!0},a.canAdvance=function(e,t){var n=p?a.pagingCount-1:a.last;return t?!0:p&&a.currentItem===a.count-1&&0===e&&"prev"===a.direction?!0:p&&0===a.currentItem&&e===a.pagingCount-1&&"next"!==a.direction?!1:e!==a.currentSlide||p?a.vars.animationLoop?!0:a.atEnd&&0===a.currentSlide&&e===n&&"next"!==a.direction?!1:a.atEnd&&a.currentSlide===n&&0===e&&"next"===a.direction?!1:!0:!1},a.getTarget=function(e){return a.direction=e,"next"===e?a.currentSlide===a.last?0:a.currentSlide+1:0===a.currentSlide?a.last:a.currentSlide-1},a.setProps=function(e,t,n){var i=function(){var n=e?e:(a.itemW+a.vars.itemMargin)*a.move*a.animatingTo,i=function(){if(u)return"setTouch"===t?e:d&&a.animatingTo===a.last?0:d?a.limit-(a.itemW+a.vars.itemMargin)*a.move*a.animatingTo:a.animatingTo===a.last?a.limit:n;switch(t){case"setTotal":return d?(a.count-1-a.currentSlide+a.cloneOffset)*e:(a.currentSlide+a.cloneOffset)*e;case"setTouch":return d?e:e;case"jumpEnd":return d?e:a.count*e;case"jumpStart":return d?a.count*e:e;default:return e}}();return-1*i+"px"}();a.transitions&&(i=c?"translate3d(0,"+i+",0)":"translate3d("+i+",0,0)",n=void 0!==n?n/1e3+"s":"0s",a.container.css("-"+a.pfx+"-transition-duration",n),a.container.css("transition-duration",n)),a.args[a.prop]=i,(a.transitions||void 0===n)&&a.container.css(a.args),a.container.css("transform",i)},a.setup=function(e){if(v)a.slides.css({width:"100%","float":"left",marginRight:"-100%",position:"relative"}),"init"===e&&(s?a.slides.css({opacity:0,display:"block",webkitTransition:"opacity "+a.vars.animationSpeed/1e3+"s ease",zIndex:1}).eq(a.currentSlide).css({opacity:1,zIndex:2}):0==a.vars.fadeFirstSlide?a.slides.css({opacity:0,display:"block",zIndex:1}).eq(a.currentSlide).css({zIndex:2}).css({opacity:1}):a.slides.css({opacity:0,display:"block",zIndex:1}).eq(a.currentSlide).css({zIndex:2}).animate({opacity:1},a.vars.animationSpeed,a.vars.easing)),a.vars.smoothHeight&&m.smoothHeight();else{var t,i;"init"===e&&(a.viewport=$('<div class="'+n+'viewport"></div>').css({overflow:"hidden",position:"relative"}).appendTo(a).append(a.container),a.cloneCount=0,a.cloneOffset=0,d&&(i=$.makeArray(a.slides).reverse(),a.slides=$(i),a.container.empty().append(a.slides))),a.vars.animationLoop&&!u&&(a.cloneCount=2,a.cloneOffset=1,"init"!==e&&a.container.find(".clone").remove(),a.container.append(m.uniqueID(a.slides.first().clone().addClass("clone")).attr("aria-hidden","true")).prepend(m.uniqueID(a.slides.last().clone().addClass("clone")).attr("aria-hidden","true"))),a.newSlides=$(a.vars.selector,a),t=d?a.count-1-a.currentSlide+a.cloneOffset:a.currentSlide+a.cloneOffset,c&&!u?(a.container.height(200*(a.count+a.cloneCount)+"%").css("position","absolute").width("100%"),setTimeout(function(){a.newSlides.css({display:"block"}),a.doMath(),a.viewport.height(a.h),a.setProps(t*a.h,"init")},"init"===e?100:0)):(a.container.width(200*(a.count+a.cloneCount)+"%"),a.setProps(t*a.computedW,"init"),setTimeout(function(){a.doMath(),a.newSlides.css({width:a.computedW,"float":"left",display:"block"}),a.vars.smoothHeight&&m.smoothHeight()},"init"===e?100:0))}u||a.slides.removeClass(n+"active-slide").eq(a.currentSlide).addClass(n+"active-slide"),a.vars.init(a)},a.doMath=function(){var e=a.slides.first(),t=a.vars.itemMargin,n=a.vars.minItems,i=a.vars.maxItems;a.w=void 0===a.viewport?a.width():a.viewport.width(),a.h=e.height(),a.boxPadding=e.outerWidth()-e.width(),u?(a.itemT=a.vars.itemWidth+t,a.minW=n?n*a.itemT:a.w,a.maxW=i?i*a.itemT-t:a.w,a.itemW=a.minW>a.w?(a.w-t*(n-1))/n:a.maxW<a.w?(a.w-t*(i-1))/i:a.vars.itemWidth>a.w?a.w:a.vars.itemWidth,a.visible=Math.floor(a.w/a.itemW),a.move=a.vars.move>0&&a.vars.move<a.visible?a.vars.move:a.visible,a.pagingCount=Math.ceil((a.count-a.visible)/a.move+1),a.last=a.pagingCount-1,a.limit=1===a.pagingCount?0:a.vars.itemWidth>a.w?a.itemW*(a.count-1)+t*(a.count-1):(a.itemW+t)*a.count-a.w-t):(a.itemW=a.w,a.pagingCount=a.count,a.last=a.count-1),a.computedW=a.itemW-a.boxPadding},a.update=function(e,t){a.doMath(),u||(e<a.currentSlide?a.currentSlide+=1:e<=a.currentSlide&&0!==e&&(a.currentSlide-=1),a.animatingTo=a.currentSlide),a.vars.controlNav&&!a.manualControls&&("add"===t&&!u||a.pagingCount>a.controlNav.length?m.controlNav.update("add"):("remove"===t&&!u||a.pagingCount<a.controlNav.length)&&(u&&a.currentSlide>a.last&&(a.currentSlide-=1,a.animatingTo-=1),m.controlNav.update("remove",a.last))),a.vars.directionNav&&m.directionNav.update()},a.addSlide=function(e,t){var n=$(e);a.count+=1,a.last=a.count-1,c&&d?void 0!==t?a.slides.eq(a.count-t).after(n):a.container.prepend(n):void 0!==t?a.slides.eq(t).before(n):a.container.append(n),a.update(t,"add"),a.slides=$(a.vars.selector+":not(.clone)",a),a.setup(),a.vars.added(a)},a.removeSlide=function(e){var t=isNaN(e)?a.slides.index($(e)):e;a.count-=1,a.last=a.count-1,isNaN(e)?$(e,a.slides).remove():c&&d?a.slides.eq(a.last).remove():a.slides.eq(e).remove(),a.doMath(),a.update(t,"remove"),a.slides=$(a.vars.selector+":not(.clone)",a),a.setup(),a.vars.removed(a)},m.init()},$(window).blur(function(e){focused=!1}).focus(function(e){focused=!0}),$.flexslider.defaults={namespace:"flex-",selector:".slides > li",animation:"fade",easing:"swing",direction:"horizontal",reverse:!1,animationLoop:!0,smoothHeight:!1,startAt:0,slideshow:!0,slideshowSpeed:7e3,animationSpeed:600,initDelay:0,randomize:!1,fadeFirstSlide:!0,thumbCaptions:!1,pauseOnAction:!0,pauseOnHover:!1,pauseInvisible:!0,useCSS:!0,touch:!0,video:!1,controlNav:!0,directionNav:!0,prevText:"Previous",nextText:"Next",keyboard:!0,multipleKeyboard:!1,mousewheel:!1,pausePlay:!1,pauseText:"Pause",playText:"Play",controlsContainer:"",manualControls:"",customDirectionNav:"",sync:"",asNavFor:"",itemWidth:0,itemMargin:0,minItems:1,maxItems:0,move:0,allowOneSlide:!0,start:function(){},before:function(){},after:function(){},end:function(){},added:function(){},removed:function(){},init:function(){}},$.fn.flexslider=function(e){if(void 0===e&&(e={}),"object"==typeof e)return this.each(function(){var t=$(this),a=e.selector?e.selector:".slides > li",n=t.find(a);1===n.length&&e.allowOneSlide===!0||0===n.length?(n.fadeIn(400),e.start&&e.start(t)):void 0===t.data("flexslider")&&new $.flexslider(this,e)});var t=$(this).data("flexslider");switch(e){case"play":t.play();break;case"pause":t.pause();break;case"stop":t.stop();break;case"next":t.flexAnimate(t.getTarget("next"),!0);break;case"prev":case"previous":t.flexAnimate(t.getTarget("prev"),!0);break;default:"number"==typeof e&&t.flexAnimate(e,!0)}}}(jQuery);
//FitVids
!function(t){"use strict";t.fn.fitVids=function(e){var i={customSelector:null,ignore:null};if(!document.getElementById("fit-vids-style")){var r=document.head||document.getElementsByTagName("head")[0],a=".fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}",o=document.createElement("div");o.innerHTML='<p>x</p><style id="fit-vids-style">'+a+"</style>",r.appendChild(o.childNodes[1])}return e&&t.extend(i,e),this.each(function(){var e=['iframe[src*="player.vimeo.com"]','iframe[src*="youtube.com"]','iframe[src*="youtube-nocookie.com"]','iframe[src*="kickstarter.com"][src*="video.html"]',"iframe[src*='dailymotion.com']","object","embed"];i.customSelector&&e.push(i.customSelector);var r=".fitvidsignore";i.ignore&&(r=r+", "+i.ignore);var a=t(this).find(e.join(","));a=a.not("object object"),a=a.not(r),a.each(function(){var e=t(this);if(!(e.parents(r).length>0||"embed"===this.tagName.toLowerCase()&&e.parent("object").length||e.parent(".fluid-width-video-wrapper").length)){e.css("height")||e.css("width")||!isNaN(e.attr("height"))&&!isNaN(e.attr("width"))||(e.attr("height",9),e.attr("width",16));var i="object"===this.tagName.toLowerCase()||e.attr("height")&&!isNaN(parseInt(e.attr("height"),10))?parseInt(e.attr("height"),10):e.height(),a=isNaN(parseInt(e.attr("width"),10))?e.width():parseInt(e.attr("width"),10),o=i/a;if(!e.attr("name")){var d="fitvid"+t.fn.fitVids._count;e.attr("name",d),t.fn.fitVids._count++}e.wrap('<div class="fluid-width-video-wrapper"></div>').parent(".fluid-width-video-wrapper").css("padding-top",100*o+"%"),e.removeAttr("height").removeAttr("width")}})})},t.fn.fitVids._count=0}(window.jQuery||window.Zepto);
//Images Loaded
(function(c,n){var l="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==";c.fn.imagesLoaded=function(f){function m(){var b=c(i),a=c(h);d&&(h.length?d.reject(e,b,a):d.resolve(e));c.isFunction(f)&&f.call(g,e,b,a)}function j(b,a){b.src===l||-1!==c.inArray(b,k)||(k.push(b),a?h.push(b):i.push(b),c.data(b,"imagesLoaded",{isBroken:a,src:b.src}),o&&d.notifyWith(c(b),[a,e,c(i),c(h)]),e.length===k.length&&(setTimeout(m),e.unbind(".imagesLoaded")))}var g=this,d=c.isFunction(c.Deferred)?c.Deferred():0,o=c.isFunction(d.notify),e=g.find("img").add(g.filter("img")),k=[],i=[],h=[];c.isPlainObject(f)&&c.each(f,function(b,a){if("callback"===b)f=a;else if(d)d[b](a)});e.length?e.bind("load.imagesLoaded error.imagesLoaded",function(b){j(b.target,"error"===b.type)}).each(function(b,a){var d=a.src,e=c.data(a,"imagesLoaded");if(e&&e.src===d)j(a,e.isBroken);else if(a.complete&&a.naturalWidth!==n)j(a,0===a.naturalWidth||0===a.naturalHeight);else if(a.readyState||a.complete)a.src=l,a.src=d}):m();return d?d.promise(g):g}})(jQuery);
//Sticky Sidebars
!function(i){i.fn.theiaStickySidebar=function(t){var o={containerSelector:"",additionalMarginTop:0,additionalMarginBottom:0,updateSidebarHeight:!0,minWidth:0};t=i.extend(o,t),t.additionalMarginTop=parseInt(t.additionalMarginTop)||0,t.additionalMarginBottom=parseInt(t.additionalMarginBottom)||0,this.each(function(){function o(){e.fixedScrollTop=0,e.sidebar.css({"min-height":"1px"}),e.stickySidebar.css({position:"static",width:""})}function a(t){var o=t.height();return t.children().each(function(){o=Math.max(o,i(this).height())}),o}var e={};e.sidebar=i(this),e.options=t||{},e.container=i(e.options.containerSelector),0==e.container.size()&&(e.container=e.sidebar.parent()),e.sidebar.css({position:"relative",overflow:"visible","-webkit-box-sizing":"border-box","-moz-box-sizing":"border-box","box-sizing":"border-box"}),e.stickySidebar=e.sidebar.find(".theiaStickySidebar"),0==e.stickySidebar.length&&(e.sidebar.find("script").remove(),e.stickySidebar=i("<div>").addClass("theiaStickySidebar").append(e.sidebar.children()),e.sidebar.append(e.stickySidebar)),e.marginTop=parseInt(e.sidebar.css("margin-top")),e.marginBottom=parseInt(e.sidebar.css("margin-bottom")),e.paddingTop=parseInt(e.sidebar.css("padding-top")),e.paddingBottom=parseInt(e.sidebar.css("padding-bottom"));var d=e.stickySidebar.offset().top,r=e.stickySidebar.outerHeight();e.stickySidebar.css("padding-top",1),e.stickySidebar.css("padding-bottom",1),d-=e.stickySidebar.offset().top,r=e.stickySidebar.outerHeight()-r-d,0==d?(e.stickySidebar.css("padding-top",0),e.stickySidebarPaddingTop=0):e.stickySidebarPaddingTop=1,0==r?(e.stickySidebar.css("padding-bottom",0),e.stickySidebarPaddingBottom=0):e.stickySidebarPaddingBottom=1,e.previousScrollTop=null,e.fixedScrollTop=0,o(),e.onScroll=function(e){if(e.stickySidebar.is(":visible")){if(i("body").width()<e.options.minWidth)return void o();if(e.sidebar.outerWidth(!0)+50>e.container.width())return void o();var d=i(document).scrollTop(),r="static";if(d>=e.container.offset().top+(e.paddingTop+e.marginTop-e.options.additionalMarginTop)){var n,s=e.paddingTop+e.marginTop+t.additionalMarginTop,c=e.paddingBottom+e.marginBottom+t.additionalMarginBottom,p=e.container.offset().top,b=e.container.offset().top+a(e.container),g=0+t.additionalMarginTop,l=e.stickySidebar.outerHeight()+s+c<i(window).height();n=l?g+e.stickySidebar.outerHeight():i(window).height()-e.marginBottom-e.paddingBottom-t.additionalMarginBottom;var f=p-d+e.paddingTop+e.marginTop,S=b-d-e.paddingBottom-e.marginBottom,h=e.stickySidebar.offset().top-d,m=e.previousScrollTop-d;"fixed"==e.stickySidebar.css("position")&&(h+=m),h=m>0?Math.min(h,g):Math.max(h,n-e.stickySidebar.outerHeight()),h=Math.max(h,f),h=Math.min(h,S-e.stickySidebar.outerHeight());var u=e.container.height()==e.stickySidebar.outerHeight();r=(u||h!=g)&&(u||h!=n-e.stickySidebar.outerHeight())?d+h-e.sidebar.offset().top-e.paddingTop<=t.additionalMarginTop?"static":"absolute":"fixed"}if("fixed"==r)e.stickySidebar.css({position:"fixed",width:e.sidebar.width(),top:h,left:e.sidebar.offset().left+parseInt(e.sidebar.css("padding-left"))});else if("absolute"==r){var y={};"absolute"!=e.stickySidebar.css("position")&&(y.position="absolute",y.top=d+h-e.sidebar.offset().top-e.stickySidebarPaddingTop-e.stickySidebarPaddingBottom),y.width=e.sidebar.width(),y.left="",e.stickySidebar.css(y)}else"static"==r&&o();"static"!=r&&1==e.options.updateSidebarHeight&&e.sidebar.css({"min-height":e.stickySidebar.outerHeight()+e.stickySidebar.offset().top-e.sidebar.offset().top+e.paddingBottom}),e.previousScrollTop=d}},e.onScroll(e),i(document).scroll(function(i){return function(){i.onScroll(i)}}(e)),i(window).resize(function(i){return function(){i.stickySidebar.css({position:"static"}),i.onScroll(i)}}(e))})}}(jQuery);

(function($) {

    $.fn.extend({
        ajaxyLiveSearch: function(options, arg) {
            if (options && typeof(options) == 'object') {
                options = $.extend( {}, $.ajaxyLiveSearch.defaults, options );
            }
			else {
				options = $.ajaxyLiveSearch.defaults;
			}
            // this creates a plugin for each element in
            // the selector or runs the function once per
            // selector.  To have it do so for just the
            // first element (once), return false after
            // creating the plugin to stop the each iteration 
			if(this.is("input")){
				this.each(function() {
					new $.ajaxyLiveSearch.load(this, options, arg );
				});
				return;
			}
        }
    });

    $.ajaxyLiveSearch = {
		element: null,
		timeout: null,
		options: null,
		load: function( elem, options, arg ) {
				this.element = elem;
				this.timeout = null;
				this.options = options;
				if($(elem).val() == "") {
					$(elem).val(options.text);
				}
				$(elem).attr('autocomplete', 'off');
				if($('#live-search_sb').length == 0){
					$('body').append('<div id="live-search_sb" class="live-search_sb" style="position:absolute;display:none;width:'+ options.width + 'px;z-index:9999">'+
											'<div class="live-search_sb_cont">' +
												'<div class="live-search_sb_top"></div>' +
												'<div id="live-search_results" style="width:100%">' +
													'<div id="live-search_val" ></div>' +
													'<div id="live-search_more"></div>' +
												'</div>' +
												'<div class="live-search_sb_bottom"></div>' +
											'</div>' +
										'</div>');
				}
				$.ajaxyLiveSearch.loadEvents(this);
			},
		loadResults: function(object) {
			options = object.options;
			elem = object.element;
			window.sf_lastElement = elem;
			if(jQuery(elem).val() != "")
			{
				jQuery("body").data("live-search_results", null);
				var loading  = 	"<li class=\"live-search_lnk live-search_more live-search_selected\">"+
					"<a id=\"live-search_loading\" href=\"" + options.searchUrl.replace('%s', encodeURI(jQuery(elem).val())) + "\"><i class=\"fa fa-spinner fa-spin\"></i>"+
					"</a>"+
				"</li>";
				jQuery("#live-search_val").html("<ul>"+loading+"</ul>");
				var pos = this.bounds(elem, options);
				var containerPos = this.bounds('.top-nav .container' , options);
				if(!pos) {
					jQuery("#live-search_sb").hide();
					return false;
				}
				if(Math.ceil(containerPos.left) + parseInt(options.width, 10) > jQuery(window).width()) {
					jQuery("#live-search_sb").css('width', jQuery(window).width() - containerPos.left - 20);
				}
				if( jQuery( 'body' ).hasClass( "rtl" ) ) {
					jQuery("#live-search_sb").css({top:pos.bottom, right:containerPos.right});
				}else{
					jQuery("#live-search_sb").css({top:pos.bottom, right:containerPos.left});
				}
				jQuery("#live-search_sb").show();
				
				var data = { action: "ajaxy_sf", sf_value: jQuery(elem).val(), search:options.search};
				if(options.ajaxData){
					data = window[options.ajaxData](data);
				}
				if(options.search) {
					var mresults = options.search.split(',');
					var results = [];
					var m = "";
					var s = 0;

					var c = [];
					for(var kindex in mresults){
						var dm = mresults[kindex].split(":");
						if(dm.length == 2) {
							if(dm[1].indexOf(jQuery(elem).val()) == 0) {
								results[results.length] = mresults[kindex];
							}
						}else if(dm.length == 1){
							if(mresults[kindex].indexOf(jQuery(elem).val()) == 0) {
								results[results.length] = mresults[kindex];
							}
						}
					}
					
					c = $.ajaxyLiveSearch.htmlArrayResults(results);
					m += c[0];
					s += c[1];
					
					var sf_selected = "";
					if(s == 0)
					{
						sf_selected = " live-search_selected";
					}
					m += "<li class=\"live-search_lnk live-search_more" + sf_selected + "\">{total} "+ tie.lang_results_found +"</li>";
					
					m = m.replace(/{search_value_escaped}/g, jQuery(elem).val());
					m = m.replace(/{search_url_escaped}/g, options.searchUrl.replace('%s', encodeURI(jQuery(elem).val())));
					m = m.replace(/{search_value}/g, jQuery(elem).val());
					m = m.replace(/{total}/g, s);
					
					jQuery("body").data("live-search_results", results);
					
					if(s > 0)
					{
						jQuery("#live-search_val").html("<ul>"+m+"</ul>");
					}
					else
					{
						jQuery("#live-search_val").html("<ul>"+m+"</ul>");
					}
					$.ajaxyLiveSearch.loadLiveEvents(object);
					jQuery("#live-search_sb").show();
				}else{
					jQuery.post(options.ajaxUrl, data, function(resp) { 
						var results = eval("("+ resp + ")");
						var m = "";
						var s = 0;
						for(var mindex in results)
						{
							var c = [];
							for(var kindex in results[mindex]){
								c = $.ajaxyLiveSearch.htmlResults(results[mindex][kindex], mindex, kindex);
								m += c[0];
								s += c[1];
							}
						}
						
						
						
						var sf_selected = "";
						if(s == 0)
						{
							sf_selected = " live-search_selected";
							m += "<li class=\"live-search_lnk live-search_more\">"+ tie.lang_no_results +"</li>";

						}else{
							if(!options.callback) {
								m += "<li class=\"live-search_lnk live-search_more\">" + sf_templates + "</li>";
							}
							m = m.replace(/{search_value_escaped}/g, jQuery(elem).val());
							m = m.replace(/{search_url_escaped}/g, options.searchUrl.replace('%s', encodeURI(jQuery(elem).val())));
							//m = m.replace(/{search_value}/g, jQuery(elem).val());
							//m = m.replace(/{total}/g, s);
						}	
						jQuery("body").data("live-search_results", results);
						
						if(s > 0)
						{
							jQuery("#live-search_val").html('<ul class="live-search_main">'+m+'</ul>');
						}
						else
						{
							jQuery("#live-search_val").html('<ul class="live-search_main">'+m+'</ul>');
						}
						$.ajaxyLiveSearch.loadLiveEvents(object);
						jQuery("#live-search_sb").show();
					});
				}
			 }
			 else
			 {
				jQuery("#live-search_sb").hide();
			 }
		},
		bounds: function (elem, options) {
			var offset = jQuery(elem).offset();
			if(offset) {
				return {top: offset.top, left: offset.left + options.leftOffset, bottom: offset.top +  jQuery(elem).innerHeight() + options.topOffset, right: offset.left - jQuery('#live-search_sb').innerWidth() + jQuery(elem).innerWidth()};			
			}
		},
		htmlResults: function (results, type, array_index){
			var m = "";
			var s = 0;	
			if(typeof(results) != "undefined")
			{
				if(results.all.length > 0)
				{
					m += "<li class=\"live-search_header\">" + results.title + "</li><li><div class=\"live-search_result_container\"><ul>";
					for(var i = 0; i < results.all.length; i ++)
					{
						s ++;
						m += "<li result-type='object' index-type='" + type + "' index-array='" + array_index + "' index='" + i + "' class=\"live-search_lnk "+results.class_name +"\">"+  $.ajaxyLiveSearch.replaceResults(results.all[i], results.template) + "</li>";
					}
					m += "</ul></div></li>";
				}
			}
			return new Array(m, s);
		},
		htmlArrayResults: function (results){
			var m = "";
			var s = 0;	
			if(typeof(results) != "undefined")
			{
				if(results.length > 0)
				{
					m += "<li><div class=\"live-search_result_container\"><ul>";
					for(var i = 0; i < results.length; i ++)
					{
						var md = results[i].split(':');
						var title = "";
						if(md.length == 2) {
							title = md[1];
						}else{
							title = results[i];
						}
						s ++;
						m += "<li result-type='array' index='" + i + "' class=\"live-search_lnk live-search_category\"><a href='javascript:;'>" + title + "</a></li>";
					}
					m += "</ul></div></li>";
				}
			}
			return new Array(m, s);
		},
		replaceResults: function (results, template){
			for(var s in results)
			{
				template = template.replace(new RegExp("{"+s+"}", "g"), results[s]);
			}
			return template;
		},
		loadLiveEvents: function(object){
			var d = {object: object};
			jQuery("#live-search_val li.live-search_lnk").mouseover(function(){
				jQuery(".live-search_lnk").each(function() { jQuery(this).attr("class",jQuery(this).attr("class").replace(" live-search_selected" , "")); });
				jQuery(this).attr("class", jQuery(this).attr("class") + " live-search_selected");
			});
			if(d.object.options.callback)
			{
				jQuery("#live-search_val li.live-search_lnk").click(function(event){
					try{
						window[d.object.options.callback](d.object, this);
					}catch(e){
						alert(e);
					}
					return false;
				});
			}
		},
		loadEvents: function(object){
			var d = {object: object};
			jQuery(document).click(function(){ jQuery("#live-search_sb").hide(); });
			jQuery(window).resize(function(){ 
				var pos = $.ajaxyLiveSearch.bounds(window.sf_lastElement, d.object.options);
				if(pos) {
					jQuery("#live-search_sb").css({top:pos.bottom, left:pos.left});
				}
			});
			
			
			jQuery(object.element).keyup(function(event){
				if(event.keyCode != "38" && event.keyCode != "40" && event.keyCode != "13" && event.keyCode != "27" && event.keyCode != "39" && event.keyCode != "37")
				{
					var ajaxyObject = d.object;
					if(ajaxyObject.timeout != null)
					{
						clearTimeout(ajaxyObject.timeout);
					}
					jQuery(ajaxyObject.element).attr("class", jQuery(ajaxyObject.element).attr("class").replace(" live-search_focused", "") + " live-search_focused");
					//$.ajaxyLiveSearch.loadResults(d.object.element, d.object.options);
					var l = {object:d.object};
					ajaxyObject.timeout = setTimeout(function() { jQuery.ajaxyLiveSearch.loadResults(l.object); }, d.object.options.delay);
				}
			});	
			jQuery(window).keydown(function(event){
				if(jQuery("#live-search_sb").css("display") != "none" && jQuery("#live-search_sb").css("display") != "undefined" && jQuery("#live-search_sb").length > 0)
				{
					if(event.keyCode == "38" || event.keyCode == "40")
					{
						if(jQuery.browser.webkit)
						{
							jQuery("#live-search_sb").focus();
						}
						var s_item = null;
						var after_s_item = null;
						var s_sel = false;
						var all_items = jQuery("#live-search_val li.live-search_lnk");
						var s_found = false;
						event.stopPropagation();
						event.preventDefault();
						for(var i = 0; i < all_items.length; i++)
						{
							if(jQuery(all_items[i]).attr("class").indexOf("live-search_selected") >= 0 && s_found == false)
							{
								s_sel = true;
								if(i < all_items.length - 1 && event.keyCode == "40")
								{
									jQuery(all_items[i]).attr("class",jQuery(all_items[i]).attr("class").replace(" live-search_selected", ""));
									jQuery(all_items[i+1]).attr("class", jQuery(all_items[i+1]).attr("class")+ " live-search_selected");
									i = i+1;
									s_found = true;
								}
								else if(i > 0 && event.keyCode == "38")
								{
									jQuery(all_items[i]).attr("class",jQuery(all_items[i]).attr("class").replace(" live-search_selected", ""));
									jQuery(all_items[i-1]).attr("class", jQuery(all_items[i-1]).attr("class")+ " live-search_selected");
									i = i+1;
									s_found = true;
								}
							}
							else
							{
								jQuery(all_items[i]).attr("class",jQuery(all_items[i]).attr("class").replace(" live-search_selected", ""));
							}
						}
						if(s_sel == false)
						{
							if(all_items.length > 0)
							{
								jQuery(all_items[0]).attr("class", jQuery(all_items[0]).attr("class")+ " live-search_selected");
							}
						}
						//jQuery(window).unbind("keypress");

					}
					else if(event.keyCode == 27)
					{
						jQuery("#live-search_sb").hide();
					}
					else if(event.keyCode == 13)
					{
						var b = jQuery("#live-search_val li.live-search_selected a").attr("href");
						if(typeof(b) != 'undefined' && b != '')
						{
							if(d.object.options.callback){
								d.object.options.callback(this);
							}else{
								window.location.href = b;
							}
							return false;
						}
						else
						{
							if(d.object.options.callback){
								d.object.options.callback(this);
							}
							else if(d.object.element != null){
								window.location.href = sf_url.replace('%s', encodeURI(jQuery(d.object).val()));
							}
							return false;
						}
					}
				}
			});
			jQuery(object.element).focus(function (){
				if(jQuery(this).val() == d.object.options.text){
					jQuery(this).val('');
					jQuery(this).attr('class', jQuery(this).attr('class') + ' live-search_focused');
				}
				if(d.object.options.expand > 0){
					jQuery(d.object.element).animate({width:d.object.options.iwidth});
				}
			});
			jQuery(object.element).blur(function () {
				if(jQuery(this).val() == ''){
					jQuery(this).val(d.object.options.text);
					jQuery(this).attr('class', jQuery(this).attr('class').replace(/ sf_focused/g, ''));
				}
				if(d.object.options.expand > 0){
					jQuery(d.object.element).animate({width:d.object.options.expand});
				}
			});
		}
	};
    $.ajaxyLiveSearch.defaults = {
       delay:500, 
	   leftOffset: 0,
	   topOffset: 5,
	   text: "Search For",
	   iwidth: 180,
	   width: 315,
	   ajaxUrl: "",
	   ajaxData: false, //function to extend data sent to server
	   searchUrl: "",
	   expand: false,
	   callback: false,
	   search: false
    };

})(jQuery);


function sf_addItem(search, title, name, name_type, value) {
	var items = jQuery(search).find('.live-search_ajaxy-selective-item');
	var exists = false;

	var key = "";
	var md = value.split(':');
	if(md.length == 2) {
		key = md[0];
	}else{
		key = value;
	}
	if(items.length > 0) {
		for(var i = 0; i < items.length; i ++) {
			if(jQuery(items[i]).find('input.live-search_ajaxy-selective-close-hidden').val() == key){
				exists = true;
				break;
			}
		}
	}
	if(exists) {
		jQuery(search).find(".live-search_ajaxy-selective-input").val("");
		jQuery('#live-search_sb').hide();
		return;
	}
	var mds = title.split(':');
	if(mds.length == 2) {
		title = md[1];
	}
	var added_item = jQuery('<span class="live-search_ajaxy-selective-item">' + title + '<a class="live-search_ajaxy-selective-close">X</a><input class="live-search_ajaxy-selective-close-hidden" type="hidden" name="' + name + '" value="' + key + '" /></span>');
	if(items.length <= 0){
		jQuery(search).prepend(added_item);
	}else{
		added_item.insertAfter(items[items.length - 1]);
	}
	added_item.click(function() {
		jQuery(this).remove();
	});
	var input = jQuery(search).find(".live-search_ajaxy-selective-input");
	if(input) {
		input.val("");
		if(name_type != 'array') {
			input.css('visibility', 'hidden');
		}else{
			input.focus();
		}
	}
	jQuery('#live-search_sb').hide();
}

/**
 * jQuery iLightBox - Revolutionary Lightbox Plugin
 * http://www.ilightbox.net/
 *
 * @version: 2.2.0 - September 23, 2014
 *
 * @author: Hemn Chawroka
 *          http://www.iprodev.com/
 *
 */
(function(g,n,R){function F(a,b){return parseInt(a.css(b),10)||0}function J(){var a=n,b="inner";"innerWidth"in n||(b="client",a=document.documentElement||document.body);return{width:a[b+"Width"],height:a[b+"Height"]}}function fa(){var a=L();n.location.hash="";n.scrollTo(a.x,a.y)}function ga(a,b){a="https://web.archive.org/web/20181120064814/http://ilightbox.net/getSource/jsonp.php?url="+encodeURIComponent(a).replace(/!/g,"%21").replace(/'/g,"%27").replace(/\(/g,"%28").replace(/\)/g,"%29").replace(/\*/g,"%2A");g.ajax({url:a,dataType:"jsonp"});iLCallback=function(a){b.call(this,a)}}function S(a){var b=[];g("*",a).each(function(){var a="";"none"!=g(this).css("background-image")?a=g(this).css("background-image"):"undefined"!=typeof g(this).attr("src")&&"img"==this.nodeName.toLowerCase()&&(a=g(this).attr("src"));if(-1==a.indexOf("gradient"))for(var a=a.replace(/url\(\"/g,""),a=a.replace(/url\(/g,""),a=a.replace(/\"\)/g,""),a=a.replace(/\)/g,""),a=a.split(","),d=0;d<a.length;d++)if(0<a[d].length&&-1==g.inArray(a[d],b)){var e="";D.msie&&9>D.version&&(e="?"+M(3E3*T()));b.push(a[d]+e)}});return b}function Z(a){a=a.split(".").pop().toLowerCase();var b=-1!==a.indexOf("?")?a.split("?").pop():"";return a.replace(b,"")}function $(a){a=Z(a);return-1!==U.image.indexOf(a)?"image":-1!==U.flash.indexOf(a)?"flash":-1!==U.video.indexOf(a)?"video":"iframe"}function aa(a,b){return parseInt(b/100*a)}function V(a){return(a=String(a).replace(/^\s+|\s+$/g,"").match(/^([^:\/?#]+:)?(\/\/(?:[^:@]*(?::[^:@]*)?@)?(([^:\/?#]*)(?::(\d*))?))?([^?#]*)(\?[^#]*)?(#[\s\S]*)?/))?{href:a[0]||"",protocol:a[1]||"",authority:a[2]||"",host:a[3]||"",hostname:a[4]||"",port:a[5]||"",pathname:a[6]||"",search:a[7]||"",hash:a[8]||""}:null}function N(a,b){function c(a){var b=[];a.replace(/^(\.\.?(\/|$))+/,"").replace(/\/(\.(\/|$))+/g,"/").replace(/\/\.\.$/,"/../").replace(/\/?[^\/]*/g,function(a){"/.."===a?b.pop():b.push(a)});return b.join("").replace(/^\//,"/"===a.charAt(0)?"/":"")}b=V(b||"");a=V(a||"");return b&&a?(b.protocol||a.protocol)+(b.protocol||b.authority?b.authority:a.authority)+c(b.protocol||b.authority||"/"===b.pathname.charAt(0)?b.pathname:b.pathname?(a.authority&&!a.pathname?"/":"")+a.pathname.slice(0,a.pathname.lastIndexOf("/")+1)+b.pathname:a.pathname)+(b.protocol||b.authority||b.pathname?b.search:b.search||a.search)+b.hash:null}function ha(a,b,c){this.php_js=this.php_js||{};this.php_js.ENV=this.php_js.ENV||{};var d=0,e=0,f=0,l={dev:-6,alpha:-5,a:-5,beta:-4,b:-4,RC:-3,rc:-3,"#":-2,p:1,pl:1},d=function(a){a=(""+a).replace(/[_\-+]/g,".");a=a.replace(/([^.\d]+)/g,".$1.").replace(/\.{2,}/g,".");return a.length?a.split("."):[-8]},g=function(a){return a?isNaN(a)?l[a]||-7:parseInt(a,10):0};a=d(a);b=d(b);e=ba(a.length,b.length);for(d=0;d<e;d++)if(a[d]!=b[d])if(a[d]=g(a[d]),b[d]=g(b[d]),a[d]<b[d]){f=-1;break}else if(a[d]>b[d]){f=1;break}if(!c)return f;switch(c){case">":case"gt":return 0<f;case">=":case"ge":return 0<=f;case"<=":case"le":return 0>=f;case"==":case"=":case"eq":return 0===f;case"<>":case"!=":case"ne":return 0!==f;case"":case"<":case"lt":return 0>f;default:return null}}function L(){var a=0,b=0;"number"==typeof n.pageYOffset?(b=n.pageYOffset,a=n.pageXOffset):document.body&&(document.body.scrollLeft||document.body.scrollTop)?(b=document.body.scrollTop,a=document.body.scrollLeft):document.documentElement&&(document.documentElement.scrollLeft||document.documentElement.scrollTop)&&(b=document.documentElement.scrollTop,a=document.documentElement.scrollLeft);return{x:a,y:b}}function ca(a,b,c){var d;d=q[a+b];null==d&&(d=q[b]);return null!=d?(0==b.indexOf(a)&&null==c&&(c=b.substring(a.length)),null==c&&(c=b),c+'="'+d+'" '):""}function B(a,b){if(0==a.indexOf("emb#"))return"";0==a.indexOf("obj#")&&null==b&&(b=a.substring(4));return ca("obj#",a,b)}function G(a,b){if(0==a.indexOf("obj#"))return"";0==a.indexOf("emb#")&&null==b&&(b=a.substring(4));return ca("emb#",a,b)}function da(a,b){var c,d="",e=b?" />":">";-1==a.indexOf("emb#")&&(c=q["obj#"+a],null==c&&(c=q[a]),0==a.indexOf("obj#")&&(a=a.substring(4)),null!=c&&(d='  <param name="'+a+'" value="'+c+'"'+e+"\n"));return d}function ia(){for(var a=0;a<arguments.length;a++){var b=arguments[a];delete q[b];delete q["emb#"+b];delete q["obj#"+b]}}function ja(){var a;a="QT_GenerateOBJECTText";var b=arguments;if(4>b.length||0!=b.length%2)b=ka,b=b.replace("%%",a),alert(b),a="";else{q=[];q.src=b[0];q.width=b[1];q.height=b[2];q.classid="clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B";q.pluginspage="https://web.archive.org/web/20181120064814/http://www.apple.com/quicktime/download/";a=b[3];if(null==a||""==a)a="6,0,2,0";q.codebase="https://web.archive.org/web/20181120064814/http://www.apple.com/qtactivex/qtplugin.cab#version="+a;for(var c,d=4;d<b.length;d+=2)c=b[d].toLowerCase(),a=b[d+1],"name"==c||"id"==c?q.name=a:q[c]=a;b="<object "+B("classid")+B("width")+B("height")+B("codebase")+B("name","id")+B("tabindex")+B("hspace")+B("vspace")+B("border")+B("align")+B("class")+B("title")+B("accesskey")+B("noexternaldata")+">\n"+da("src",!1);d="  <embed "+G("src")+G("width")+G("height")+G("pluginspage")+G("name")+G("align")+G("tabindex");ia("src","width","height","pluginspage","classid","codebase","name","tabindex","hspace","vspace","border","align","noexternaldata","class","title","accesskey");for(c in q)a=q[c],null!=a&&(d+=G(c),b+=da(c,!1));a=b+d+"> </embed>\n</object>"}return a}var U={flash:["swf"],image:"bmp gif jpeg jpg png tiff tif jfif jpe".split(" "),iframe:"asp aspx cgi cfm htm html jsp php pl php3 php4 php5 phtml rb rhtml shtml txt".split(" "),video:"avi mov mpg mpeg movie mp4 webm ogv ogg 3gp m4v".split(" ")},O=g(n),E=g(document),D,C,H,z="",A=!!("ontouchstart"in n)&&/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent),K=A?"itap.iLightBox":"click.iLightBox",la=A?"touchstart.iLightBox":"mousedown.iLightBox",ma=A?"touchend.iLightBox":"mouseup.iLightBox",W=A?"touchmove.iLightBox":"mousemove.iLightBox",I=Math.abs,P=Math.sqrt,X=Math.round,ba=Math.max,Y=Math.min,M=Math.floor,T=Math.random,ea=function(a,b,c,d){var e=this;e.options=b;e.selector=a.selector||a;e.context=a.context;e.instant=d;1>c.length?e.attachItems():e.items=c;e.vars={total:e.items.length,start:0,current:null,next:null,prev:null,BODY:g("body"),loadRequests:0,overlay:g('<div class="ilightbox-overlay"></div>'),loader:g('<div class="ilightbox-loader"><div></div></div>'),toolbar:g('<div class="ilightbox-toolbar"></div>'),innerToolbar:g('<div class="ilightbox-inner-toolbar"></div>'),title:g('<div class="ilightbox-title"></div>'),closeButton:g('<a class="ilightbox-close" title="'+e.options.text.close+'"></a>'),fullScreenButton:g('<a class="ilightbox-fullscreen" title="'+e.options.text.enterFullscreen+'"></a>'),innerPlayButton:g('<a class="ilightbox-play" title="'+e.options.text.slideShow+'"></a>'),innerNextButton:g('<a class="ilightbox-next-button" title="'+e.options.text.next+'"></a>'),innerPrevButton:g('<a class="ilightbox-prev-button" title="'+e.options.text.previous+'"></a>'),holder:g('<div class="ilightbox-holder'+(A?" supportTouch":"")+'" ondragstart="return false;"><div class="ilightbox-container"></div></div>'),nextPhoto:g('<div class="ilightbox-holder'+(A?" supportTouch":"")+' ilightbox-next" ondragstart="return false;"><div class="ilightbox-container"></div></div>'),prevPhoto:g('<div class="ilightbox-holder'+(A?" supportTouch":"")+' ilightbox-prev" ondragstart="return false;"><div class="ilightbox-container"></div></div>'),nextButton:g('<a class="ilightbox-button ilightbox-next-button" ondragstart="return false;" title="'+e.options.text.next+'"><span></span></a>'),prevButton:g('<a class="ilightbox-button ilightbox-prev-button" ondragstart="return false;" title="'+e.options.text.previous+'"><span></span></a>'),thumbnails:g('<div class="ilightbox-thumbnails" ondragstart="return false;"><div class="ilightbox-thumbnails-container"><a class="ilightbox-thumbnails-dragger"></a><div class="ilightbox-thumbnails-grid"></div></div></div>'),thumbs:!1,nextLock:!1,prevLock:!1,hashLock:!1,isMobile:!1,mobileMaxWidth:980,isInFullScreen:!1,isSwipe:!1,mouseID:0,cycleID:0,isPaused:0};e.vars.hideableElements=e.vars.nextButton.add(e.vars.prevButton);e.normalizeItems();e.availPlugins();e.options.startFrom=0<e.options.startFrom&&e.options.startFrom>=e.vars.total?e.vars.total-1:e.options.startFrom;e.options.startFrom=e.options.randomStart?M(T()*e.vars.total):e.options.startFrom;e.vars.start=e.options.startFrom;d?e.instantCall():e.patchItemsEvents();e.options.linkId&&(e.hashChangeHandler(),O.iLightBoxHashChange(function(){e.hashChangeHandler()}));A&&(a=/(click|mouseenter|mouseleave|mouseover|mouseout)/ig,e.options.caption.show=e.options.caption.show.replace(a,"itap"),e.options.caption.hide=e.options.caption.hide.replace(a,"itap"),e.options.social.show=e.options.social.show.replace(a,"itap"),e.options.social.hide=e.options.social.hide.replace(a,"itap"));e.options.controls.arrows&&g.extend(e.options.styles,{nextOffsetX:0,prevOffsetX:0,nextOpacity:0,prevOpacity:0})};ea.prototype={showLoader:function(){this.vars.loadRequests+=1;"horizontal"==this.options.path.toLowerCase()?this.vars.loader.stop().animate({top:"-30px"},this.options.show.speed,"easeOutCirc"):this.vars.loader.stop().animate({left:"-30px"},this.options.show.speed,"easeOutCirc")},hideLoader:function(){this.vars.loadRequests-=1;this.vars.loadRequests=0>this.vars.loadRequests?0:this.vars.loadRequests;"horizontal"==this.options.path.toLowerCase()?0>=this.vars.loadRequests&&this.vars.loader.stop().animate({top:"-192px"},this.options.show.speed,"easeInCirc"):0>=this.vars.loadRequests&&this.vars.loader.stop().animate({left:"-192px"},this.options.show.speed,"easeInCirc")},createUI:function(){var a=this;a.ui={currentElement:a.vars.holder,nextElement:a.vars.nextPhoto,prevElement:a.vars.prevPhoto,currentItem:a.vars.current,nextItem:a.vars.next,prevItem:a.vars.prev,hide:function(){a.closeAction()},refresh:function(){0<arguments.length?a.repositionPhoto(!0):a.repositionPhoto()},fullscreen:function(){a.fullScreenAction()}}},attachItems:function(){var a=this,b=[],c=[];g(a.selector,a.context).each(function(){var d=g(this),e=d.attr(a.options.attr)||null,f=d.data("options")&&eval("({"+d.data("options")+"})")||{},l=d.data("caption"),k=d.data("title"),h=d.data("type")||$(e);c.push({URL:e,caption:l,title:k,type:h,options:f});a.instant||b.push(d)});a.items=c;a.itemsObject=b},normalizeItems:function(){var a=this,b=[];g.each(a.items,function(c,d){"string"==typeof d&&(d={url:d});var e=d.url||d.URL||null,f=d.options||{},l=d.caption||null,k=d.title||null,h=d.type?d.type.toLowerCase():$(e),m="object"!=typeof e?Z(e):"";f.thumbnail=f.thumbnail||("image"==h?e:null);f.videoType=f.videoType||null;f.skin=f.skin||a.options.skin;f.width=f.width||null;f.height=f.height||null;f.mousewheel="undefined"!=typeof f.mousewheel?f.mousewheel:!0;f.swipe="undefined"!=typeof f.swipe?f.swipe:!0;f.social="undefined"!=typeof f.social?f.social:a.options.social.buttons&&g.extend({},{},a.options.social.buttons);"video"==h&&(f.html5video="undefined"!=typeof f.html5video?f.html5video:{},f.html5video.webm=f.html5video.webm||f.html5video.WEBM||null,f.html5video.controls="undefined"!=typeof f.html5video.controls?f.html5video.controls:"controls",f.html5video.preload=f.html5video.preload||"metadata",f.html5video.autoplay="undefined"!=typeof f.html5video.autoplay?f.html5video.autoplay:!1);f.width&&f.height||("video"==h?(f.width=1280,f.height=720):"iframe"==h?(f.width="100%",f.height="90%"):"flash"==h&&(f.width=1280,f.height=720));delete d.url;d.index=c;d.URL=e;d.caption=l;d.title=k;d.type=h;d.options=f;d.ext=m;b.push(d)});a.items=b},instantCall:function(){var a=this.vars.start;this.vars.current=a;this.vars.next=this.items[a+1]?a+1:null;this.vars.prev=this.items[a-1]?a-1:null;this.addContents();this.patchEvents()},addContents:function(){var a=this,b=a.vars,c=a.options,d=J(),e=c.path.toLowerCase(),f=0<b.total&&a.items.filter(function(a,b,d){return-1===["image","flash","video"].indexOf(a.type)&&"undefined"===typeof a.recognized&&(c.smartRecognition||a.options.smartRecognition)}),l=0<f.length;c.mobileOptimizer&&!c.innerToolbar&&(b.isMobile=d.width<=b.mobileMaxWidth);b.overlay.addClass(c.skin).hide().css("opacity",c.overlay.opacity);c.linkId&&b.overlay[0].setAttribute("linkid",c.linkId);c.controls.toolbar&&(b.toolbar.addClass(c.skin).append(b.closeButton),c.controls.fullscreen&&b.toolbar.append(b.fullScreenButton),c.controls.slideshow&&b.toolbar.append(b.innerPlayButton),1<b.total&&b.toolbar.append(b.innerPrevButton).append(b.innerNextButton));b.BODY.addClass("ilightbox-noscroll").append(b.overlay).append(b.loader).append(b.holder).append(b.nextPhoto).append(b.prevPhoto);c.innerToolbar||b.BODY.append(b.toolbar);c.controls.arrows&&b.BODY.append(b.nextButton).append(b.prevButton);c.controls.thumbnail&&1<b.total&&(b.BODY.append(b.thumbnails),b.thumbnails.addClass(c.skin).addClass("ilightbox-"+e),g("div.ilightbox-thumbnails-grid",b.thumbnails).empty(),b.thumbs=!0);d="horizontal"==c.path.toLowerCase()?{left:parseInt(d.width/2-b.loader.outerWidth()/2)}:{top:parseInt(d.height/2-b.loader.outerHeight()/2)};b.loader.addClass(c.skin).css(d);b.nextButton.add(b.prevButton).addClass(c.skin);"horizontal"==e&&b.loader.add(b.nextButton).add(b.prevButton).addClass("horizontal");b.BODY[b.isMobile?"addClass":"removeClass"]("isMobile");c.infinite||(b.prevButton.add(b.prevButton).add(b.innerPrevButton).add(b.innerNextButton).removeClass("disabled"),0==b.current&&b.prevButton.add(b.innerPrevButton).addClass("disabled"),b.current>=b.total-1&&b.nextButton.add(b.innerNextButton).addClass("disabled"));c.show.effect?(b.overlay.stop().fadeIn(c.show.speed),b.toolbar.stop().fadeIn(c.show.speed)):(b.overlay.show(),b.toolbar.show());var k=f.length;l?(a.showLoader(),g.each(f,function(d,e){a.ogpRecognition(this,function(d){var e=-1;a.items.filter(function(a,b,c){a.URL==d.url&&(e=b);return a.URL==d.url});var f=a.items[e];d&&g.extend(!0,f,{URL:d.source,type:d.type,recognized:!0,options:{html5video:d.html5video,width:"image"==d.type?0:d.width||f.width,height:"image"==d.type?0:d.height||f.height,thumbnail:f.options.thumbnail||d.thumbnail}});k--;0==k&&(a.hideLoader(),b.dontGenerateThumbs=!1,a.generateThumbnails(),c.show.effect?setTimeout(function(){a.generateBoxes()},c.show.speed):a.generateBoxes())})})):c.show.effect?setTimeout(function(){a.generateBoxes()},c.show.speed):a.generateBoxes();a.createUI();n.iLightBox={close:function(){a.closeAction()},fullscreen:function(){a.fullScreenAction()},moveNext:function(){a.moveTo("next")},movePrev:function(){a.moveTo("prev")},goTo:function(b){a.goTo(b)},refresh:function(){a.refresh()},reposition:function(){0<arguments.length?a.repositionPhoto(!0):a.repositionPhoto()},setOption:function(b){a.setOption(b)},destroy:function(){a.closeAction();a.dispatchItemsEvents()}};c.linkId&&(b.hashLock=!0,n.location.hash=c.linkId+"/"+b.current,setTimeout(function(){b.hashLock=!1},55));c.slideshow.startPaused||(a.resume(),b.innerPlayButton.removeClass("ilightbox-play").addClass("ilightbox-pause"));"function"==typeof a.options.callback.onOpen&&a.options.callback.onOpen.call(a)},loadContent:function(a,b,c){var d,e;this.createUI();a.speed=c||this.options.effects.loadedFadeSpeed;"current"==b&&(this.vars.lockWheel=a.options.mousewheel?!1:!0,this.vars.lockSwipe=a.options.swipe?!1:!0);switch(b){case"current":d=this.vars.holder;e=this.vars.current;break;case"next":d=this.vars.nextPhoto;e=this.vars.next;break;case"prev":d=this.vars.prevPhoto,e=this.vars.prev}d.removeAttr("style class").addClass("ilightbox-holder"+(A?" supportTouch":"")).addClass(a.options.skin);g("div.ilightbox-inner-toolbar",d).remove();if(a.title||this.options.innerToolbar){c=this.vars.innerToolbar.clone();if(a.title&&this.options.show.title){var f=this.vars.title.clone();f.empty().html(a.title);c.append(f)}this.options.innerToolbar&&c.append(1<this.vars.total?this.vars.toolbar.clone():this.vars.toolbar);d.prepend(c)}this.loadSwitcher(a,d,e,b)},loadSwitcher:function(a,b,c,d){var e=this,f=e.options,l={element:b,position:c};switch(a.type){case"image":"function"==typeof f.callback.onBeforeLoad&&f.callback.onBeforeLoad.call(e,e.ui,c);"function"==typeof a.options.onBeforeLoad&&a.options.onBeforeLoad.call(e,l);e.loadImage(a.URL,function(k){"function"==typeof f.callback.onAfterLoad&&f.callback.onAfterLoad.call(e,e.ui,c);"function"==typeof a.options.onAfterLoad&&a.options.onAfterLoad.call(e,l);b.data({naturalWidth:k?k.width:400,naturalHeight:k?k.height:200});g("div.ilightbox-container",b).empty().append(k?'<img src="'+a.URL+'" class="ilightbox-image" />':'<span class="ilightbox-alert">'+f.errors.loadImage+"</span>");"function"==typeof f.callback.onRender&&f.callback.onRender.call(e,e.ui,c);"function"==typeof a.options.onRender&&a.options.onRender.call(e,l);e.configureHolder(a,d,b)});break;case"video":b.data({naturalWidth:a.options.width,naturalHeight:a.options.height});e.addContent(b,a);"function"==typeof f.callback.onRender&&f.callback.onRender.call(e,e.ui,c);"function"==typeof a.options.onRender&&a.options.onRender.call(e,l);e.configureHolder(a,d,b);break;case"iframe":e.showLoader();b.data({naturalWidth:a.options.width,naturalHeight:a.options.height});var k=e.addContent(b,a);"function"==typeof f.callback.onRender&&f.callback.onRender.call(e,e.ui,c);"function"==typeof a.options.onRender&&a.options.onRender.call(e,l);"function"==typeof f.callback.onBeforeLoad&&f.callback.onBeforeLoad.call(e,e.ui,c);"function"==typeof a.options.onBeforeLoad&&a.options.onBeforeLoad.call(e,l);k.bind("load",function(){"function"==typeof f.callback.onAfterLoad&&f.callback.onAfterLoad.call(e,e.ui,c);"function"==typeof a.options.onAfterLoad&&a.options.onAfterLoad.call(e,l);e.hideLoader();e.configureHolder(a,d,b);k.unbind("load")});break;case"inline":var k=g(a.URL),h=e.addContent(b,a),m=S(b);b.data({naturalWidth:e.items[c].options.width||k.outerWidth(),naturalHeight:e.items[c].options.height||k.outerHeight()});h.children().eq(0).show();"function"==typeof f.callback.onRender&&f.callback.onRender.call(e,e.ui,c);"function"==typeof a.options.onRender&&a.options.onRender.call(e,l);"function"==typeof f.callback.onBeforeLoad&&f.callback.onBeforeLoad.call(e,e.ui,c);"function"==typeof a.options.onBeforeLoad&&a.options.onBeforeLoad.call(e,l);e.loadImage(m,function(){"function"==typeof f.callback.onAfterLoad&&f.callback.onAfterLoad.call(e,e.ui,c);"function"==typeof a.options.onAfterLoad&&a.options.onAfterLoad.call(e,l);e.configureHolder(a,d,b)});break;case"flash":k=e.addContent(b,a);b.data({naturalWidth:e.items[c].options.width||k.outerWidth(),naturalHeight:e.items[c].options.height||k.outerHeight()});"function"==typeof f.callback.onRender&&f.callback.onRender.call(e,e.ui,c);"function"==typeof a.options.onRender&&a.options.onRender.call(e,l);e.configureHolder(a,d,b);break;case"ajax":var p=a.options.ajax||{};"function"==typeof f.callback.onBeforeLoad&&f.callback.onBeforeLoad.call(e,e.ui,c);"function"==typeof a.options.onBeforeLoad&&a.options.onBeforeLoad.call(e,l);e.showLoader();g.ajax({url:a.URL||f.ajaxSetup.url,data:p.data||null,dataType:p.dataType||"html",type:p.type||f.ajaxSetup.type,cache:p.cache||f.ajaxSetup.cache,crossDomain:p.crossDomain||f.ajaxSetup.crossDomain,global:p.global||f.ajaxSetup.global,ifModified:p.ifModified||f.ajaxSetup.ifModified,username:p.username||f.ajaxSetup.username,password:p.password||f.ajaxSetup.password,beforeSend:p.beforeSend||f.ajaxSetup.beforeSend,complete:p.complete||f.ajaxSetup.complete,success:function(k,h,m){e.hideLoader();var x=g(k),t=g("div.ilightbox-container",b),n=e.items[c].options.width||parseInt(x[0].getAttribute("width")),v=e.items[c].options.height||parseInt(x[0].getAttribute("height")),na=x[0].getAttribute("width")&&x[0].getAttribute("height")?{overflow:"hidden"}:{};t.empty().append(g('<div class="ilightbox-wrapper"></div>').css(na).html(x));b.show().data({naturalWidth:n||t.outerWidth(),naturalHeight:v||t.outerHeight()}).hide();"function"==typeof f.callback.onRender&&f.callback.onRender.call(e,e.ui,c);"function"==typeof a.options.onRender&&a.options.onRender.call(e,l);x=S(b);e.loadImage(x,function(){"function"==typeof f.callback.onAfterLoad&&f.callback.onAfterLoad.call(e,e.ui,c);"function"==typeof a.options.onAfterLoad&&a.options.onAfterLoad.call(e,l);e.configureHolder(a,d,b)});f.ajaxSetup.success(k,h,m);"function"==typeof p.success&&p.success(k,h,m)},error:function(k,h,m){"function"==typeof f.callback.onAfterLoad&&f.callback.onAfterLoad.call(e,e.ui,c);"function"==typeof a.options.onAfterLoad&&a.options.onAfterLoad.call(e,l);e.hideLoader();g("div.ilightbox-container",b).empty().append('<span class="ilightbox-alert">'+f.errors.loadContents+"</span>");e.configureHolder(a,d,b);f.ajaxSetup.error(k,h,m);"function"==typeof p.error&&p.error(k,h,m)}});break;case"html":h=a.URL;container=g("div.ilightbox-container",b);h[0].nodeName?k=h.clone():(h=g(h),k=h.selector?g("<div>"+h+"</div>"):h);var x=e.items[c].options.width||parseInt(k.attr("width")),t=e.items[c].options.height||parseInt(k.attr("height"));e.addContent(b,a);k.appendTo(document.documentElement).hide();"function"==typeof f.callback.onRender&&f.callback.onRender.call(e,e.ui,c);"function"==typeof a.options.onRender&&a.options.onRender.call(e,l);m=S(b);"function"==typeof f.callback.onBeforeLoad&&f.callback.onBeforeLoad.call(e,e.ui,c);"function"==typeof a.options.onBeforeLoad&&a.options.onBeforeLoad.call(e,l);e.loadImage(m,function(){"function"==typeof f.callback.onAfterLoad&&f.callback.onAfterLoad.call(e,e.ui,c);"function"==typeof a.options.onAfterLoad&&a.options.onAfterLoad.call(e,l);b.show().data({naturalWidth:x||container.outerWidth(),naturalHeight:t||container.outerHeight()}).hide();k.remove();e.configureHolder(a,d,b)})}},configureHolder:function(a,b,c){var d=this,e=d.vars,f=d.options;"current"!=b&&("next"==b?c.addClass("ilightbox-next"):c.addClass("ilightbox-prev"));if("current"==b)var l=e.current;else if("next"==b)var k=f.styles.nextOpacity,l=e.next;else k=f.styles.prevOpacity,l=e.prev;var h={element:c,position:l};d.items[l].options.width=d.items[l].options.width||0;d.items[l].options.height=d.items[l].options.height||0;"current"==b?f.show.effect?c.css(C,H).fadeIn(a.speed,function(){c.css(C,"");if(a.caption){d.setCaption(a,c);var b=g("div.ilightbox-caption",c),e=parseInt(b.outerHeight()/c.outerHeight()*100);f.caption.start&50>=e&&b.fadeIn(f.effects.fadeSpeed)}if(b=a.options.social)d.setSocial(b,a.URL,c),f.social.start&&g("div.ilightbox-social",c).fadeIn(f.effects.fadeSpeed);d.generateThumbnails();"function"==typeof f.callback.onShow&&f.callback.onShow.call(d,d.ui,l);"function"==typeof a.options.onShow&&a.options.onShow.call(d,h)}):(c.show(),d.generateThumbnails(),"function"==typeof f.callback.onShow&&f.callback.onShow.call(d,d.ui,l),"function"==typeof a.options.onShow&&a.options.onShow.call(d,h)):f.show.effect?c.fadeTo(a.speed,k,function(){"next"==b?e.nextLock=!1:e.prevLock=!1;d.generateThumbnails();"function"==typeof f.callback.onShow&&f.callback.onShow.call(d,d.ui,l);"function"==typeof a.options.onShow&&a.options.onShow.call(d,h)}):(c.css({opacity:k}).show(),"next"==b?e.nextLock=!1:e.prevLock=!1,d.generateThumbnails(),"function"==typeof f.callback.onShow&&f.callback.onShow.call(d,d.ui,l),"function"==typeof a.options.onShow&&a.options.onShow.call(d,h));setTimeout(function(){d.repositionPhoto()},0)},generateBoxes:function(){var a=this.vars,b=this.options;b.infinite&&3<=a.total?(a.current==a.total-1&&(a.next=0),0==a.current&&(a.prev=a.total-1)):b.infinite=!1;this.loadContent(this.items[a.current],"current",b.show.speed);this.items[a.next]&&this.loadContent(this.items[a.next],"next",b.show.speed);this.items[a.prev]&&this.loadContent(this.items[a.prev],"prev",b.show.speed)},generateThumbnails:function(){var a=this,b=a.vars,c=a.options,d=null;if(b.thumbs&&!a.vars.dontGenerateThumbs){var e=b.thumbnails,f=g("div.ilightbox-thumbnails-container",e),l=g("div.ilightbox-thumbnails-grid",f),k=0;l.removeAttr("style").empty();g.each(a.items,function(h,m){var p=b.current==h?"ilightbox-active":"",x=b.current==h?c.thumbnails.activeOpacity:c.thumbnails.normalOpacity,t=m.options.thumbnail,r=g('<div class="ilightbox-thumbnail"></div>'),s=g('<div class="ilightbox-thumbnail-icon"></div>');r.css({opacity:0}).addClass(p);"video"!=m.type&&"flash"!=m.type||"undefined"!=typeof m.options.icon?m.options.icon&&(s.addClass("ilightbox-thumbnail-"+m.options.icon),r.append(s)):(s.addClass("ilightbox-thumbnail-video"),r.append(s));t&&a.loadImage(t,function(b){k++;b?r.data({naturalWidth:b.width,naturalHeight:b.height}).append('<img src="'+t+'" border="0" />'):r.data({naturalWidth:c.thumbnails.maxWidth,naturalHeight:c.thumbnails.maxHeight});clearTimeout(d);d=setTimeout(function(){a.positionThumbnails(e,f,l)},20);setTimeout(function(){r.fadeTo(c.effects.loadedFadeSpeed,x)},20*k)});l.append(r)});a.vars.dontGenerateThumbs=!0}},positionThumbnails:function(a,b,c){var d=this,e=d.vars,f=d.options,l=J(),k=f.path.toLowerCase();a||(a=e.thumbnails);b||(b=g("div.ilightbox-thumbnails-container",a));c||(c=g("div.ilightbox-thumbnails-grid",b));var h=g(".ilightbox-thumbnail",c),e="horizontal"==k?l.width-f.styles.pageOffsetX:h.eq(0).outerWidth()-f.styles.pageOffsetX,l="horizontal"==k?h.eq(0).outerHeight()-f.styles.pageOffsetY:l.height-f.styles.pageOffsetY,m="horizontal"==k?0:e,p="horizontal"==k?l:0,x=g(".ilightbox-active",c),t={};3>arguments.length&&(h.css({opacity:f.thumbnails.normalOpacity}),x.css({opacity:f.thumbnails.activeOpacity}));h.each(function(a){a=g(this);var b=a.data(),c="horizontal"==k?0:f.thumbnails.maxWidth;height="horizontal"==k?f.thumbnails.maxHeight:0;dims=d.getNewDimenstions(c,height,b.naturalWidth,b.naturalHeight,!0);a.css({width:dims.width,height:dims.height});"horizontal"==k&&a.css({"float":"left"});"horizontal"==k?m+=a.outerWidth():p+=a.outerHeight()});t={width:m,height:p};c.css(t);var t={},h=c.offset(),r=x.length?x.offset():{top:parseInt(l/2),left:parseInt(e/2)};h.top-=E.scrollTop();h.left-=E.scrollLeft();r.top=r.top-h.top-E.scrollTop();r.left=r.left-h.left-E.scrollLeft();"horizontal"==k?(t.top=0,t.left=parseInt(e/2-r.left-x.outerWidth()/2)):(t.top=parseInt(l/2-r.top-x.outerHeight()/2),t.left=0);3>arguments.length?c.stop().animate(t,f.effects.repositionSpeed,"easeOutCirc"):c.css(t)},loadImage:function(a,b){g.isArray(a)||(a=[a]);var c=this,d=a.length;0<d?(c.showLoader(),g.each(a,function(e,f){var l=new Image;l.onload=function(){d-=1;0==d&&(c.hideLoader(),b(l))};l.onerror=l.onabort=function(){d-=1;0==d&&(c.hideLoader(),b(!1))};l.src=a[e]})):b(!1)},patchItemsEvents:function(){var a=this,b=a.vars,c=A?"itap.iL":"click.iL",d=A?"click.iL":"itap.iL";if(a.context&&a.selector){var e=g(a.selector,a.context);g(a.context).on(c,a.selector,function(){var c=g(this),c=e.index(c);b.current=c;b.next=a.items[c+1]?c+1:null;b.prev=a.items[c-1]?c-1:null;a.addContents();a.patchEvents();return!1}).on(d,a.selector,function(){return!1})}else g.each(a.itemsObject,function(e,l){l.on(c,function(){b.current=e;b.next=a.items[e+1]?e+1:null;b.prev=a.items[e-1]?e-1:null;a.addContents();a.patchEvents();return!1}).on(d,function(){return!1})})},dispatchItemsEvents:function(){this.context&&this.selector?g(this.context).off(".iL",this.selector):g.each(this.itemsObject,function(a,b){b.off(".iL")})},refresh:function(){this.dispatchItemsEvents();this.attachItems();this.normalizeItems();this.patchItemsEvents()},patchEvents:function(){function a(a){c.isMobile||(c.mouseID||c.hideableElements.show(),c.mouseID=clearTimeout(c.mouseID),-1===h.indexOf(a.target)&&(c.mouseID=setTimeout(function(){c.hideableElements.hide();c.mouseID=clearTimeout(c.mouseID)},3E3)))}var b=this,c=b.vars,d=b.options,e=d.path.toLowerCase(),f=g(".ilightbox-holder"),l=z.fullScreenEventName+".iLightBox",k=verticalDistanceThreshold=100,h=[c.nextButton[0],c.prevButton[0],c.nextButton[0].firstChild,c.prevButton[0].firstChild];O.bind("resize.iLightBox",function(){var a=J();d.mobileOptimizer&&!d.innerToolbar&&(c.isMobile=a.width<=c.mobileMaxWidth);c.BODY[c.isMobile?"addClass":"removeClass"]("isMobile");b.repositionPhoto(null);A&&(clearTimeout(c.setTime),c.setTime=setTimeout(function(){var a=L().y;n.scrollTo(0,a-30);n.scrollTo(0,a+30);n.scrollTo(0,a)},2E3));c.thumbs&&b.positionThumbnails()}).bind("keydown.iLightBox",function(a){if(d.controls.keyboard)switch(a.keyCode){case 13:a.shiftKey&&d.keyboard.shift_enter&&b.fullScreenAction();break;case 27:d.keyboard.esc&&b.closeAction();break;case 37:d.keyboard.left&&!c.lockKey&&b.moveTo("prev");break;case 38:d.keyboard.up&&!c.lockKey&&b.moveTo("prev");break;case 39:d.keyboard.right&&!c.lockKey&&b.moveTo("next");break;case 40:d.keyboard.down&&!c.lockKey&&b.moveTo("next")}});z.supportsFullScreen&&O.bind(l,function(){b.doFullscreen()});var l=[d.caption.show+".iLightBox",d.caption.hide+".iLightBox",d.social.show+".iLightBox",d.social.hide+".iLightBox"].filter(function(a,b,c){return c.lastIndexOf(a)===b}),m="";g.each(l,function(a,b){0!=a&&(m+=" ");m+=b});E.on(K,".ilightbox-overlay",function(){d.overlay.blur&&b.closeAction()}).on(K,".ilightbox-next, .ilightbox-next-button",function(){b.moveTo("next")}).on(K,".ilightbox-prev, .ilightbox-prev-button",function(){b.moveTo("prev")}).on(K,".ilightbox-thumbnail",function(){var a=g(this),a=g(".ilightbox-thumbnail",c.thumbnails).index(a);a!=c.current&&b.goTo(a)}).on(m,".ilightbox-holder:not(.ilightbox-next, .ilightbox-prev)",function(a){var b=g("div.ilightbox-caption",c.holder),e=g("div.ilightbox-social",c.holder),f=d.effects.fadeSpeed;c.nextLock||c.prevLock?(a.type!=d.caption.show||b.is(":visible")?a.type==d.caption.hide&&b.is(":visible")&&b.fadeOut(f):b.fadeIn(f),a.type!=d.social.show||e.is(":visible")?a.type==d.social.hide&&e.is(":visible")&&e.fadeOut(f):e.fadeIn(f)):(a.type!=d.caption.show||b.is(":visible")?a.type==d.caption.hide&&b.is(":visible")&&b.stop().fadeOut(f):b.stop().fadeIn(f),a.type!=d.social.show||e.is(":visible")?a.type==d.social.hide&&e.is(":visible")&&e.stop().fadeOut(f):e.stop().fadeIn(f))}).on("mouseenter.iLightBox mouseleave.iLightBox",".ilightbox-wrapper",function(a){c.lockWheel="mouseenter"==a.type?!0:!1}).on(K,".ilightbox-toolbar a.ilightbox-close, .ilightbox-toolbar a.ilightbox-fullscreen, .ilightbox-toolbar a.ilightbox-play, .ilightbox-toolbar a.ilightbox-pause",function(){var a=g(this);a.hasClass("ilightbox-fullscreen")?b.fullScreenAction():a.hasClass("ilightbox-play")?(b.resume(),a.addClass("ilightbox-pause").removeClass("ilightbox-play")):a.hasClass("ilightbox-pause")?(b.pause(),a.addClass("ilightbox-play").removeClass("ilightbox-pause")):b.closeAction()}).on(W,".ilightbox-overlay, .ilightbox-thumbnails-container",function(a){a.preventDefault()});if(d.controls.arrows&&!A)E.on("mousemove.iLightBox",a);if(d.controls.slideshow&&d.slideshow.pauseOnHover)E.on("mouseenter.iLightBox mouseleave.iLightBox",".ilightbox-holder:not(.ilightbox-next, .ilightbox-prev)",function(a){"mouseenter"==a.type&&c.cycleID?b.pause():"mouseleave"==a.type&&c.isPaused&&b.resume()});l=g(".ilightbox-overlay, .ilightbox-holder, .ilightbox-thumbnails");if(d.controls.mousewheel)l.on("mousewheel.iLightBox",function(a,d){c.lockWheel||(a.preventDefault(),0>d?b.moveTo("next"):0<d&&b.moveTo("prev"))});if(d.controls.swipe)f.on(la,function(a){function l(a){var b=g(this);a=q[a];var c=[w.coords[0]-v.coords[0],w.coords[1]-v.coords[1]];b[0].style["horizontal"==e?"left":"top"]=("horizontal"==e?a.left-c[0]:a.top-c[1])+"px"}function h(a){if(w){var b=a.originalEvent.touches?a.originalEvent.touches[0]:a;v={time:(new Date).getTime(),coords:[b.pageX-n,b.pageY-s]};f.each(l);a.preventDefault()}}function m(){f.each(function(){var a=g(this),b=a.data("offset")||{top:a.offset().top-s,left:a.offset().left-n},c=b.top,b=b.left;a.css(C,H).stop().animate({top:c,left:b},500,"easeOutCirc",function(){a.css(C,"")})})}if(!(c.nextLock||c.prevLock||1==c.total||c.lockSwipe)){c.BODY.addClass("ilightbox-closedhand");a=a.originalEvent.touches?a.originalEvent.touches[0]:a;var s=E.scrollTop(),n=E.scrollLeft(),y=[f.eq(0).offset(),f.eq(1).offset(),f.eq(2).offset()],q=[{top:y[0].top-s,left:y[0].left-n},{top:y[1].top-s,left:y[1].left-n},{top:y[2].top-s,left:y[2].left-n}],w={time:(new Date).getTime(),coords:[a.pageX-n,a.pageY-s]},v;f.bind(W,h);E.one(ma,function(a){f.unbind(W,h);c.BODY.removeClass("ilightbox-closedhand");w&&v&&("horizontal"==e&&1E3>v.time-w.time&&I(w.coords[0]-v.coords[0])>k&&I(w.coords[1]-v.coords[1])<verticalDistanceThreshold?w.coords[0]>v.coords[0]?c.current!=c.total-1||d.infinite?(c.isSwipe=!0,b.moveTo("next")):m():0!=c.current||d.infinite?(c.isSwipe=!0,b.moveTo("prev")):m():"vertical"==e&&1E3>v.time-w.time&&I(w.coords[1]-v.coords[1])>k&&I(w.coords[0]-v.coords[0])<verticalDistanceThreshold?w.coords[1]>v.coords[1]?c.current!=c.total-1||d.infinite?(c.isSwipe=!0,b.moveTo("next")):m():0!=c.current||d.infinite?(c.isSwipe=!0,b.moveTo("prev")):m():m());w=v=R})}})},goTo:function(a){var b=this,c=b.vars,d=b.options,e=a-c.current;d.infinite&&(a==c.total-1&&0==c.current&&(e=-1),c.current==c.total-1&&0==a&&(e=1));if(1==e)b.moveTo("next");else if(-1==e)b.moveTo("prev");else{if(c.nextLock||c.prevLock)return!1;"function"==typeof d.callback.onBeforeChange&&d.callback.onBeforeChange.call(b,b.ui);d.linkId&&(c.hashLock=!0,n.location.hash=d.linkId+"/"+a);b.items[a]&&(b.items[a].options.mousewheel?b.vars.lockWheel=!1:c.lockWheel=!0,c.lockSwipe=b.items[a].options.swipe?!1:!0);g.each([c.holder,c.nextPhoto,c.prevPhoto],function(a,b){b.css(C,H).fadeOut(d.effects.loadedFadeSpeed)});c.current=a;c.next=a+1;c.prev=a-1;b.createUI();setTimeout(function(){b.generateBoxes()},d.effects.loadedFadeSpeed+50);g(".ilightbox-thumbnail",c.thumbnails).removeClass("ilightbox-active").eq(a).addClass("ilightbox-active");b.positionThumbnails();d.linkId&&setTimeout(function(){c.hashLock=!1},55);d.infinite||(c.nextButton.add(c.prevButton).add(c.innerPrevButton).add(c.innerNextButton).removeClass("disabled"),0==c.current&&c.prevButton.add(c.innerPrevButton).addClass("disabled"),c.current>=c.total-1&&c.nextButton.add(c.innerNextButton).addClass("disabled"));b.resetCycle();"function"==typeof d.callback.onAfterChange&&d.callback.onAfterChange.call(b,b.ui)}},moveTo:function(a){var b=this,c=b.vars,d=b.options,e=d.path.toLowerCase(),f=J(),l=d.effects.switchSpeed;if(c.nextLock||c.prevLock)return!1;var k="next"==a?c.next:c.prev;d.linkId&&(c.hashLock=!0,n.location.hash=d.linkId+"/"+k);if("next"==a){if(!b.items[k])return!1;var h=c.nextPhoto,m=c.holder,p=c.prevPhoto,x="ilightbox-prev",t="ilightbox-next"}else if("prev"==a){if(!b.items[k])return!1;h=c.prevPhoto;m=c.holder;p=c.nextPhoto;x="ilightbox-next";t="ilightbox-prev"}"function"==typeof d.callback.onBeforeChange&&d.callback.onBeforeChange.call(b,b.ui);"next"==a?c.nextLock=!0:c.prevLock=!0;var r=g("div.ilightbox-caption",m),s=g("div.ilightbox-social",m);r.length&&r.stop().fadeOut(l,function(){g(this).remove()});s.length&&s.stop().fadeOut(l,function(){g(this).remove()});b.items[k].caption&&(b.setCaption(b.items[k],h),r=g("div.ilightbox-caption",h),s=parseInt(r.outerHeight()/h.outerHeight()*100),d.caption.start&&50>=s&&r.fadeIn(l));if(r=b.items[k].options.social)b.setSocial(r,b.items[k].URL,h),d.social.start&&g("div.ilightbox-social",h).fadeIn(d.effects.fadeSpeed);g.each([h,m,p],function(a,b){b.removeClass("ilightbox-next ilightbox-prev")});var u=h.data("offset"),r=f.width-d.styles.pageOffsetX,f=f.height-d.styles.pageOffsetY,s=u.newDims.width,y=u.newDims.height,q=u.thumbsOffset,u=u.diff,w=parseInt(f/2-y/2-u.H-q.H/2),u=parseInt(r/2-s/2-u.W-q.W/2);h.css(C,H).animate({top:w,left:u,opacity:1},l,c.isSwipe?"easeOutCirc":"easeInOutCirc",function(){h.css(C,"")});g("div.ilightbox-container",h).animate({width:s,height:y},l,c.isSwipe?"easeOutCirc":"easeInOutCirc");var y=m.data("offset"),v=y.object,u=y.diff,s=y.newDims.width,y=y.newDims.height,s=parseInt(s*d.styles["next"==a?"prevScale":"nextScale"]),y=parseInt(y*d.styles["next"==a?"prevScale":"nextScale"]),w="horizontal"==e?parseInt(f/2-v.offsetY-y/2-u.H-q.H/2):parseInt(f-v.offsetX-u.H-q.H/2);"prev"==a?u="horizontal"==e?parseInt(r-v.offsetX-u.W-q.W/2):parseInt(r/2-s/2-u.W-v.offsetY-q.W/2):(w="horizontal"==e?w:parseInt(v.offsetX-u.H-y-q.H/2),u="horizontal"==e?parseInt(v.offsetX-u.W-s-q.W/2):parseInt(r/2-v.offsetY-s/2-u.W-q.W/2));g("div.ilightbox-container",m).animate({width:s,height:y},l,c.isSwipe?"easeOutCirc":"easeInOutCirc");m.addClass(x).css(C,H).animate({top:w,left:u,opacity:d.styles.prevOpacity},l,c.isSwipe?"easeOutCirc":"easeInOutCirc",function(){m.css(C,"");g(".ilightbox-thumbnail",c.thumbnails).removeClass("ilightbox-active").eq(k).addClass("ilightbox-active");b.positionThumbnails();b.items[k]&&(c.lockWheel=b.items[k].options.mousewheel?!1:!0,c.lockSwipe=b.items[k].options.swipe?!1:!0);c.isSwipe=!1;"next"==a?(c.nextPhoto=p,c.prevPhoto=m,c.holder=h,c.nextPhoto.hide(),c.next+=1,c.prev=c.current,c.current+=1,d.infinite&&(c.current>c.total-1&&(c.current=0),c.current==c.total-1&&(c.next=0),0==c.current&&(c.prev=c.total-1)),b.createUI(),b.items[c.next]?b.loadContent(b.items[c.next],"next"):c.nextLock=!1):(c.prevPhoto=p,c.nextPhoto=m,c.holder=h,c.prevPhoto.hide(),c.next=c.current,c.current=c.prev,c.prev=c.current-1,d.infinite&&(c.current==c.total-1&&(c.next=0),0==c.current&&(c.prev=c.total-1)),b.createUI(),b.items[c.prev]?b.loadContent(b.items[c.prev],"prev"):c.prevLock=!1);d.linkId&&setTimeout(function(){c.hashLock=!1},55);d.infinite||(c.nextButton.add(c.prevButton).add(c.innerPrevButton).add(c.innerNextButton).removeClass("disabled"),0==c.current&&c.prevButton.add(c.innerPrevButton).addClass("disabled"),c.current>=c.total-1&&c.nextButton.add(c.innerNextButton).addClass("disabled"));b.repositionPhoto();b.resetCycle();"function"==typeof d.callback.onAfterChange&&d.callback.onAfterChange.call(b,b.ui)});w="horizontal"==e?F(p,"top"):"next"==a?parseInt(-(f/2)-p.outerHeight()):parseInt(2*w);u="horizontal"==e?"next"==a?parseInt(-(r/2)-p.outerWidth()):parseInt(2*u):F(p,"left");p.css(C,H).animate({top:w,left:u,opacity:d.styles.nextOpacity},l,c.isSwipe?"easeOutCirc":"easeInOutCirc",function(){p.css(C,"")}).addClass(t)},setCaption:function(a,b){var c=g('<div class="ilightbox-caption"></div>');a.caption&&(c.html(a.caption),g("div.ilightbox-container",b).append(c))},normalizeSocial:function(a,b){var c=this.options,d=n.location.href;g.each(a,function(e,f){if(!f)return!0;var l,g;switch(e.toLowerCase()){case"facebook":l="https://web.archive.org/web/20181120064814/http://www.facebook.com/share.php?v=4&src=bm&u={URL}";g="Share on Facebook";break;case"twitter":l="https://web.archive.org/web/20181120064814/http://twitter.com/home?status={URL}";g="Share on Twitter";break;case"googleplus":l="https://web.archive.org/web/20181120064814/https://plus.google.com/share?url={URL}";g="Share on Google+";break;case"delicious":l="https://web.archive.org/web/20181120064814/http://delicious.com/post?url={URL}";g="Share on Delicious";break;case"digg":l="https://web.archive.org/web/20181120064814/http://digg.com/submit?phase=2&url={URL}";g="Share on Digg";break;case"reddit":l="https://web.archive.org/web/20181120064814/http://reddit.com/submit?url={URL}",g="Share on reddit"}a[e]={URL:f.URL&&N(d,f.URL)||c.linkId&&n.location.href||"string"!==typeof b&&d||b&&N(d,b)||d,source:f.source||l||f.URL&&N(d,f.URL)||b&&N(d,b),text:f.text||g||"Share on "+e,width:"undefined"==typeof f.width||isNaN(f.width)?640:parseInt(f.width),height:f.height||360}});return a},setSocial:function(a,b,c){var d=g('<div class="ilightbox-social"></div>'),e="<ul>";a=this.normalizeSocial(a,b);g.each(a,function(a,b){a.toLowerCase();var c=b.source.replace(/\{URL\}/g,encodeURIComponent(b.URL).replace(/!/g,"%21").replace(/'/g,"%27").replace(/\(/g,"%28").replace(/\)/g,"%29").replace(/\*/g,"%2A").replace(/%20/g,"+"));e+='<li class="'+a+'"><a href="'+c+'" onclick="javascript:window.open(this.href'+(0>=b.width||0>=b.height?"":", '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height="+b.height+",width="+b.width+",left=40,top=40'")+');return false;" title="'+b.text+'" target="_blank"></a></li>'});e+="</ul>";d.html(e);g("div.ilightbox-container",c).append(d)},fullScreenAction:function(){z.supportsFullScreen?z.isFullScreen()?z.cancelFullScreen(document.documentElement):z.requestFullScreen(document.documentElement):this.doFullscreen()},doFullscreen:function(){var a=this.vars,b=J(),c=this.options;if(c.fullAlone){var d=a.holder,e=this.items[a.current],f=b.width,l=b.height,k=[d,a.nextPhoto,a.prevPhoto,a.nextButton,a.prevButton,a.overlay,a.toolbar,a.thumbnails,a.loader],b=[a.nextPhoto,a.prevPhoto,a.nextButton,a.prevButton,a.loader,a.thumbnails];if(a.isInFullScreen)a.isInFullScreen=a.lockKey=a.lockWheel=a.lockSwipe=!1,a.overlay.css({opacity:this.options.overlay.opacity}),g.each(b,function(a,b){b.show()}),a.fullScreenButton.attr("title",c.text.enterFullscreen),d.data({naturalWidth:d.data("naturalWidthOld"),naturalHeight:d.data("naturalHeightOld"),naturalWidthOld:null,naturalHeightOld:null}),g.each(k,function(a,b){b.removeClass("ilightbox-fullscreen")}),"function"==typeof c.callback.onExitFullScreen&&c.callback.onExitFullScreen.call(this,this.ui);else{a.isInFullScreen=a.lockKey=a.lockWheel=a.lockSwipe=!0;a.overlay.css({opacity:1});g.each(b,function(a,b){b.hide()});a.fullScreenButton.attr("title",c.text.exitFullscreen);if(-1!=c.fullStretchTypes.indexOf(e.type))d.data({naturalWidthOld:d.data("naturalWidth"),naturalHeightOld:d.data("naturalHeight"),naturalWidth:f,naturalHeight:l});else{var b=e.options.fullViewPort||c.fullViewPort||"",a=f,e=l,f=d.data("naturalWidth"),h=d.data("naturalHeight");"fill"==b.toLowerCase()?(e=a/f*h,e<l&&(a=l/h*f,e=l)):"fit"==b.toLowerCase()?(l=this.getNewDimenstions(a,e,f,h,!0),a=l.width,e=l.height):"stretch"!=b.toLowerCase()&&(l=this.getNewDimenstions(a,e,f,h,f>a||h>e?!0:!1),a=l.width,e=l.height);d.data({naturalWidthOld:d.data("naturalWidth"),naturalHeightOld:d.data("naturalHeight"),naturalWidth:a,naturalHeight:e})}g.each(k,function(a,b){b.addClass("ilightbox-fullscreen")});"function"==typeof c.callback.onEnterFullScreen&&c.callback.onEnterFullScreen.call(this,this.ui)}}else a.isInFullScreen=a.isInFullScreen?!1:!0;this.repositionPhoto(!0)},closeAction:function(){var a=this.vars,b=this.options;O.unbind(".iLightBox");E.off(".iLightBox");a.isInFullScreen&&z.cancelFullScreen(document.documentElement);g(".ilightbox-overlay, .ilightbox-holder, .ilightbox-thumbnails").off(".iLightBox");b.hide.effect?a.overlay.stop().fadeOut(b.hide.speed,function(){a.overlay.remove();a.BODY.removeClass("ilightbox-noscroll").off(".iLightBox")}):(a.overlay.remove(),a.BODY.removeClass("ilightbox-noscroll").off(".iLightBox"));g.each([a.toolbar,a.holder,a.nextPhoto,a.prevPhoto,a.nextButton,a.prevButton,a.loader,a.thumbnails],function(a,b){b.removeAttr("style").remove()});a.dontGenerateThumbs=a.isInFullScreen=!1;n.iLightBox=null;b.linkId&&(a.hashLock=!0,fa(),setTimeout(function(){a.hashLock=!1},55));"function"==typeof b.callback.onHide&&b.callback.onHide.call(this,this.ui)},repositionPhoto:function(){var a=this.vars,b=this.options,c=b.path.toLowerCase(),d=J(),e=d.width,f=d.height,d=a.isInFullScreen&&b.fullAlone||a.isMobile?0:"horizontal"==c?0:a.thumbnails.outerWidth(),l=a.isMobile?a.toolbar.outerHeight():a.isInFullScreen&&b.fullAlone?0:"horizontal"==c?a.thumbnails.outerHeight():0,e=a.isInFullScreen&&b.fullAlone?e:e-b.styles.pageOffsetX,f=a.isInFullScreen&&b.fullAlone?f:f-b.styles.pageOffsetY,k="horizontal"==c?parseInt(this.items[a.next]||this.items[a.prev]?2*(b.styles.nextOffsetX+b.styles.prevOffsetX):30>=e/10?30:e/10):parseInt(30>=e/10?30:e/10)+d,h="horizontal"==c?parseInt(30>=f/10?30:f/10)+l:parseInt(this.items[a.next]||this.items[a.prev]?2*(b.styles.nextOffsetX+b.styles.prevOffsetX):30>=f/10?30:f/10),d={type:"current",width:e,height:f,item:this.items[a.current],offsetW:k,offsetH:h,thumbsOffsetW:d,thumbsOffsetH:l,animate:arguments.length,holder:a.holder};this.repositionEl(d);this.items[a.next]&&(d=g.extend(d,{type:"next",item:this.items[a.next],offsetX:b.styles.nextOffsetX,offsetY:b.styles.nextOffsetY,holder:a.nextPhoto}),this.repositionEl(d));this.items[a.prev]&&(d=g.extend(d,{type:"prev",item:this.items[a.prev],offsetX:b.styles.prevOffsetX,offsetY:b.styles.prevOffsetY,holder:a.prevPhoto}),this.repositionEl(d));b="horizontal"==c?{left:parseInt(e/2-a.loader.outerWidth()/2)}:{top:parseInt(f/2-a.loader.outerHeight()/2)};a.loader.css(b)},repositionEl:function(a){var b=this.vars,c=this.options,d=c.path.toLowerCase(),e="current"==a.type?b.isInFullScreen&&c.fullAlone?a.width:a.width-a.offsetW:a.width-a.offsetW,f="current"==a.type?b.isInFullScreen&&c.fullAlone?a.height:a.height-a.offsetH:a.height-a.offsetH,l=a.item,k=a.item.options,h=a.holder,m=a.offsetX||0,p=a.offsetY||0,n=a.thumbsOffsetW,t=a.thumbsOffsetH;"current"==a.type?("number"==typeof k.width&&k.width&&(e=b.isInFullScreen&&c.fullAlone&&(-1!=c.fullStretchTypes.indexOf(l.type)||k.fullViewPort||c.fullViewPort)?e:k.width>e?e:k.width),"number"==typeof k.height&&k.height&&(f=b.isInFullScreen&&c.fullAlone&&(-1!=c.fullStretchTypes.indexOf(l.type)||k.fullViewPort||c.fullViewPort)?f:k.height>f?f:k.height)):("number"==typeof k.width&&k.width&&(e=k.width>e?e:k.width),"number"==typeof k.height&&k.height&&(f=k.height>f?f:k.height));f=parseInt(f-g(".ilightbox-inner-toolbar",h).outerHeight());b="string"==typeof k.width&&-1!=k.width.indexOf("%")?aa(parseInt(k.width.replace("%","")),a.width):h.data("naturalWidth");l="string"==typeof k.height&&-1!=k.height.indexOf("%")?aa(parseInt(k.height.replace("%","")),a.height):h.data("naturalHeight");l="string"==typeof k.width&&-1!=k.width.indexOf("%")||"string"==typeof k.height&&-1!=k.height.indexOf("%")?{width:b,height:l}:this.getNewDimenstions(e,f,b,l);e=g.extend({},l,{});"prev"==a.type||"next"==a.type?(b=parseInt(l.width*("next"==a.type?c.styles.nextScale:c.styles.prevScale)),l=parseInt(l.height*("next"==a.type?c.styles.nextScale:c.styles.prevScale))):(b=l.width,l=l.height);f=parseInt((F(h,"padding-left")+F(h,"padding-right")+F(h,"border-left-width")+F(h,"border-right-width"))/2);k=parseInt((F(h,"padding-top")+F(h,"padding-bottom")+F(h,"border-top-width")+F(h,"border-bottom-width")+g(".ilightbox-inner-toolbar",h).outerHeight())/2);switch(a.type){case"current":var r=parseInt(a.height/2-l/2-k-t/2),s=parseInt(a.width/2-b/2-f-n/2);break;case"next":r="horizontal"==d?parseInt(a.height/2-p-l/2-k-t/2):parseInt(a.height-m-k-t/2);s="horizontal"==d?parseInt(a.width-m-f-n/2):parseInt(a.width/2-b/2-f-p-n/2);break;case"prev":r="horizontal"==d?parseInt(a.height/2-p-l/2-k-t/2):parseInt(m-k-l-t/2),s="horizontal"==d?parseInt(m-f-b-n/2):parseInt(a.width/2-p-b/2-f-n/2)}h.data("offset",{top:r,left:s,newDims:e,diff:{W:f,H:k},thumbsOffset:{W:n,H:t},object:a});0<a.animate&&c.effects.reposition?(h.css(C,H).stop().animate({top:r,left:s},c.effects.repositionSpeed,"easeOutCirc",function(){h.css(C,"")}),g("div.ilightbox-container",h).stop().animate({width:b,height:l},c.effects.repositionSpeed,"easeOutCirc"),g("div.ilightbox-inner-toolbar",h).stop().animate({width:b},c.effects.repositionSpeed,"easeOutCirc",function(){g(this).css("overflow","visible")})):(h.css({top:r,left:s}),g("div.ilightbox-container",h).css({width:b,height:l}),g("div.ilightbox-inner-toolbar",h).css({width:b}))},resume:function(a){var b=this,c=b.vars,d=b.options;!d.slideshow.pauseTime||d.controls.slideshow&&1>=c.total||a<c.isPaused||(c.isPaused=0,c.cycleID&&(c.cycleID=clearTimeout(c.cycleID)),c.cycleID=setTimeout(function(){c.current==c.total-1?b.goTo(0):b.moveTo("next")},d.slideshow.pauseTime))},pause:function(a){var b=this.vars;a<b.isPaused||(b.isPaused=a||100,b.cycleID&&(b.cycleID=clearTimeout(b.cycleID)))},resetCycle:function(){var a=this.vars;this.options.controls.slideshow&&a.cycleID&&!a.isPaused&&this.resume()},getNewDimenstions:function(a,b,c,d,e){factor=a?b?Y(a/c,b/d):a/c:b/d;e||(factor>this.options.maxScale?factor=this.options.maxScale:factor<this.options.minScale&&(factor=this.options.minScale));a=this.options.keepAspectRatio?X(c*factor):a;b=this.options.keepAspectRatio?X(d*factor):b;return{width:a,height:b,ratio:factor}},setOption:function(a){this.options=g.extend(!0,this.options,a||{});this.refresh()},availPlugins:function(){var a=document.createElement("video");this.plugins={flash:0<=parseInt(Q.getVersion("Shockwave"))||0<=parseInt(Q.getVersion("Flash"))?!0:!1,quicktime:0<=parseInt(Q.getVersion("QuickTime"))?!0:!1,html5H264:!(!a.canPlayType||!a.canPlayType("video/mp4").replace(/no/,"")),html5WebM:!(!a.canPlayType||!a.canPlayType("video/webm").replace(/no/,"")),html5Vorbis:!(!a.canPlayType||!a.canPlayType("video/ogg").replace(/no/,"")),html5QuickTime:!(!a.canPlayType||!a.canPlayType("video/quicktime").replace(/no/,""))}},addContent:function(a,b){var c;switch(b.type){case"video":var d=!1,e=b.videoType,f=b.options.html5video;("video/mp4"==e||"mp4"==b.ext||"m4v"==b.ext||f.h264)&&this.plugins.html5H264?(b.ext="mp4",b.URL=f.h264||b.URL):f.webm&&this.plugins.html5WebM?(b.ext="webm",b.URL=f.webm||b.URL):f.ogg&&this.plugins.html5Vorbis&&(b.ext="ogv",b.URL=f.ogg||b.URL);!this.plugins.html5H264||"video/mp4"!=e&&"mp4"!=b.ext&&"m4v"!=b.ext?!this.plugins.html5WebM||"video/webm"!=e&&"webm"!=b.ext?!this.plugins.html5Vorbis||"video/ogg"!=e&&"ogv"!=b.ext?!this.plugins.html5QuickTime||"video/quicktime"!=e&&"mov"!=b.ext&&"qt"!=b.ext||(d=!0,e="video/quicktime"):(d=!0,e="video/ogg"):(d=!0,e="video/webm"):(d=!0,e="video/mp4");d?c=g("<video />",{width:"100%",height:"100%",preload:f.preload,autoplay:f.autoplay,poster:f.poster,controls:f.controls}).append(g("<source />",{src:b.URL,type:e})):this.plugins.quicktime?(c=g("<object />",{type:"video/quicktime",pluginspage:"https://web.archive.org/web/20181120064814/http://www.apple.com/quicktime/download"}).attr({data:b.URL,width:"100%",height:"100%"}).append(g("<param />",{name:"src",value:b.URL})).append(g("<param />",{name:"autoplay",value:"false"})).append(g("<param />",{name:"loop",value:"false"})).append(g("<param />",{name:"scale",value:"tofit"})),D.msie&&(c=ja(b.URL,"100%","100%","","SCALE","tofit","AUTOPLAY","false","LOOP","false"))):c=g("<span />",{"class":"ilightbox-alert",html:this.options.errors.missingPlugin.replace("{pluginspage}","https://web.archive.org/web/20181120064814/http://www.apple.com/quicktime/download").replace("{type}","QuickTime")});break;case"flash":if(this.plugins.flash){var l="",k=0;b.options.flashvars?g.each(b.options.flashvars,function(a,b){0!=k&&(l+="&");l+=a+"="+encodeURIComponent(b);k++}):l=null;c=g("<embed />").attr({type:"application/x-shockwave-flash",src:b.URL,width:"number"==typeof b.options.width&&b.options.width&&"1"==this.options.minScale&&"1"==this.options.maxScale?b.options.width:"100%",height:"number"==typeof b.options.height&&b.options.height&&"1"==this.options.minScale&&"1"==this.options.maxScale?b.options.height:"100%",quality:"high",bgcolor:"#000000",play:"true",loop:"true",menu:"true",wmode:"transparent",scale:"showall",allowScriptAccess:"always",allowFullScreen:"true",flashvars:l,fullscreen:"yes"})}else c=g("<span />",{"class":"ilightbox-alert",html:this.options.errors.missingPlugin.replace("{pluginspage}","https://web.archive.org/web/20181120064814/http://www.adobe.com/go/getflash").replace("{type}","Adobe Flash player")});break;case"iframe":c=g("<iframe />").attr({width:"number"==typeof b.options.width&&b.options.width&&"1"==this.options.minScale&&"1"==this.options.maxScale?b.options.width:"100%",height:"number"==typeof b.options.height&&b.options.height&&"1"==this.options.minScale&&"1"==this.options.maxScale?b.options.height:"100%",src:b.URL,frameborder:0,hspace:0,vspace:0,scrolling:A?"auto":"scroll",webkitAllowFullScreen:"",mozallowfullscreen:"",allowFullScreen:""});break;case"inline":c=g('<div class="ilightbox-wrapper"></div>').html(g(b.URL).clone(!0));break;case"html":d=b.URL,d[0].nodeName||(d=g(b.URL),d=d.selector?g("<div>"+d+"</div>"):d),c=g('<div class="ilightbox-wrapper"></div>').html(d)}g("div.ilightbox-container",a).empty().html(c);"video"===c[0].tagName.toLowerCase()&&D.webkit&&setTimeout(function(){var a=c[0].currentSrc+"?"+M(3E4*T());c[0].currentSrc=a;c[0].src=a});return c},ogpRecognition:function(a,b){var c=this,d=a.URL;c.showLoader();ga(d,function(a){c.hideLoader();if(a){var d={length:!1};d.url=a.url;if(200==a.status){a=a.results;var l=a.type,g=a.source;d.source=g.src;d.width=g.width&&parseInt(g.width)||0;d.height=g.height&&parseInt(g.height)||0;d.type=l;d.thumbnail=g.thumbnail||a.images[0];d.html5video=a.html5video||{};d.length=!0;"application/x-shockwave-flash"==g.type?d.type="flash":-1!=g.type.indexOf("video/")?d.type="video":-1!=g.type.indexOf("/html")?d.type="iframe":-1!=g.type.indexOf("image/")&&(d.type="image")}else if("undefined"!=typeof a.response)throw a.response;b.call(this,d.length?d:!1)}})},hashChangeHandler:function(a){var b=this.vars,c=this.options;a=V(a||n.location.href).hash;var d=a.split("/"),e=d[1];b.hashLock||"#"+c.linkId!=d[0]&&1<a.length||(e?(b=d[1]||0,this.items[b]?(a=g(".ilightbox-overlay"),a.length&&a.attr("linkid")==c.linkId?this.goTo(b):this.itemsObject[b].trigger(A?"itap":"click")):(a=g(".ilightbox-overlay"),a.length&&this.closeAction())):(a=g(".ilightbox-overlay"),a.length&&this.closeAction()))}};g.fn.iLightBox=function(){var a=arguments,b=g.isPlainObject(a[0])?a[0]:a[1],c=g.isArray(a[0])||"string"==typeof a[0]?a[0]:a[1];b||(b={});var b=g.extend(!0,{attr:"href",path:"vertical",skin:"dark",linkId:!1,infinite:!1,startFrom:0,randomStart:!1,keepAspectRatio:!0,maxScale:1,minScale:.2,innerToolbar:!1,smartRecognition:!1,mobileOptimizer:!0,fullAlone:!0,fullViewPort:null,fullStretchTypes:"flash, video",overlay:{blur:!0,opacity:.85},controls:{arrows:!1,slideshow:!1,toolbar:!0,fullscreen:!0,thumbnail:!0,keyboard:!0,mousewheel:!0,swipe:!0},keyboard:{left:!0,right:!0,up:!0,down:!0,esc:!0,shift_enter:!0},show:{effect:!0,speed:300,title:!0},hide:{effect:!0,speed:300},caption:{start:!0,show:"mouseenter",hide:"mouseleave"},social:{start:!0,show:"mouseenter",hide:"mouseleave",buttons:!1},styles:{pageOffsetX:0,pageOffsetY:0,nextOffsetX:45,nextOffsetY:0,nextOpacity:1,nextScale:1,prevOffsetX:45,prevOffsetY:0,prevOpacity:1,prevScale:1},thumbnails:{maxWidth:120,maxHeight:80,normalOpacity:1,activeOpacity:.6},effects:{reposition:!0,repositionSpeed:200,switchSpeed:500,loadedFadeSpeed:180,fadeSpeed:200},slideshow:{pauseTime:5E3,pauseOnHover:!1,startPaused:!0},text:{close:"Press Esc to close",enterFullscreen:"Enter Fullscreen (Shift+Enter)",exitFullscreen:"Exit Fullscreen (Shift+Enter)",slideShow:"Slideshow",next:"Next",previous:"Previous"},errors:{loadImage:"An error occurred when trying to load photo.",loadContents:"An error occurred when trying to load contents.",missingPlugin:"The content your are attempting to view requires the <a href='{pluginspage}' target='_blank'>{type} plugin</a>."},ajaxSetup:{url:"",beforeSend:function(a,b){},cache:!1,complete:function(a,b){},crossDomain:!1,error:function(a,b,c){},success:function(a,b,c){},global:!0,ifModified:!1,username:null,password:null,type:"GET"},callback:{}},b),d=g.isArray(c)||"string"==typeof c?!0:!1,c=g.isArray(c)?c:[];"string"==typeof a[0]&&(c[0]=a[0]);if(ha(g.fn.jquery,"1.8",">=")){var e=new ea(g(this),b,c,d);return{close:function(){e.closeAction()},fullscreen:function(){e.fullScreenAction()},moveNext:function(){e.moveTo("next")},movePrev:function(){e.moveTo("prev")},goTo:function(a){e.goTo(a)},refresh:function(){e.refresh()},reposition:function(){0<arguments.length?e.repositionPhoto(!0):e.repositionPhoto()},setOption:function(a){e.setOption(a)},destroy:function(){e.closeAction();e.dispatchItemsEvents()}}}throw"The jQuery version that was loaded is too old. iLightBox requires jQuery 1.8+";};g.iLightBox=function(a,b){return g.fn.iLightBox(a,b)};g.extend(g.easing,{easeInCirc:function(a,b,c,d,e){return-d*(P(1-(b/=e)*b)-1)+c},easeOutCirc:function(a,b,c,d,e){return d*P(1-(b=b/e-1)*b)+c},easeInOutCirc:function(a,b,c,d,e){return 1>(b/=e/2)?-d/2*(P(1-b*b)-1)+c:d/2*(P(1-(b-=2)*b)+1)+c}});(function(){g.each("touchstart touchmove touchend tap taphold swipe swipeleft swiperight scrollstart scrollstop".split(" "),function(a,b){g.fn[b]=function(a){return a?this.bind(b,a):this.trigger(b)};g.attrFn&&(g.attrFn[b]=!0)});g.event.special.itap={setup:function(){var a=this,b=g(this),c,d;b.bind("touchstart.iTap",function(e){c=L();b.one("touchend.iTap",function(b){d=L();b=g.event.fix(b||n.event);b.type="itap";c&&d&&c.x==d.x&&c.y==d.y&&(g.event.dispatch||g.event.handle).call(a,b);c=d=R})})},teardown:function(){g(this).unbind("touchstart.iTap")}}})();(function(){z={supportsFullScreen:!1,isFullScreen:function(){return!1},requestFullScreen:function(){},cancelFullScreen:function(){},fullScreenEventName:"",prefix:""};browserPrefixes=["webkit","moz","o","ms","khtml"];if("undefined"!=typeof document.cancelFullScreen)z.supportsFullScreen=!0;else for(var a=0,b=browserPrefixes.length;a<b;a++)if(z.prefix=browserPrefixes[a],"undefined"!=typeof document[z.prefix+"CancelFullScreen"]){z.supportsFullScreen=!0;break}z.supportsFullScreen&&(z.fullScreenEventName=z.prefix+"fullscreenchange",z.isFullScreen=function(){switch(this.prefix){case"":return document.fullScreen;case"webkit":return document.webkitIsFullScreen;default:return document[this.prefix+"FullScreen"]}},z.requestFullScreen=function(a){return""===this.prefix?a.requestFullScreen():a[this.prefix+"RequestFullScreen"]()},z.cancelFullScreen=function(a){return""===this.prefix?document.cancelFullScreen():document[this.prefix+"CancelFullScreen"]()})})();(function(){var a,b;a=navigator.userAgent;a=a.toLowerCase();b=/(chrome)[ \/]([\w.]+)/.exec(a)||/(webkit)[ \/]([\w.]+)/.exec(a)||/(opera)(?:.*version|)[ \/]([\w.]+)/.exec(a)||/(msie) ([\w.]+)/.exec(a)||0>a.indexOf("compatible")&&/(mozilla)(?:.*? rv:([\w.]+)|)/.exec(a)||[];a=b[1]||"";b=b[2]||"0";D={};a&&(D[a]=!0,D.version=b);D.chrome?D.webkit=!0:D.webkit&&(D.safari=!0)})();(function(){function a(a){for(var e=0,f=b.length;e<f;e++){var g=b[e]?b[e]+a.charAt(0).toUpperCase()+a.slice(1):a;if(c.style[g]!==R)return g}}var b=["","webkit","moz","ms","o"],c=document.createElement("div");C=a("transform")||"";H=a("perspective")?"translateZ(0) ":""})();var Q={version:"0.7.9",name:"PluginDetect",handler:function(a,b,c){return function(){a(b,c)}},openTag:"<",isDefined:function(a){return"undefined"!=typeof a},isArray:function(a){return/array/i.test(Object.prototype.toString.call(a))},isFunc:function(a){return"function"==typeof a},isString:function(a){return"string"==typeof a},isNum:function(a){return"number"==typeof a},isStrNum:function(a){return"string"==typeof a&&/\d/.test(a)},getNumRegx:/[\d][\d\.\_,-]*/,splitNumRegx:/[\.\_,-]/g,getNum:function(a,b){var c=this.isStrNum(a)?(this.isDefined(b)?new RegExp(b):this.getNumRegx).exec(a):null;return c?c[0]:null},compareNums:function(a,b,c){var d=parseInt;if(this.isStrNum(a)&&this.isStrNum(b)){if(this.isDefined(c)&&c.compareNums)return c.compareNums(a,b);a=a.split(this.splitNumRegx);b=b.split(this.splitNumRegx);for(c=0;c<Y(a.length,b.length);c++){if(d(a[c],10)>d(b[c],10))return 1;if(d(a[c],10)<d(b[c],10))return-1}}return 0},formatNum:function(a,b){var c,d;if(!this.isStrNum(a))return null;this.isNum(b)||(b=4);b--;d=a.replace(/\s/g,"").split(this.splitNumRegx).concat(["0","0","0","0"]);for(c=0;4>c;c++)if(/^(0+)(.+)$/.test(d[c])&&(d[c]=RegExp.$2),c>b||!/\d/.test(d[c]))d[c]="0";return d.slice(0,4).join(",")},$$hasMimeType:function(a){return function(b){if(!a.isIE&&b){var c,d,e=a.isArray(b)?b:a.isString(b)?[b]:[];for(d=0;d<e.length;d++)if(a.isString(e[d])&&/[^\s]/.test(e[d])&&(c=(b=navigator.mimeTypes[e[d]])?b.enabledPlugin:0)&&(c.name||c.description))return b}return null}},findNavPlugin:function(a,b,c){a=new RegExp(a,"i");b=!this.isDefined(b)||b?/\d/:0;c=c?new RegExp(c,"i"):0;var d=navigator.plugins,e,f,g;for(e=0;e<d.length;e++)if(g=d[e].description||"",f=d[e].name||"",a.test(g)&&(!b||b.test(RegExp.leftContext+RegExp.rightContext))||a.test(f)&&(!b||b.test(RegExp.leftContext+RegExp.rightContext)))if(!c||!c.test(g)&&!c.test(f))return d[e];return null},getMimeEnabledPlugin:function(a,b,c){var d;b=new RegExp(b,"i");c=c?new RegExp(c,"i"):0;var e,f,g=this.isString(a)?[a]:a;for(f=0;f<g.length;f++)if((d=this.hasMimeType(g[f]))&&(d=d.enabledPlugin)&&(e=d.description||"",a=d.name||"",b.test(e)||b.test(a))&&(!c||!c.test(e)&&!c.test(a)))return d;return 0},getPluginFileVersion:function(a,b){var c,d,e,f,g=-1;if(2<this.OS||!a||!a.version||!(c=this.getNum(a.version)))return b;if(!b)return c;c=this.formatNum(c);b=this.formatNum(b);d=b.split(this.splitNumRegx);e=c.split(this.splitNumRegx);for(f=0;f<d.length;f++)if(-1<g&&f>g&&"0"!=d[f]||e[f]!=d[f]&&(-1==g&&(g=f),"0"!=d[f]))return b;return c},AXO:n.ActiveXObject,getAXO:function(a){var b=null;try{b=new this.AXO(a)}catch(c){}return b},convertFuncs:function(a){var b,c,d=/^[\$][\$]/;for(b in a)if(d.test(b))try{c=b.slice(2),0<c.length&&!a[c]&&(a[c]=a[b](a),delete a[b])}catch(e){}},initObj:function(a,b,c){var d;if(a){if(1==a[b[0]]||c)for(d=0;d<b.length;d+=2)a[b[d]]=b[d+1];for(d in a)(c=a[d])&&1==c[b[0]]&&this.initObj(c,b)}},initScript:function(){var a=navigator,b,c=document,d=a.userAgent||"",e=a.vendor||"",f=a.platform||"",a=a.product||"";this.initObj(this,["$",this]);for(b in this.Plugins)this.Plugins[b]&&this.initObj(this.Plugins[b],["$",this,"$$",this.Plugins[b]],1);this.convertFuncs(this);this.OS=100;if(f){var g=["Win",1,"Mac",2,"Linux",3,"FreeBSD",4,"iPhone",21.1,"iPod",21.2,"iPad",21.3,"Win.*CE",22.1,"Win.*Mobile",22.2,"Pocket\\s*PC",22.3,"",100];for(b=g.length-2;0<=b;b-=2)if(g[b]&&(new RegExp(g[b],"i")).test(f)){this.OS=g[b+1];break}}this.head=c.getElementsByTagName("head")[0]||c.getElementsByTagName("body")[0]||c.body||null;this.verIE=(this.isIE=(new Function("return/*@cc_on!@*/!1"))())&&/MSIE\s*(\d+\.?\d*)/i.test(d)?parseFloat(RegExp.$1,10):null;this.docModeIE=this.verIEfull=null;if(this.isIE){b=document.createElement("div");try{b.style.behavior="url(#default#clientcaps)",this.verIEfull=b.getComponentVersion("{89820200-ECBD-11CF-8B85-00AA005B4383}","componentid").replace(/,/g,".")}catch(k){}b=parseFloat(this.verIEfull||"0",10);this.docModeIE=c.documentMode||(/back/i.test(c.compatMode||"")?5:b)||this.verIE;this.verIE=b||this.docModeIE}this.ActiveXEnabled=!1;if(this.isIE)for(c="Msxml2.XMLHTTP Msxml2.DOMDocument Microsoft.XMLDOM ShockwaveFlash.ShockwaveFlash TDCCtl.TDCCtl Shell.UIHelper Scripting.Dictionary wmplayer.ocx".split(" "),b=0;b<c.length;b++)if(this.getAXO(c[b])){this.ActiveXEnabled=!0;break}this.verGecko=(this.isGecko=/Gecko/i.test(a)&&/Gecko\s*\/\s*\d/i.test(d))?this.formatNum(/rv\s*\:\s*([\.\,\d]+)/i.test(d)?RegExp.$1:"0.9"):null;this.verChrome=(this.isChrome=/Chrome\s*\/\s*(\d[\d\.]*)/i.test(d))?this.formatNum(RegExp.$1):null;this.verSafari=(this.isSafari=(/Apple/i.test(e)||!e&&!this.isChrome)&&/Safari\s*\/\s*(\d[\d\.]*)/i.test(d))&&/Version\s*\/\s*(\d[\d\.]*)/i.test(d)?this.formatNum(RegExp.$1):null;this.verOpera=(this.isOpera=/Opera\s*[\/]?\s*(\d+\.?\d*)/i.test(d))&&(/Version\s*\/\s*(\d+\.?\d*)/i.test(d),1)?parseFloat(RegExp.$1,10):null;this.addWinEvent("load",this.handler(this.runWLfuncs,this))},init:function(a){var b,c={status:-3,plugin:0};if(!this.isString(a))return c;if(1==a.length)return this.getVersionDelimiter=a,c;a=a.toLowerCase().replace(/\s/g,"");b=this.Plugins[a];if(!b||!b.getVersion)return c;c.plugin=b;this.isDefined(b.installed)||(b.installed=null,b.version=null,b.version0=null,b.getVersionDone=null,b.pluginName=a);this.garbage=!1;if(this.isIE&&!this.ActiveXEnabled&&"java"!==a)return c.status=-2,c;c.status=1;return c},fPush:function(a,b){this.isArray(b)&&(this.isFunc(a)||this.isArray(a)&&0<a.length&&this.isFunc(a[0]))&&b.push(a)},callArray:function(a){var b;if(this.isArray(a))for(b=0;b<a.length&&null!==a[b];b++)this.call(a[b]),a[b]=null},call:function(a){var b=this.isArray(a)?a.length:-1;if(0<b&&this.isFunc(a[0]))a[0](this,1<b?a[1]:0,2<b?a[2]:0,3<b?a[3]:0);else this.isFunc(a)&&a(this)},getVersionDelimiter:",",$$getVersion:function(a){return function(b,c,d){b=a.init(b);if(0>b.status)return null;b=b.plugin;1!=b.getVersionDone&&(b.getVersion(null,c,d),null===b.getVersionDone&&(b.getVersionDone=1));a.cleanup();return c=(c=b.version||b.version0)?c.replace(a.splitNumRegx,a.getVersionDelimiter):c}},cleanup:function(){this.garbage&&this.isDefined(n.CollectGarbage)&&n.CollectGarbage()},isActiveXObject:function(a,b){var c=!1,d='<object width="1" height="1" style="display:none" '+a.getCodeBaseVersion(b)+">"+a.HTML+this.openTag+"/object>";if(!this.head)return c;this.head.insertBefore(document.createElement("object"),this.head.firstChild);this.head.firstChild.outerHTML=d;try{this.head.firstChild.classid=a.classID}catch(e){}try{this.head.firstChild.object&&(c=!0)}catch(f){}try{c&&4>this.head.firstChild.readyState&&(this.garbage=!0)}catch(g){}this.head.removeChild(this.head.firstChild);return c},codebaseSearch:function(a,b){var c=this;if(!c.ActiveXEnabled||!a)return null;a.BIfuncs&&a.BIfuncs.length&&null!==a.BIfuncs[a.BIfuncs.length-1]&&c.callArray(a.BIfuncs);var d,e=a.SEARCH;if(c.isStrNum(b)){if(e.match&&e.min&&0>=c.compareNums(b,e.min))return!0;if(e.match&&e.max&&0<=c.compareNums(b,e.max))return!1;(d=c.isActiveXObject(a,b))&&(!e.min||0<c.compareNums(b,e.min))&&(e.min=b);d||e.max&&!(0>c.compareNums(b,e.max))||(e.max=b);return d}var f=[0,0,0,0],g=[].concat(e.digits),k=e.min?1:0,h,m,n=function(b,d){var e=[].concat(f);e[b]=d;return c.isActiveXObject(a,e.join(","))};if(e.max){d=e.max.split(c.splitNumRegx);for(h=0;h<d.length;h++)d[h]=parseInt(d[h],10);d[0]<g[0]&&(g[0]=d[0])}if(e.min){m=e.min.split(c.splitNumRegx);for(h=0;h<m.length;h++)m[h]=parseInt(m[h],10);m[0]>f[0]&&(f[0]=m[0])}if(m&&d)for(h=1;h<m.length&&m[h-1]==d[h-1];h++)d[h]<g[h]&&(g[h]=d[h]),m[h]>f[h]&&(f[h]=m[h]);if(e.max)for(h=1;h<g.length;h++)if(0<d[h]&&0==g[h]&&g[h-1]<e.digits[h-1]){g[h-1]+=1;break}for(h=0;h<g.length;h++){m={};for(e=0;20>e&&!(1>g[h]-f[h]);e++){d=X((g[h]+f[h])/2);if(m["a"+d])break;m["a"+d]=1;n(h,d)?(f[h]=d,k=1):g[h]=d}g[h]=f[h];!k&&n(h,f[h])&&(k=1);if(!k)break}return k?f.join(","):null},addWinEvent:function(a,b){var c;this.isFunc(b)&&(n.addEventListener?n.addEventListener(a,b,!1):n.attachEvent?n.attachEvent("on"+a,b):(c=n["on"+a],n["on"+a]=this.winHandler(b,c)))},winHandler:function(a,b){return function(){a();"function"==typeof b&&b()}},WLfuncs0:[],WLfuncs:[],runWLfuncs:function(a){a.winLoaded=!0;a.callArray(a.WLfuncs0);a.callArray(a.WLfuncs);if(a.onDoneEmptyDiv)a.onDoneEmptyDiv()},winLoaded:!1,$$onWindowLoaded:function(a){return function(b){a.winLoaded?a.call(b):a.fPush(b,a.WLfuncs)}},div:null,divID:"plugindetect",divWidth:50,pluginSize:1,emptyDiv:function(){var a,b,c,d;if(this.div&&this.div.childNodes)for(a=this.div.childNodes.length-1;0<=a;a--){if((c=this.div.childNodes[a])&&c.childNodes)for(b=c.childNodes.length-1;0<=b;b--){d=c.childNodes[b];try{c.removeChild(d)}catch(e){}}if(c)try{this.div.removeChild(c)}catch(f){}}!this.div&&(a=document.getElementById(this.divID))&&(this.div=a);if(this.div&&this.div.parentNode){try{this.div.parentNode.removeChild(this.div)}catch(g){}this.div=null}},DONEfuncs:[],onDoneEmptyDiv:function(){var a,b;if(this.winLoaded&&(!this.WLfuncs||!this.WLfuncs.length||null===this.WLfuncs[this.WLfuncs.length-1])){for(a in this)if((b=this[a])&&b.funcs&&(3==b.OTF||b.funcs.length&&null!==b.funcs[b.funcs.length-1]))return;for(a=0;a<this.DONEfuncs.length;a++)this.callArray(this.DONEfuncs);this.emptyDiv()}},getWidth:function(a){return a&&(a=a.scrollWidth||a.offsetWidth,this.isNum(a))?a:-1},getTagStatus:function(a,b,c,d){var e=a.span,f=this.getWidth(e);c=c.span;var g=this.getWidth(c);b=b.span;var k=this.getWidth(b);if(!(e&&c&&b&&this.getDOMobj(a)))return-2;if(g<k||0>f||0>g||0>k||k<=this.pluginSize||1>this.pluginSize)return 0;if(f>=k)return-1;try{if(f==this.pluginSize&&(!this.isIE||4==this.getDOMobj(a).readyState)&&(!a.winLoaded&&this.winLoaded||a.winLoaded&&this.isNum(d)&&(this.isNum(a.count)||(a.count=d),10<=d-a.count)))return 1}catch(h){}return 0},getDOMobj:function(a,b){var c=a?a.span:0,d=c&&c.firstChild?1:0;try{d&&b&&this.div.focus()}catch(e){}return d?c.firstChild:null},setStyle:function(a,b){var c=a.style,d;if(c&&b)for(d=0;d<b.length;d+=2)try{c[b[d]]=b[d+1]}catch(e){}},insertDivInBody:function(a,b){var c=null,d=b?n.top.document:n.document,e=d.getElementsByTagName("body")[0]||d.body;if(!e)try{d.write('<div id="pd33993399">.'+this.openTag+"/div>"),c=d.getElementById("pd33993399")}catch(f){}if(e=d.getElementsByTagName("body")[0]||d.body)e.insertBefore(a,e.firstChild),c&&e.removeChild(c)},insertHTML:function(a,b,c,d,e){e=document;var f,g=e.createElement("span"),k,h="outlineStyle none borderStyle none padding 0px margin 0px visibility visible".split(" ");this.isDefined(d)||(d="");if(this.isString(a)&&/[^\s]/.test(a)){a=a.toLowerCase().replace(/\s/g,"");f=this.openTag+a+' width="'+this.pluginSize+'" height="'+this.pluginSize+'" ';f+='style="outline-style:none;border-style:none;padding:0px;margin:0px;visibility:visible;display:inline;" ';for(k=0;k<b.length;k+=2)/[^\s]/.test(b[k+1])&&(f+=b[k]+'="'+b[k+1]+'" ');f+=">";for(k=0;k<c.length;k+=2)/[^\s]/.test(c[k+1])&&(f+=this.openTag+'param name="'+c[k]+'" value="'+c[k+1]+'" />');f+=d+this.openTag+"/"+a+">"}else f=d;this.div||((b=e.getElementById(this.divID))?this.div=b:(this.div=e.createElement("div"),this.div.id=this.divID),this.setStyle(this.div,h.concat(["width",this.divWidth+"px","height",this.pluginSize+3+"px","fontSize",this.pluginSize+3+"px","lineHeight",this.pluginSize+3+"px","verticalAlign","baseline","display","block"])),b||(this.setStyle(this.div,"position absolute right 0px top 0px".split(" ")),this.insertDivInBody(this.div)));if(this.div&&this.div.parentNode){this.setStyle(g,h.concat(["fontSize",this.pluginSize+3+"px","lineHeight",this.pluginSize+3+"px","verticalAlign","baseline","display","inline"]));try{g.innerHTML=f}catch(m){}try{this.div.appendChild(g)}catch(n){}return{span:g,winLoaded:this.winLoaded,tagName:a,outerHTML:f}}return{span:null,winLoaded:this.winLoaded,tagName:"",outerHTML:f}},Plugins:{quicktime:{mimeType:["video/quicktime","application/x-quicktimeplayer","image/x-macpaint","image/x-quicktime"],progID:"QuickTimeCheckObject.QuickTimeCheck.1",progID0:"QuickTime.QuickTime",classID:"clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B",minIEver:7,HTML:'<param name="src" value="" /><param name="controller" value="false" />',getCodeBaseVersion:function(a){return'codebase="#version='+a+'"'},SEARCH:{min:0,max:0,match:0,digits:[16,128,128,0]},getVersion:function(a){var b=this.$,c=null,d=null;if(b.isIE){b.isStrNum(a)&&(a=a.split(b.splitNumRegx),3<a.length&&0<parseInt(a[3],10)&&(a[3]="9999"),a=a.join(","));if(b.isStrNum(a)&&b.verIE>=this.minIEver&&0<this.canUseIsMin()){this.installed=this.isMin(a);this.getVersionDone=0;return}this.getVersionDone=1;!c&&b.verIE>=this.minIEver&&(c=this.CDBASE2VER(b.codebaseSearch(this)));c||(d=b.getAXO(this.progID))&&d.QuickTimeVersion&&(c=d.QuickTimeVersion.toString(16),c=parseInt(c.charAt(0),16)+"."+parseInt(c.charAt(1),16)+"."+parseInt(c.charAt(2),16))}else b.hasMimeType(this.mimeType)&&(d=3!=b.OS?b.findNavPlugin("QuickTime.*Plug-?in",0):null)&&d.name&&(c=b.getNum(d.name));this.installed=c?1:d?0:-1;this.version=b.formatNum(c,3)},cdbaseUpper:["7,60,0,0","0,0,0,0"],cdbaseLower:["7,50,0,0",null],cdbase2ver:[function(a,b){var c=b.split(a.$.splitNumRegx);return[c[0],c[1].charAt(0),c[1].charAt(1),c[2]].join()},null],CDBASE2VER:function(a){var b=this.$,c,d=this.cdbaseUpper,e=this.cdbaseLower;if(a)for(a=b.formatNum(a),c=0;c<d.length;c++)if(d[c]&&0>b.compareNums(a,d[c])&&e[c]&&0<=b.compareNums(a,e[c])&&this.cdbase2ver[c])return this.cdbase2ver[c](this,a);return a},canUseIsMin:function(){var a=this.$,b,c=this.canUseIsMin,d=this.cdbaseUpper,e=this.cdbaseLower;if(!c.value)for(c.value=-1,b=0;b<d.length;b++){if(d[b]&&a.codebaseSearch(this,d[b])){c.value=1;break}if(e[b]&&a.codebaseSearch(this,e[b])){c.value=-1;break}}this.SEARCH.match=1==c.value?1:0;return c.value},isMin:function(a){return this.$.codebaseSearch(this,a)?.7:-1}},flash:{mimeType:"application/x-shockwave-flash",progID:"ShockwaveFlash.ShockwaveFlash",classID:"clsid:D27CDB6E-AE6D-11CF-96B8-444553540000",getVersion:function(){var a=function(a){return a?(a=/[\d][\d\,\.\s]*[rRdD]{0,1}[\d\,]*/.exec(a))?a[0].replace(/[rRdD\.]/g,",").replace(/\s/g,""):null:null},b=this.$,c,d=null,e=null,f=null;if(b.isIE){for(c=15;2<c;c--)if(e=b.getAXO(this.progID+"."+c)){f=c.toString();break}e||(e=b.getAXO(this.progID));if("6"==f)try{e.AllowScriptAccess="always"}catch(g){return"6,0,21,0"}try{d=a(e.GetVariable("$version"))}catch(k){}!d&&f&&(d=f)}else{if(e=b.hasMimeType(this.mimeType)){c=b.getDOMobj(b.insertHTML("object",["type",this.mimeType],[],"",this));try{d=b.getNum(c.GetVariable("$version"))}catch(h){}}d||((c=e?e.enabledPlugin:null)&&c.description&&(d=a(c.description)),d&&(d=b.getPluginFileVersion(c,d)))}this.installed=d?1:-1;this.version=b.formatNum(d);return!0}},shockwave:{mimeType:"application/x-director",progID:"SWCtl.SWCtl",classID:"clsid:166B1BCA-3F9C-11CF-8075-444553540000",getVersion:function(){var a=null,b=null,c=this.$;if(c.isIE){try{b=c.getAXO(this.progID).ShockwaveVersion("")}catch(d){}c.isString(b)&&0<b.length?a=c.getNum(b):c.getAXO(this.progID+".8")?a="8":c.getAXO(this.progID+".7")?a="7":c.getAXO(this.progID+".1")&&(a="6")}else(b=c.findNavPlugin("Shockwave\\s*for\\s*Director"))&&b.description&&c.hasMimeType(this.mimeType)&&(a=c.getNum(b.description)),a&&(a=c.getPluginFileVersion(b,a));this.installed=a?1:-1;this.version=c.formatNum(a)}},zz:0}};Q.initScript();var ka='The "%%" function requires an even number of arguments.\nArguments should be in the form "atttributeName", "attributeValue", ...',q=null;(function(){function a(a){a=a||location.href;return"#"+a.replace(/^[^#]*#?(.*)$/,"$1")}var b=document,c,d=g.event.special,e=b.documentMode,f="oniLightBoxHashChange"in n&&(void 0===e||7<e);g.fn.iLightBoxHashChange=function(a){return a?this.bind("iLightBoxHashChange",a):this.trigger("iLightBoxHashChange")};g.fn.iLightBoxHashChange.delay=50;d.iLightBoxHashChange=g.extend(d.iLightBoxHashChange,{setup:function(){if(f)return!1;g(c.start)},teardown:function(){if(f)return!1;g(c.stop)}});c=function(){function c(){var b=a(),d=t(m);b!==m?(q(m=b,d),g(n).trigger("iLightBoxHashChange")):d!==m&&(location.href=location.href.replace(/#.*/,"")+d);e=setTimeout(c,g.fn.iLightBoxHashChange.delay)}var d={},e,m=a(),p=function(a){return a},q=p,t=p;d.start=function(){e||c()};d.stop=function(){e&&clearTimeout(e);e=void 0};D.msie&&!f&&function(){var e,f;d.start=function(){e||(f=(f=g.fn.iLightBoxHashChange.src)&&f+a(),e=g('<iframe tabindex="-1" title="empty"/>').hide().one("load",function(){f||q(a());c()}).attr("src",f||"javascript:0").insertAfter("body")[0].contentWindow,b.onpropertychange=function(){try{"title"===event.propertyName&&(e.document.title=b.title)}catch(a){}})};d.stop=p;t=function(){return a(e.location.href)};q=function(a,c){var d=e.document,f=g.fn.iLightBoxHashChange.domain;a!==c&&(d.title=b.title,d.open(),f&&d.write('<script>document.domain="'+f+'"\x3c/script>'),d.close(),e.location.hash=a)}}();return d}()})();Array.prototype.filter||(Array.prototype.filter=function(a,b){if(null==this)throw new TypeError;var c=Object(this),d=c.length>>>0;if("function"!=typeof a)throw new TypeError;for(var e=[],f=0;f<d;f++)if(f in c){var g=c[f];a.call(b,g,f,c)&&e.push(g)}return e});Array.prototype.indexOf||(Array.prototype.indexOf=function(a,b){var c;if(null==this)throw new TypeError('"this" is null or not defined');var d=Object(this),e=d.length>>>0;if(0===e)return-1;c=+b||0;Infinity===I(c)&&(c=0);if(c>=e)return-1;for(c=ba(0<=c?c:e-I(c),0);c<e;){if(c in d&&d[c]===a)return c;c++}return-1});Array.prototype.lastIndexOf||(Array.prototype.lastIndexOf=function(a){if(null==this)throw new TypeError;var b=Object(this),c=b.length>>>0;if(0===c)return-1;var d=c;1<arguments.length&&(d=Number(arguments[1]),d!=d?d=0:0!=d&&d!=1/0&&d!=-(1/0)&&(d=(0<d||-1)*M(I(d))));for(c=0<=d?Y(d,c-1):c-I(d);0<=c;c--)if(c in b&&b[c]===a)return c;return-1})})(jQuery,this);
(function(e){function r(t){var n=t||window.event,r=[].slice.call(arguments,1),i=0,s=true,o=0,u=0;t=e.event.fix(n);t.type="mousewheel";if(n.wheelDelta){i=n.wheelDelta/120}if(n.detail){i=-n.detail/3}u=i;if(n.axis!==undefined&&n.axis===n.HORIZONTAL_AXIS){u=0;o=-1*i}if(n.wheelDeltaY!==undefined){u=n.wheelDeltaY/120}if(n.wheelDeltaX!==undefined){o=-1*n.wheelDeltaX/120}r.unshift(t,i,o,u);return(e.event.dispatch||e.event.handle).apply(this,r)}var t=["DOMMouseScroll","mousewheel"];if(e.event.fixHooks){for(var n=t.length;n;){e.event.fixHooks[t[--n]]=e.event.mouseHooks}}e.event.special.mousewheel={setup:function(){if(this.addEventListener){for(var e=t.length;e;){this.addEventListener(t[--e],r,false)}}else{this.onmousewheel=r}},teardown:function(){if(this.removeEventListener){for(var e=t.length;e;){this.removeEventListener(t[--e],r,false)}}else{this.onmousewheel=null}}};e.fn.extend({mousewheel:function(e){return e?this.bind("mousewheel",e):this.trigger("mousewheel")},unmousewheel:function(e){return this.unbind("mousewheel",e)}})})(jQuery);
(function(e,t,n){var r=0,i,s=function(e){if(i){t.requestAnimationFrame(s,e);jQuery.fx.tick()}},o=["ms","moz","webkit","o"];for(var u=0,a=o.length;u<a&&!t.requestAnimationFrame;++u){t.requestAnimationFrame=t[o[u]+"RequestAnimationFrame"];t.cancelAnimationFrame=t[o[u]+"CancelAnimationFrame"]||t[o[u]+"CancelRequestAnimationFrame"]}if(!t.requestAnimationFrame)t.requestAnimationFrame=function(e,n){var i=(new Date).getTime(),s=i-r,o=Math.max(0,16-s);var u=t.setTimeout(function(){e(i+o)},o);r=i+o;return u};if(!t.cancelAnimationFrame){t.cancelAnimationFrame=function(e){clearTimeout(e)}}jQuery.fx.timer=function(e){if(e()&&jQuery.timers.push(e)&&!i){i=true;s(e.elem)}};jQuery.fx.stop=function(){i=false}})(jQuery,this)

}
/*
     FILE ARCHIVED ON 06:48:14 Nov 20, 2018 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:01:17 Jan 28, 2021.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  RedisCDXSource: 3.896
  PetaboxLoader3.resolve: 217.892 (4)
  esindex: 0.016
  PetaboxLoader3.datanode: 2004.306 (5)
  CDXLines.iter: 15.873 (3)
  LoadShardBlock: 1983.713 (3)
  captures_list: 2007.412
  exclusion.robots: 0.245
  exclusion.robots.policy: 0.233
  load_resource: 304.617 (2)
*/