var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

var tie = {"mobile_menu_active": "true", "mobile_menu_top": "", "lightbox_all": "true", "lightbox_gallery": "true", "woocommerce_lightbox": "", "lightbox_skin": null, "lightbox_thumb": "vertical", "lightbox_arrows": "", "sticky_sidebar": "", "is_singular": "1", "SmothScroll": "true", "reading_indicator": "true", "lang_no_results": "No Results", "lang_results_found": "Results Found"};

function getFormattedDate(today)
{
    var week = new Array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
    var day = week[today.getDay()];
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();
    var hour = today.getHours();
    var minu = today.getMinutes();

    if (dd < 10) {
        dd = '0' + dd
    }
    if (mm < 10) {
        mm = '0' + mm
    }
    if (minu < 10) {
        minu = '0' + minu
    }

    return day + ' - ' + dd + '/' + mm + '/' + yyyy + ' ' + hour + ':' + minu;
}
var str = new Date();
document.getElementsByClassName("today-date")[0].innerHTML = getFormattedDate(str);
jQuery(document).ready(function () {
    jQuery('#flexslider').flexslider({
        animation: "fade", slideshowSpeed: 7000,
        animationSpeed: 600,
        randomize: false,
        pauseOnHover: true,
        prevText: "",
        nextText: "",
        after: function (slider) {
            jQuery('#flexslider .slider-caption').animate({bottom: 12, }, 400)
        },
        before: function (slider) {
            jQuery('#flexslider .slider-caption').animate({bottom: -105, }, 400)
        },
        start: function (slider) {
            var slide_control_width = 100 / 5;
            jQuery('#flexslider .flex-control-nav li').css('width', slide_control_width + '%');
            jQuery('#flexslider .slider-caption').animate({bottom: 12, }, 400)
        }
    });
});
 $(document).ready(function(){
      var arr = (location.host + location.pathname).split('/'); 
       setMenuActive(arr[1]);
 });
 $(document).ready(function(){
     $(".back").click(function(){
        window.history.back();     
     });
 });

}
/*
     FILE ARCHIVED ON 23:43:36 Nov 21, 2018 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:01:17 Jan 28, 2021.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  RedisCDXSource: 0.959
  PetaboxLoader3.resolve: 69.201 (2)
  esindex: 0.016
  PetaboxLoader3.datanode: 743.213 (5)
  CDXLines.iter: 17.772 (3)
  LoadShardBlock: 694.834 (3)
  captures_list: 718.379
  exclusion.robots: 0.368
  exclusion.robots.policy: 0.351
  load_resource: 172.179 (2)
*/