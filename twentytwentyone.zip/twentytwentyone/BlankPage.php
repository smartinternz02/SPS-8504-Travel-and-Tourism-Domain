<?php /* Template Name: PageWithoutSidebar */ ?>
<!DOCTYPE html>
<html class=" js no-touch csstransforms csstransforms3d csstransitions svg js no-touch csstransforms csstransforms3d csstransitions svg" lang="en-US"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/banner-styles.css">
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/iconochive.css">
<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/font-awesome_002.css">
<!-- End Wayback Rewrite JS Include -->

        <meta charset="UTF-8">
        <title>GP Sakoli</title>
        <link rel="stylesheet" id="tie-style-css" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/style-theme.css" type="text/css" media="all">
        <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/style.css">
        <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/font-awesome.css">
        <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/bootstrap.css">
        <!--<link rel="stylesheet" href="http://gpsakoli.ac.in/assets/style.css">-->
       
        <link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/ticker-style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style id="fit-vids-style">.fluid-width-video-wrapper{width:100%;position:relative;padding:0;}.fluid-width-video-wrapper iframe,.fluid-width-video-wrapper object,.fluid-width-video-wrapper embed {position:absolute;top:0;left:0;width:100%;height:100%;}</style></head>
    <body><!-- BEGIN WAYBACK TOOLBAR INSERT -->
	<?php echo get_stylesheet_directory_uri();?>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/timestamp.js" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/graph-calc.js" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/auto-complete.js" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/toolbar.js" charset="utf-8"></script>

        <div class="wrapper-outer">
            <div class="background-cover"></div>
            <aside id="slide-out">
                <div class="search-mobile">
                    <form method="get" id="searchform-mobile" action="">
                        <button class="search-button" type="submit" value="Search"><i class="fa fa-search"></i></button>	
                        <input type="text" id="s-mobile" name="s" title="Search" value="Search" onfocus="if (this.value == 'Search') {
                                    this.value = '';
                                }" onblur="if (this.value == '') {
                                            this.value = 'Search';
                                        }">
                    </form>
                </div><!-- .search-mobile /-->

                <div class="social-icons">
                   
                </div>
                <div id="mobile-menu"><div class="main-menu">
                                    <ul id="menu-home1" class="menu">
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom home current-menu-parent"><a href="http://gpsakoli.ac.in/"><i class="fa fa-home"></i>Home</a></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor menu-item-has-children menu-item-1 mega-menu mega-recent-featured"><a href="#"><i class="fa fa-info"></i>About Us</a>
                                            <div class="mega-menu-block menu-sub-content ">

                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent"><a href="http://gpsakoli.ac.in/welcome/about">About Institute</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent "><a href="http://gpsakoli.ac.in/welcome/about">About City</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent"><a href="http://gpsakoli.ac.in/welcome/vision">Vision</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent menu-item-11572"><a href="http://gpsakoli.ac.in/welcome/vision">Mission</a></li>
                                                     <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent "><a href="http://gpsakoli.ac.in/welcome/vision">Principal Desk</a></li>
                                                </ul>

                                                <!-- .mega-menu-content --> 
                                            </div><!-- .mega-menu-block --> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i>
                                        </li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-2 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-paper-plane"></i>Departments</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/civil">Civil </a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/mechanical">Mechanical </a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/etx">Electronics &amp; Tele. Comm.</a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/computer">Computer Technology</a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/electrical">Electrical</a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/science">Science &amp; Humanities</a>
                                                         
                                                    </li>
                                                     <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/workshop">Workshop</a></li>
                                                     <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/mechanics">Applied Mechanics</a></li>
                                                    
                                                </ul>

                                            </div><!-- .mega-menu-block --> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-3 mega-menu mega-recent-featured "><a href="http://gpsakoli.ac.in/welcome/comingsoon"><i class="fa fa-university"></i>Administration</a>
                                            <div class="mega-menu-block menu-sub-content">

                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category "><a href="#">Office</a></li>
                                                    
                                                </ul>

                                            </div><!-- .mega-menu-block --> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Facilities</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/library">Library</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Gymkhana</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/hostel">Hostel</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/cooperativestore">Student Co-operative Store</a></li>
                                                </ul>
                                            </div> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Student Section</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">E Magazine</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Blogs</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Academic Calender</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Notices</a></li>
                                                </ul>
                                            </div> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://gpsakoli.ac.in/welcome/rti"><i class="fa fa-home"></i>RTI</a>
                                            
                                        
                                        </li><li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://gpsakoli.ac.in/welcome/training"><i class="fa fa-home"></i>Training &amp; Placement</a>
                                        
                                        </li><li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://gpsakoli.ac.in/welcome/contact"><i class="fa fa-users"></i>Contact Us</a></li>
                                         <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Extenal Links</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://http//msbte.com/msbte">MSBTE</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://http//www.aicte-india.org/">AICTE</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://www.dtemaharashtra.gov.in/">DTE</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="https://www.maharashtra.gov.in/">Maha Govt</a></li>
                                                </ul>
                                            </div> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                    </ul></div>									 									<div class="main-menu">
                                    <ul id="menu-home1" class="menu">
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom home current-menu-parent"><a href="http://gpsakoli.ac.in/welcome"><i class="fa fa-home"></i>Home</a></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor menu-item-has-children menu-item-1 mega-menu mega-recent-featured"><a href="#"><i class="fa fa-info"></i>About Us</a>
                                            <div class="mega-menu-block menu-sub-content ">

                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent"><a href="http://gpsakoli.ac.in/welcome/about">About Institute</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent "><a href="http://gpsakoli.ac.in/welcome/about">About City</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent"><a href="http://gpsakoli.ac.in/welcome/vision">Vision</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent menu-item-11572"><a href="http://gpsakoli.ac.in/welcome/vision">Mission</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent "><a href="http://gpsakoli.ac.in/welcome/vision">Principal Desk</a></li>
													<li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent "><a href="http://gpsakoli.ac.in/welcome/gallery">Gallery</a></li>
                                                </ul>

                                                <!-- .mega-menu-content --> 
                                            </div><!-- .mega-menu-block --> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-2 mega-menu mega-recent-featured "><a href="#">Departments</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/civil">Civil </a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/mechanical">Mechanical </a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/etx">Electronics &amp; Tele. Comm.</a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/computer">Computer Technology</a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/electrical">Electrical</a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/science">Science &amp; Humanities</a>
                                                         
                                                    </li>
                                                     <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/workshop">Workshop</a></li>
                                                     <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/mechanics">Applied Mechanics</a></li>
                                                    
                                                </ul>

                                            </div><!-- .mega-menu-block --> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-3 mega-menu mega-recent-featured "><a href="http://gpsakoli.ac.in/welcome/comingsoon"><i class="fa fa-university"></i>Administration</a>
                                            <div class="mega-menu-block menu-sub-content" style="left: -50px; width: 240px;">

                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category "><a href="#">Office</a></li>
                                                    
                                                </ul>

                                            </div><!-- .mega-menu-block --> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Campus Life</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/students">Students Representative </a></li>
						    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/library">Library</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/gymkhana">Gymkhana</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/hostel">Hostel</a></li>
						   <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/sports">Sports</a></li>
						    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/signature">Signature Events</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/cooperativestore">Student Co-operative Store</a></li>
                                                </ul>
                                            </div> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Student Section</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">E Magazine</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Blogs</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Academic Calender</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Notices</a></li>
                                                </ul>
                                            </div> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>RTI</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/rti">RTI</a></li>
                               
                                              
                                                </ul>
                                            </div> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
										
                                  <!--       <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://gpsakoli.ac.in/welcome/rti"><i class="fa fa-home"></i>RTI</a> -->
                                            
                                        
                               <!--         </li><li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://gpsakoli.ac.in/welcome/training"><i class="fa fa-home"></i>Training &amp; Placement</a>  -->
										<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Training &amp; Placementa</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/training">Training &amp; Placement</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/campusinfo">Our Recruiter</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/studentplace">Placement Record</a></li>
                                              
                                                </ul>
                                            </div> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
										
										<li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://gpsakoli.ac.in/welcome/contact"><i class="fa fa-users"></i>Contact Us</a></li>
                                         <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Extenal Links</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://http//msbte.com/msbte">MSBTE</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://www.aicte-india.org/">AICTE</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://www.dtemaharashtra.gov.in/">DTE</a></li>
                                                     <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/notes">Press notes</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="https://www.maharashtra.gov.in/">Maha Govt</a></li>
                                                       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/Sword">Student Word</a></li>
                                                </ul>
                                            </div> 
                                        <i class="mobile-arrows fa fa-chevron-down"></i></li>
                                    </ul></div></div>            
            </aside><!-- #slide-out /-->
            <div id="wrapper" class="boxed-all">
                <div class="inner-wrapper">

                    <header id="theme-header" class="theme-header">
                        <div id="top-nav" class="top-nav">
                            <div class="container">

                                <span class="today-date">Thursday - 28/01/2021 22:38</span>					

                                <div class="search-block">
                                    <form method="get" id="searchform-header" action="">
                                        <button class="search-button" type="submit" value="Search"><i class="fa fa-search"></i></button>	
                                        <input class="search-live" type="text" id="s-header" name="s" title="Search" value="Search" onfocus="if (this.value == 'Search') {
                                                    this.value = '';
                                                }" onblur="if (this.value == '') {
                                                            this.value = 'Search';
                                                        }">
                                    </form>
                                </div><!-- .search-block /-->
                                 <span class="today-date"></span>
                                <div class="social-icons">
                                    <a class="ttip-none" title="Facebook" href="https://www.facebook.com/Government-PolytechnicSakoli-2301164576596169/" target="_blank"><i class="fa fa-facebook" style="color:blue"></i></a>
                                </div>
								
								<div class="social-icons">
                                    <a class="ttip-none" title="instagram" href="https://www.instagram.com/gpsakoli/" target="_blank"><i class="fa fa-instagram" style="color:#FF0040"></i></a>
                                </div>
								
								<div class="social-icons">
                                    <a class="ttip-none" title="twitter" href="https://www.twitter.com/gpsakoli/" target="_blank"><i class="fa fa-twitter" style="color:#0101DF"></i></a>
                                </div>
								
								<div class="social-icons">
                                    <a class="ttip-none" title="Youth4work" href="https://www.university.youth4work.com/gp_government-polytechnic-sakoli/" target="_blank"><i class="fa fa-umbrella" style="color:blue"></i></a>
                                </div>
								
								<div class="social-icons">
                                    <a class="ttip-none" title="youtube" href="https://www.youtube.com/results?search_query=gp+sakoli/" target="_blank"><i class="fa fa-youtube" style="color:red"></i></a>
                                </div>



                            </div><!-- .container /-->
                        </div><!-- .top-menu /-->

                        <div class="header-content text-center">

                            <a id="slide-out-open" class="slide-out-open" href="#"><span></span></a>

                            <div class="logo">
                                <a title="" href="http://gpsakoli.ac.in/welcome">
                                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/site-logo.png">
                                    </a>
                                <br> <a title="" href="http://gpsakoli.ac.in/welcome"><strong class="site-name">Government Polytechnic Sakoli</strong></a>
                            </div>
                            <!--                            <ul class="place-image">
                                                            <li><img src="img/doha.png" alt="Doha"/></li>
                                                            <li><img src="img/qat.png" alt="Qatar"/></li>
                                                            <li><img src="img/hyd.png" alt="Hydrabad"/></li>
                                                        </ul>-->
                                
                            
                            <div class="clear"></div>

                        </div>	

<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/font-awesome_002.css">

                        <nav id="main-nav" class="fixed-enabled fixed-nav-appear" style="border-bottom: 5px solid #2ecc71">
                            <div class="container">
								<!--<style>
								ul:hover li{
									transform:scale(1.5);
									opacity:.2;
									filter:blur(5px);
									
								}
								ul li:hover{
									transform:scale(2);
									opacity:1;
									filter:blur(0);
									
								}
							
								
								</style>
-->
                                <div class="main-menu">
                                    <ul id="menu-home1" class="menu">
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom home current-menu-parent"><a href="http://gpsakoli.ac.in/welcome"><i class="fa fa-home"></i>Home</a></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor menu-item-has-children menu-item-1 mega-menu mega-recent-featured"><a href="#"><i class="fa fa-info"></i>About Us</a>
                                            <div class="mega-menu-block menu-sub-content ">

                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent"><a href="http://gpsakoli.ac.in/welcome/about">About Institute</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent "><a href="http://gpsakoli.ac.in/welcome/about">About City</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent"><a href="http://gpsakoli.ac.in/welcome/vision">Vision</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent menu-item-11572"><a href="http://gpsakoli.ac.in/welcome/vision">Mission</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent "><a href="http://gpsakoli.ac.in/welcome/vision">Principal Desk</a></li>
													<li class="menu-item menu-item-type-taxonomy menu-item-object-category current-post-ancestor current-menu-parent current-post-parent "><a href="http://gpsakoli.ac.in/welcome/gallery">Gallery</a></li>
                                                </ul>

                                                <div class="mega-menu-content">
                                                </div><!-- .mega-menu-content --> 
                                            </div><!-- .mega-menu-block --> 
                                        </li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-2 mega-menu mega-recent-featured "><a href="#">Departments</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/civil">Civil </a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/mechanical">Mechanical </a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/etx">Electronics &amp; Tele. Comm.</a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/computer">Computer Technology</a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/electrical">Electrical</a>
                                                         
                                                    </li>
                                                    <li class="menu-item menu-item-type-custom"><a href="http://gpsakoli.ac.in/welcome/science">Science &amp; Humanities</a>
                                                         
                                                    </li>
                                                     <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/workshop">Workshop</a></li>
                                                     <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/mechanics">Applied Mechanics</a></li>
                                                    
                                                </ul>

                                            </div><!-- .mega-menu-block --> 
                                        </li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-3 mega-menu mega-recent-featured "><a href="http://gpsakoli.ac.in/welcome/comingsoon"><i class="fa fa-university"></i>Administration</a>
                                            <div class="mega-menu-block menu-sub-content" style="left: -50px; width: 240px;">

                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category "><a href="#">Office</a></li>
                                                    
                                                </ul>

                                            </div><!-- .mega-menu-block --> 
                                        </li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Campus Life</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/students">Students Representative </a></li>
						    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/library">Library</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/gymkhana">Gymkhana</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/hostel">Hostel</a></li>
						   <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/sports">Sports</a></li>
						    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/signature">Signature Events</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/cooperativestore">Student Co-operative Store</a></li>
                                                </ul>
                                            </div> 
                                        </li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Student Section</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">E Magazine</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Blogs</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Academic Calender</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/comingsoon">Notices</a></li>
                                                </ul>
                                            </div> 
                                        </li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>RTI</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/rti">RTI</a></li>
                               
                                              
                                                </ul>
                                            </div> 
                                        </li>
										
                                  <!--       <li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://gpsakoli.ac.in/welcome/rti"><i class="fa fa-home"></i>RTI</a> -->
                                            
                                        
                               <!--         </li><li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://gpsakoli.ac.in/welcome/training"><i class="fa fa-home"></i>Training &amp; Placement</a>  -->
										<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Training &amp; Placementa</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/training">Training &amp; Placement</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/campusinfo">Our Recruiter</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/studentplace">Placement Record</a></li>
                                              
                                                </ul>
                                            </div> 
                                        </li>
										
										<li class="menu-item menu-item-type-custom menu-item-object-custom"><a href="http://gpsakoli.ac.in/welcome/contact"><i class="fa fa-users"></i>Contact Us</a></li>
                                         <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4 mega-menu mega-recent-featured "><a href="#"><i class="fa fa-play"></i>Extenal Links</a>
                                            <div class="mega-menu-block menu-sub-content">
                                                <ul class="mega-recent-featured-list sub-list">
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://http//msbte.com/msbte">MSBTE</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://www.aicte-india.org/">AICTE</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://www.dtemaharashtra.gov.in/">DTE</a></li>
                                                     <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/notes">Press notes</a></li>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="https://www.maharashtra.gov.in/">Maha Govt</a></li>
                                                       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="http://gpsakoli.ac.in/welcome/Sword">Student Word</a></li>
                                                </ul>
                                            </div> 
                                        </li>
                                    </ul></div>					
                            </div>
                        </nav><!-- .main-nav /-->

                    </header><!-- #header /-->
                    <div class="clear"></div>
			<!--		<marquee behavior="alternate"><a style="font-family:Times New Roman" href="http://gpsakoli.ac.in/assets/files/TTRD2020.pdf" target="_blank">WELCOME TO GOVERNMENT POLYTECHNIC COLLEGE SAKOLI</a></marquee> -->
                    <div id="main-content" class="container">

                                          
<style id="css-ddslick" type="text/css">.dd-select{ border-radius:2px; border:solid 1px #ccc; position:relative; cursor:pointer;}.dd-desc { color:#aaa; display:block; overflow: hidden; font-weight:normal; line-height: 1.4em; }.dd-selected{ overflow:hidden; display:block; padding:10px; font-weight:bold;}.dd-pointer{ width:0; height:0; position:absolute; right:10px; top:50%; margin-top:-3px;}.dd-pointer-down{ border:solid 5px transparent; border-top:solid 5px #000; }.dd-pointer-up{border:solid 5px transparent !important; border-bottom:solid 5px #000 !important; margin-top:-8px;}.dd-options{ border:solid 1px #ccc; border-top:none; list-style:none; box-shadow:0px 1px 5px #ddd; display:none; position:absolute; z-index:2000; margin:0; padding:0;background:#fff; overflow:auto;}.dd-option{ padding:10px; display:block; border-bottom:solid 1px #ddd; overflow:hidden; text-decoration:none; color:#333; cursor:pointer;-webkit-transition: all 0.25s ease-in-out; -moz-transition: all 0.25s ease-in-out;-o-transition: all 0.25s ease-in-out;-ms-transition: all 0.25s ease-in-out; }.dd-options > li:last-child > .dd-option{ border-bottom:none;}.dd-option:hover{ background:#f3f3f3; color:#000;}.dd-selected-description-truncated { text-overflow: ellipsis; white-space:nowrap; }.dd-option-selected { background:#f6f6f6; }.dd-option-image, .dd-selected-image { vertical-align:middle; float:left; margin-right:5px; max-width:64px;}.dd-image-right { float:right; margin-right:15px; margin-left:5px;}.dd-container{ position:relative;}​ .dd-selected-text { font-weight:bold}​</style>

<div class="content">

<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/font-awesome_002.css">

    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
			<li data-target="#myCarousel" data-slide-to="4"></li>
			<li data-target="#myCarousel" data-slide-to="5"></li>
			<li data-target="#myCarousel" data-slide-to="6"></li>
			<li data-target="#myCarousel" data-slide-to="7"></li>
			<li data-target="#myCarousel" data-slide-to="8"></li>
			<li data-target="#myCarousel" data-slide-to="9"></li>
			<li data-target="#myCarousel" data-slide-to="10"></li>
			<li data-target="#myCarousel" data-slide-to="11"></li>
			<li data-target="#myCarousel" data-slide-to="12"></li>
			<li data-target="#myCarousel" data-slide-to="13"></li>
			<li data-target="#myCarousel" data-slide-to="14"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/tree_plant_5_6_20.jpg" alt="Chania">
                <div class="carousel-caption">Tree Plantation Program on 5th June 2020 in the Campus
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/online_fdp.jpg" alt="Chania">
                <div class="carousel-caption">Online FDP on "Overview of NBA Norms and its Preparation for Accreditation" 
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/NDF_donation.jpg" alt="Chania">
                <div class="carousel-caption">Bhandara collector Received Rs. 51,000/- as Donation for National Defence Fund
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/donate_covid.jpg" alt="Chania">
                <div class="carousel-caption">Donation to COVID-19 Warriors
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/sankalp.jpg" alt="Chania">
                <div class="carousel-caption" style="color:black;">Sankalp
 Diwas Organised to take pledge of making institute upto a level to 
recognise it as "National Tribal Polytechnic of India"   
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/blood_donation.jpg" alt="Chania">
                <div class="carousel-caption"><b>Blood Donation Camp</b>
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/pathari.jpg" alt="Chania">
                <div class="carousel-caption"><b>Program Organised at Pathari Village Under Unnat Bharat Abhiyan 2020</b>
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/quiz.jpg" alt="Chania">
                <div class="carousel-caption">State Level Quiz Competition Organised By Electronics and Telecommunication Department 
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/alumni2020.jpg" alt="Chania">
                <div class="carousel-caption">Alumni Meet 2020
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/HM2020.jpg" alt="Chania">
                <div class="carousel-caption">Head Masters Meet 2020
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/tarendra_lakhankar.jpg" alt="Chania">
                <div class="carousel-caption">Expert lecture By Tarendra Lakhankar, Project Scientist at NOAA-CESSRST,The City College of New York
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/n1.jpg" alt="Chania">
                <div class="carousel-caption" style="color:black;">National Conference on "Technology for Tribal and Rural Development"-TTRD-2020
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/swachatta.jpg" alt="Chania">
                <div class="carousel-caption">"Swachatta hi Seva" Campaign
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/Workshop_Emp_Entra.jpg" alt="Chania">
                <div class="carousel-caption" style="color:black;">Workshop on Employability and Entrepreneurship skill Development
                </div>
            </div>
			<div class="item ">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/FDP_WEMAD.jpg" alt="Chania">
                <div class="carousel-caption">One Week FDP By NITTTR,Bhopal on Work Ethics Motivation And Attitude Development
                </div>
            </div>
			
			
        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="fa fa-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="fa fa-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

     <!--<div class="entry">
        <div class="row cat-box-content">
          <a style="color:#E00707!important;" target="_blank" href="http://gpsakoli.ac.in/files/adv.pdf"><span class="fa fa-angle-double-right"></span>&nbsp;Time Table For Admission for online registered and  non cap register candidate For First Year and Second Year</a><img src="http://gpsakoli.ac.in/assets/media/images/new.gif"/>
            <ul id="js-news" class="js-hidden">
                <li class="news-item"><a target="_blank" href="https://online.msbte.co.in/msbte19/reportsindex.php?act=time_table_s&sub=print_tt">Summer-2020 final Exam Time Table </a><img src=""></li>
				<li class="news-item"><a target="_blank" href="https://online.msbte.co.in/msbte19/index.php?act=hall_ticket&sub=hallticket_s_public">HALL Ticket Summer-2020 Examination </a><img src=""></li>
                <li class="news-item"><a target="_blank"  href="http://gpsakoli.ac.in/files/me.pdf">Admitted Student List For Year 2020-21 to Mechanical Engineering.</a></li>
                <li target="_blank"  class="news-item"><a href="http://gpsakoli.ac.in/files/et.pdf">Admitted Student List For Year 2020-21 to Electrical Engineering.</a></li>
                <li target="_blank"  class="news-item"><a href="http://gpsakoli.ac.in/files/ce.pdf">Admitted Student List For Year 2020-21 to Civil Engineering.</a></li>
                <li target="_blank"  class="news-item"><a href="http://gpsakoli.ac.in/files/etx.pdf">Admitted Student List For Year 2020-21 to Electronics & Telecommunications Engg.</a></li>
                <li class="news-item"><a href="http://gpsakoli.ac.in/news/vacant-position">Vacancy position   in different  branch For First Year.</a></li>
                 <li class="news-item"><a target="_blank" href="http://gpsakoli.ac.in/files/cs2.pdf">Admitted Student List For Year 2020-21 to Second Year Computer Technology.</a></li>
                <li class="news-item"><a target="_blank"  href="http://gpsakoli.ac.in/files/me2.pdf">Admitted Student List For Year 2020-21 to Second Year Mechanical Engineering.</a></li>
                <li target="_blank"  class="news-item"><a href="http://gpsakoli.ac.in/files/et2.pdf">Admitted Student List For Year 2020-21 to Second Year Electrical Engineering.</a></li>
                <li target="_blank"  class="news-item"><a href="http://gpsakoli.ac.in/files/ce2.pdf">Admitted Student List For Year 2020-21 to Second Year Civil Engineering.</a></li>
                <li target="_blank"  class="news-item"><a href="http://gpsakoli.ac.in/files/etx2.pdf">Admitted Student List For Year 2020-21 to Second Year Electronics & Telecommunications Engg.</a></li>
                <li class="news-item"><a href="http://gpsakoli.ac.in/news/vacant-position-second-year">Vacancy position   For Second Year.</a></li>
               
            </ul>
        </div>
    </div>--> 
    <div class="entry">
        <div class="row cat-box-content">
            <div class="col-sm-6  text-center">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/principal.jpg" class="" width="150" height="100">
                <h4>Dr. C. S. Thorat</h4>
                <span>Principal</span>
            </div>
            <div class="col-sm-6 text-center">
                <h4 style="background:#0b33dc;color:#fff;font-weight:900">Mission</h4>
                <p>
                    <span class="fa fa-quote-left fa-2x" style="color:#2ecc71"></span>&nbsp;Set
 up state of art infrastructure, laboratories, library and e-governance
                    Build strategic networking with alumni, industries 
and academic institutions. Persistent efforts in development faculty and
 staff
                    Achieve excellence in teaching learning process and 
innovation.
                    Impart quality education and inculcate professional 
ethics &amp; values. <span class="fa fa-quote-right fa-2x" style="color:#2ecc71"></span>
                </p>
            </div>
        </div>
    </div>
    <div class="entry">
        <div class="row cat-box-content">
            <div class="one_third">
                <h3 class="text-center" style="margin-left:40%;width:50px;height:50px;background:#2ecc71;padding:10px;border-radius:25px;color:#fff;"><i class="fa fa-institution"></i>
                </h3>
                <h3 style="background:#0b33dc;color:#fff">About the Institute</h3>
                <p style="font-size:13px;">Government Polytechnic, 
Sakoli, popularly known as GPS, is one of the foremost technological 
institute established by Government of Maharashtra in 1983.</p>
            </div>
            <div class="one_third">
                <h3 class="text-center" style="margin-left:40%;width:50px;height:50px;background:#2ecc71;padding:10px;border-radius:25px;color:#fff;"><i class="fa fa-location-arrow"></i>
                </h3>
                <h3 style="background:#0b33dc;color:#fff">ABOUT THE CITY</h3>
                <p style="font-size:13px;">Sakoli is situated in the 
district of Bhandara on the Nagpur-Raipur National Highway (NH-06). It 
is well-connected by roads and rails.</p>
            </div>
            <div class="one_third last">
                <h3 class="text-center" style="margin-left:40%;width:50px;height:50px;background:#2ecc71;padding:10px;border-radius:25px;color:#fff;"><i class="fa fa-mortar-board"></i>
                </h3>
                <h3 style="background:#0b33dc;color:#fff">OUR VISION</h3>
                <p style="font-size:13px;">To be the institution of 
national-repute in creating ethical and technically competent 
professionals for the progress of global society by imparting values.</p>
            </div>
        </div>
        <div class="row cat-box-content text-center">
            <h4 style="font-weight:900;background:#2ecc71;color:#fff">Opportunities After Diploma</h4>
            <div class="one_third text-center">
                <h4 style="background:#0b33dc;color:#fff">Higher Education</h4>
                <p style="font-size:13px;">Engineering Degree programme ,AMIE, AMIETE,Open University programme.</p>
            </div>
            <div class="one_third">
                
                <h4 style="background:#0b33dc;color:#fff">Employment</h4>
                <p style="font-size:13px;">Government, Semi Government, Public Sector undertaking and Private sector.</p>
            </div>
            <div class="one_third last">
                <h4 style="background:#0b33dc;color:#fff">Entrepreneur</h4>
                <p style="font-size:13px;">Establish own business in their relevant field.</p>
            </div>
        </div>
    </div>
    <div class="entry">
        <div class="row cat-box-content">
            <div class="col-sm-12">
                <h3 style="background:#2ecc71;color:#fff">Course and intake capacity</h3>
                <table class="table table-bordered table-hover course-table">
                    <tbody><tr class="head">
                            <th>Diploma Programme</th>
                            <th>Sanctioned Intake</th>
                            <th>Year of Establishment</th>
                        </tr>
                        <tr>
                            <td>CIVIL ENGINEERING</td>
                            <td>60</td>
                            <td>1983</td>
                        </tr>
                        <tr>
                            <td>MECHANICAL ENGINEERING</td>
                            <td>60</td>
                            <td>1990</td>
                        </tr>
                        <tr>
                            <td>ELECTRONICS &amp; TELE. COMM.</td>
                            <td>60</td>
                            <td>1995</td>
                        </tr>
                        <tr>
                            <td>COMPUTER TECHNOLOGY</td>
                            <td>60</td>
                            <td>2005</td>
                        </tr>
                        <tr>
                            <td>ELECTRICAL ENGINEERING</td>
                            <td>60</td>
                            <td>2007</td>
                        </tr>
                    </tbody></table>
            </div>
        </div>
    </div>
</div>  
﻿<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/font-awesome_002.css">

<aside id="sidebar">
    <div class="theiaStickySidebar" style="padding-top: 0px; padding-bottom: 1px; position: static; top: 0px; width: 310px;">
        
         
         <div id="login-widget-4" class="widget login-widget">
           <div class="widget-top"><h4><strong>Events</strong></h4>
                  <div class="widget-container text-left quick-link"> <div>
                    <ul>
                         <li><a style="color:#E00707!important;" href="http://gpsakoli.ac.in/assets/files/ICTTRD2021.pdf" target="_blank"><span class="fa fa-angle-double-right"></span>&nbsp;International Conference TTRD-2021 Brochure</a></li>
						 <ul>
							<li><b>Dates are Postponed due to pandemic situtation</b></li>
							<li>Abstract Submission: Date will be announced soon</li>
							<li>Intimation of acceptance: Date will be announced soon</li>
							<li>Submission of full paper: Date will be announced soon</li>
							<li>Submission of full paper: Date will be announced soon</li>
							<li><a href="http://www.gpsakoli.ac.in/assets/files/ICTTRDAbstractFormat.docx" target="_blank">Abstract Templete</a></li>
							<li><a href="https://forms.gle/UEkwuqpinVcF6YE66" target="_blank">Registration Link</a></li>
							
						</ul>
						<li><a style="color:#E00707!important;" href="http://gpsakoli.ac.in/welcome/AlumniForm" target="_blank"><span class="fa fa-angle-double-right"></span>&nbsp;Alumini Registration</a></li>
                        
                        
                    </ul>
                </div>
            </div>
            </div>
             
           </div>
		   
		    <div id="login-widget-4" class="widget login-widget">
            <div class="widget-top"><h4><strong>Admission Process Dates</strong></h4>
                  <div class="widget-container text-left quick-link"> <div>
                   <ul>
						<li><b>Important Dates:</b></li>
						<li><a href="https://poly20.dtemaharashtra.org/diploma20/index.php/hp_controller/impDates" target="_blank">For Fisrt Year Admission Dates Click Here</a></li>
						<li><a href="https://dsd20.dtemaharashtra.org/dsd20/index.php/hp_controller/impDates" target="_blank">For Direct Second Year Admission Dates Click Here</a></li>
					</ul>
                       
                    
                </div>
            </div>
            </div>
             
           </div>
		   <div id="login-widget-4 text-center" class="widget login-widget">
            <div class="widget-top"><h4><strong>News</strong></h4>
                  <div class="widget-container text-left quick-link"> <div>
                    <ul>
                        <li><a style="color:#E00707!important;" href="http://gpsakoli.ac.in/assets/files/enggdayceleb.pdf" target="_blank"><span class="fa fa-angle-double-right"></span>Engineer's Day celebration</a></li>
                     </ul>
                </div>
            </div>
            </div>
             
           </div>
		    <div id="login-widget-4 text-center" class="widget login-widget">
            <div class="widget-top"><h4><strong>Quotations</strong></h4>
                  <div class="widget-container text-left quick-link"> <div>
                    <ul>
                        <li><a style="color:#E00707!important;" href="http://gpsakoli.ac.in/assets/files/CleanNivida.pdf" target="_blank"><span class="fa fa-angle-double-right"></span>सफाई  काम कंत्राटी पद्धतीने करण्याबाबतची निविदा</a></li>
                        
					 </ul>
                </div>
            </div>
            </div>
             
           </div>
		 
		   <div id="login-widget-4 text-center" class="widget login-widget">
            <div class="widget-top"><h4><strong>पदविका प्रवेश </strong></h4>
                  <div class="widget-container text-left quick-link"> <div>
                    <ul>
                        <li><a style="color:#E00707!important;" href="http://gpsakoli.ac.in/assets/images/DiplomaAdmissionPresentationWebsite.pdf" target="_blank"><span class="fa fa-angle-double-right"></span>&nbsp;दहावी नंतर अभियांत्रीकी  तंत्रशिक्षणाचे पर्याय </a></li>
                        
                        
                    </ul>
                </div>
            </div>
            </div>
             
           </div>
		   
		 		    <div id="login-widget-4" class="widget login-widget">
            <div class="widget-top"><h4><strong>Download</strong></h4>
                  <div class="widget-container text-left quick-link"> <div>
                    <ul>
                        <li><a style="color:#E00707!important;" href="https://online.msbte.co.in/msbte19/index.php?act=exam_login" target="_blank"><span class="fa fa-angle-double-right"></span>&nbsp;Exam Form</a>
                       <br> <a style="color:#E00707!important;" href="https://msbte.org.in/portal/question-paper-search/" target="_blank"><span class="fa fa-angle-double-right"></span>&nbsp;Question paper</a>
						<br><a style="color:#E00707!important;" href="https://msbte.org.in/portal/curriculum-search/" target="_blank"><span class="fa fa-angle-double-right"></span>&nbsp;Syllabus</a></li>

                        
                    </ul>
                </div>
            </div>
            </div>
             
           </div> 
        
		   
		  
        

       
    </div></aside></div> 

</div>

 

<footer id="theme-footer" style="background-color: #FBE7FD">
    <div id="footer-widget-area" class="footer-3c" style="background-color: #FBE7FD">
        <div id="footer-first" class="footer-widgets-box" style="background-color: #FBE7FD">
            <div id="text-html-widget-2" class="text-html-box" style="background-color: #FBE7FD">
                <div class="entry text-center" style="margin-top:20px;">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/site-logo.png" alt="IIQS" width="100" height="44">
                    <p>Government Polytechinc Sakoli <br>
                         SendurWafa Road , Sakoli<br>
                        Sakoli Dist. Bhandara , 441802
                    </p>
                     <p><span class="fa fa-phone"></span> 071 86 236 206 <span class="fa fa-phone"></span> 071 86 237470</p>
                    <p><span class="fa fa-envelope"></span> admin@gpsakoli.ac.in</p>
                </div> 
            </div>
        </div>
        <div id="footer-second" class="footer-widgets-box">
            <div id="posts-list-widget-2" class="footer-widget posts-list"><div class="footer-widget-top"><h4>Useful Links </h4></div>
                <div class="footer-widget-container"> 
                    <ul class="footer-links">
                        <li>
                            <a href="#" target="_blank">RTI</a>
                        </li>
                        <li>
                            <a href="#">Blogs</a>
                        </li>
                        <li>
                            <a href="#">Notices</a>
                        </li>
                        <li>
                            <a href="#">E-magazine</a>
                        </li>
                        <li>
                            <a href="#">Training and Placement</a>
                        </li>
                        
                        <li>
                            <a href="https://docs.google.com/forms/d/e/1FAIpQLSefEmEmD6NpnypBL0gWug4_MjyFRD2ZnLtIAihd6eU4u8mfOQ/viewform?usp=sf_link">Online Grievance Redressal System</a>
                        </li>
                        <li>
                            <a href="https://web.archive.org/web/20190120052100/http://gpsakoli.ac.in/docs/citizen_charter.pdf">Citizen Charter</a>
                        </li>

                    </ul>
                    <div class="clear"></div>
                </div></div>  </div> 
        <div id="footer-third" class="footer-widgets-box">
             <div class="footer-widget-container"> 
                 <div class="footer-widget-top"><h4>Departments</h4></div>
                    <ul class="footer-links">
                        <li>
                            <a href="http://gpsakoli.ac.in/welcome/civil" target="_blank">Civil</a>
                        </li>
                        <li>
                            <a href="#">Mechanical</a>
                        </li>
                        <li>
                            <a href="#">Computer Technology</a>
                        </li>
                        <li>
                            <a href="#">Electrical</a>
                        </li>
                        <li>
                            <a href="#">Electronics and Tele.Comm.</a>
                        </li>

                    </ul>
                    <div class="clear"></div>
                </div>
 </div> 
    </div> 
    <div class="clear"></div>
</footer>
<div class="footer-bottom">
    <div class="container">
        <div class="alignright">
        </div>
        <div class="alignleft">
            © Copyright 2017, All Rights Reserved </div>
        <div class="clear"></div>
    </div> 
</div>
</div>
</div>

<div id="topcontrol" class="fa fa-angle-up" title="Scroll To Top" style="bottom: -100px;"></div>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/jquery-3.js"></script>
        <!--<script type='text/javascript' src="http://gpsakoli.ac.in/assets/js/jquery.js"></script>-->
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/jquery-migrate.js"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/custom-scripts.js"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/active-menu.js"></script>
<script type="text/javascript" src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/page-scripts.js"></script>
<!-- Latest compiled JavaScript -->
<script src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/bootstrap.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/jquery_002.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/monthly.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/common.js"></script>
<script src="<?php echo get_stylesheet_directory_uri(); ?>/Sakoli_files/jquery.js"></script>
<script>
    $(document).ready(function(){
        $('#mainCarousel').carousel({
    interval: 3000 
    });
    });
    </script>
       <script type="text/javascript">
    $(function () {
        $('#js-news').ticker();
    });
</script>


      <!--
     FILE ARCHIVED ON 05:21:00 Jan 20, 2019 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 03:15:27 Apr 29, 2019.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
-->
<!--
playback timings (ms):
  LoadShardBlock: 44.43 (3)
  esindex: 0.007
  captures_list: 83.201
  CDXLines.iter: 13.617 (3)
  PetaboxLoader3.datanode: 92.483 (5)
  exclusion.robots: 0.379
  exclusion.robots.policy: 0.364
  RedisCDXSource: 21.018
  PetaboxLoader3.resolve: 59.899 (2)
  load_resource: 190.719
--></body></html>